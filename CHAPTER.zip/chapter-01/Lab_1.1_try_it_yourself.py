"""Lab 1.1 - Try It Yourself: Research and Classify Database Products

Classify ScyllaDB, InfluxDB and ArangoDB into NoSQL families and decide whether
each one fits neatly into a single family or spans multiple families.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config.connection import get_db, reset_collection, banner
from rich.table import Table
from rich.console import Console

console = Console()


def main():
    banner("Lab 1.1 (Try It Yourself): Classify ScyllaDB, InfluxDB, ArangoDB")

    db = get_db("nosql_labs")
    col = reset_collection("nosql_labs", "try_it_yourself_products")

    # Researched products. "families" lists every family the product touches;
    # "primary_family" is the best single label; "fits_neatly" is our verdict.
    products = [
        {
            "name": "ScyllaDB",
            "primary_family": "Wide-Column",
            "families": ["Wide-Column"],
            "data_model": "Column-Family (partitioned rows, Cassandra-compatible)",
            "vendor": "ScyllaDB Inc.",
            "query_language": "CQL (also DynamoDB-compatible API via Alternator)",
            "use_case": "Low-latency, high-throughput workloads: messaging, IoT, ad tech, real-time feeds",
            "open_source": True,
            "fits_neatly": True,
            "reasoning": "Drop-in Cassandra-style wide-column store rewritten in C++ with a shard-per-core design; "
                         "the data model is a classic partitioned wide-column model.",
            "caveat": "Its DynamoDB-compatible API exposes a key-value/document flavor, but the engine underneath is wide-column.",
        },
        {
            "name": "InfluxDB",
            "primary_family": "Time-Series",
            "families": ["Time-Series", "Wide-Column"],
            "data_model": "Measurements with tags, fields and timestamps (columnar storage in v3)",
            "vendor": "InfluxData",
            "query_language": "InfluxQL, Flux, SQL (v3)",
            "use_case": "Metrics, IoT sensor data, monitoring and observability, real-time analytics",
            "open_source": True,
            "fits_neatly": False,
            "reasoning": "Purpose-built for timestamped data. Time-series is often treated as a specialized "
                         "sub-type of the wide-column/column-oriented family rather than one of the four classic families.",
            "caveat": "Doesn't map cleanly to key-value, document, wide-column or graph; it is a specialized family of its own.",
        },
        {
            "name": "ArangoDB",
            "primary_family": "Multi-Model",
            "families": ["Document", "Graph", "Key-Value", "Search"],
            "data_model": "JSON documents + native graphs + key-value access in one engine",
            "vendor": "ArangoDB Inc.",
            "query_language": "AQL (ArangoDB Query Language)",
            "use_case": "Knowledge graphs, recommendations, fraud detection, apps needing documents and graph traversals together",
            "open_source": True,
            "fits_neatly": False,
            "reasoning": "A single engine and query language (AQL) that handles documents, graphs and key-value lookups, "
                         "so it deliberately spans several families.",
            "caveat": "Multi-model flexibility can mean it is not the deepest option in any single model.",
        },
    ]

    col.insert_many(products)
    print(f"[OK] Inserted {len(products)} researched products.\n")

    # Summary table
    table = Table(title="Try It Yourself: Product Classification", show_lines=True)
    table.add_column("Product", style="cyan", width=12)
    table.add_column("Primary Family", style="magenta", width=14)
    table.add_column("Families Spanned", width=34)
    table.add_column("Fits Neatly?", width=12)
    table.add_column("Best For", width=45)

    for p in col.find().sort("name"):
        table.add_row(
            p["name"],
            p["primary_family"],
            ", ".join(p["families"]),
            "Yes" if p["fits_neatly"] else "No",
            p["use_case"],
        )
    console.print(table)

    # Reasoning and caveats
    print("\n--- Classification Reasoning ---")
    for p in col.find().sort("name"):
        print(f"\n  {p['name']} ({p['primary_family']})")
        print(f"    Why:    {p['reasoning']}")
        print(f"    Caveat: {p['caveat']}")

    # Aggregation: neat vs. spanning
    print("\n--- Neat Fit vs. Spans Multiple Families ---")
    pipeline = [
        {"$group": {"_id": "$fits_neatly", "count": {"$sum": 1}, "products": {"$push": "$name"}}},
        {"$sort": {"_id": -1}},
    ]
    for g in col.aggregate(pipeline):
        label = "Fits one family neatly" if g["_id"] else "Spans / blurs families"
        print(f"  {label:24}: {g['count']} -> {', '.join(g['products'])}")

    # Query: products that touch more than one family
    print("\n--- Products touching 2+ families ---")
    for p in col.find({"$expr": {"$gt": [{"$size": "$families"}, 1]}}):
        print(f"  {p['name']}: {', '.join(p['families'])}")

    banner("Lab 1.1 (Try It Yourself) Complete")


if __name__ == "__main__":
    main()
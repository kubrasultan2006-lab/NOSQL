python chapter-01\Lab_1.1_try_it_yourself.py
PS C:\Users\Kubra\pymongo-quickstart> python chapter-01\Lab_1.1_try_it_yourself.py  

============================================================
  Lab 1.1 (Try It Yourself): Classify ScyllaDB, InfluxDB, ArangoDB
============================================================

[OK] Connected to MongoDB at mongodb://localhost:27017
[OK] Dropped collection: nosql_labs.try_it_yourself_products
[OK] Inserted 3 researched products.

                                               Try It Yourself: Product Classification                                               
┏━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ Product      ┃ Primary Family ┃ Families Spanned                   ┃ Fits Neatly? ┃ Best For                                      ┃
┡━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┩
│ ArangoDB     │ Multi-Model    │ Document, Graph, Key-Value, Search │ No           │ Knowledge graphs, recommendations, fraud      │
│              │                │                                    │              │ detection, apps needing documents and graph   │
│              │                │                                    │              │ traversals together                           │
├──────────────┼────────────────┼────────────────────────────────────┼──────────────┼───────────────────────────────────────────────┤
│ InfluxDB     │ Time-Series    │ Time-Series, Wide-Column           │ No           │ Metrics, IoT sensor data, monitoring and      │
│              │                │                                    │              │ observability, real-time analytics            │
├──────────────┼────────────────┼────────────────────────────────────┼──────────────┼───────────────────────────────────────────────┤
│ ScyllaDB     │ Wide-Column    │ Wide-Column                        │ Yes          │ Low-latency, high-throughput workloads:       │
│              │                │                                    │              │ messaging, IoT, ad tech, real-time feeds      │
└──────────────┴────────────────┴────────────────────────────────────┴──────────────┴───────────────────────────────────────────────┘

--- Classification Reasoning ---

  ArangoDB (Multi-Model)
    Why:    A single engine and query language (AQL) that handles documents, graphs and key-value lookups, so it deliberately spans several families.
    Caveat: Multi-model flexibility can mean it is not the deepest option in any single model.

  InfluxDB (Time-Series)
    Why:    Purpose-built for timestamped data. Time-series is often treated as a specialized sub-type of the wide-column/column-oriented family rather than one of the four classic families.
    Caveat: Doesn't map cleanly to key-value, document, wide-column or graph; it is a specialized family of its own.

  ScyllaDB (Wide-Column)
    Why:    Drop-in Cassandra-style wide-column store rewritten in C++ with a shard-per-core design; the data model is a classic partitioned wide-column model.
    Caveat: Its DynamoDB-compatible API exposes a key-value/document flavor, but the engine underneath is wide-column.

--- Neat Fit vs. Spans Multiple Families ---
  Fits one family neatly  : 1 -> ScyllaDB
  Spans / blurs families  : 2 -> InfluxDB, ArangoDB

--- Products touching 2+ families ---
  InfluxDB: Time-Series, Wide-Column
  ArangoDB: Document, Graph, Key-Value, Search

============================================================
  Lab 1.1 (Try It Yourself) Complete
============================================================


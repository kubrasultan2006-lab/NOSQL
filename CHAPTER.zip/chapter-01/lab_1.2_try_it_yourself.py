"""Lab 1.2 - Try It Yourself: Map an E-Commerce Application to NoSQL Families

Choose a different application domain (e-commerce) and map each data domain
to the most appropriate NoSQL family, documenting the reasoning for each.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config.connection import get_db, reset_collection, banner
from rich.table import Table
from rich.console import Console

console = Console()


def main():
    banner("Lab 1.2 (Try It Yourself): E-Commerce Application Mapping")

    db = get_db("nosql_labs")
    col = reset_collection("nosql_labs", "ecommerce_mapping")

    # Each data domain of an Amazon-style e-commerce platform mapped to a NoSQL family
    mappings = [
        {
            "data_domain": "Product Catalog",
            "family": "Document",
            "product": "MongoDB",
            "access_pattern": "Read-heavy; fetch a product by ID or filter by category, brand, price",
            "reasoning": "Products have varying attributes (a phone has storage and screen size, a shirt has size "
                         "and fabric), nested specs and reviews. A document database stores each product as one "
                         "self-contained JSON document with a flexible schema, and secondary indexes support "
                         "filtering and faceted search.",
        },
        {
            "data_domain": "Shopping Cart & Sessions",
            "family": "Key-Value",
            "product": "Redis",
            "access_pattern": "Very frequent reads/writes by session or user ID; short-lived data",
            "reasoning": "A cart is always accessed by a single key (the user or session ID) and needs sub-millisecond "
                         "latency. Redis keeps it in memory, supports TTL expiry for abandoned carts, and needs no "
                         "complex querying.",
        },
        {
            "data_domain": "Order History",
            "family": "Wide-Column",
            "product": "Cassandra",
            "access_pattern": "Append-only writes; queried by customer ID and date range",
            "reasoning": "Orders are written once and rarely updated, and are fetched per customer in time order. "
                         "Partitioning by customer ID with orders clustered by date gives fast range reads and "
                         "scales writes horizontally across many nodes.",
        },
        {
            "data_domain": "Recommendations (Customers Also Bought)",
            "family": "Graph",
            "product": "Neo4j",
            "access_pattern": "Multi-hop traversals: users -> purchased items -> other buyers -> their items",
            "reasoning": "Recommendations come from relationships between customers and products. A graph database "
                         "traverses these connections directly, while the same query in other families would need "
                         "expensive joins or application-side processing.",
        },
        {
            "data_domain": "Clickstream & Event Analytics",
            "family": "Wide-Column",
            "product": "Cassandra / HBase",
            "access_pattern": "Massive write throughput; time-series reads per user or page",
            "reasoning": "Millions of click and view events arrive every minute and are queried by time window. "
                         "A column-family store handles high write volume, partitions by time bucket, and scales "
                         "linearly, making it a good fit for event logs.",
        },
    ]

    col.insert_many(mappings)
    print(f"[OK] Inserted {len(mappings)} data-domain mappings.\n")

    # Mapping table
    table = Table(title="E-Commerce: Data Domain -> NoSQL Family", show_lines=True)
    table.add_column("Data Domain", style="cyan", width=26)
    table.add_column("Family", style="magenta", width=12)
    table.add_column("Product", width=18)
    table.add_column("Access Pattern", width=48)

    for m in col.find():
        table.add_row(m["data_domain"], m["family"], m["product"], m["access_pattern"])
    console.print(table)

    # Reasoning paragraphs
    print("\n--- Reasoning per Data Domain ---")
    for m in col.find():
        print(f"\n  {m['data_domain']} -> {m['family']} ({m['product']})")
        print(f"    {m['reasoning']}")

    # Group by family
    print("\n--- Grouped by Family ---")
    pipeline = [
        {"$group": {"_id": "$family", "count": {"$sum": 1}, "domains": {"$push": "$data_domain"}}},
        {"$sort": {"count": -1}},
    ]
    for g in col.aggregate(pipeline):
        print(f"  {g['_id']:12} : {g['count']} domain(s) -> {', '.join(g['domains'])}")

    print("\n[TIP] No single family fits every data domain; this is polyglot persistence.")

    banner("Lab 1.2 (Try It Yourself) Complete")


if __name__ == "__main__":
    main()
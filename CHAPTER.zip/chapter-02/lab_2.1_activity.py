"""Lab 2.1 - Activity: Compare Atlas and Docker MongoDB Server Versions

Connects to a local Docker MongoDB and a MongoDB Atlas cluster at the same time
and compares their server_info() output.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pymongo import MongoClient
from config.connection import banner
from rich.console import Console
from rich.table import Table

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

console = Console()

LOCAL_URI = os.getenv("MONGO_URI_LOCAL", "mongodb://localhost:27017")
ATLAS_URI = os.getenv("MONGO_URI_ATLAS")


def get_server_info(label, uri, timeout_ms=5000):
    """Connect to a MongoDB deployment and return its server_info() dict, or None."""
    if not uri:
        print(f"  {label:7}: NOT CONFIGURED (set MONGO_URI_ATLAS in .env)")
        return None
    try:
        client = MongoClient(uri, serverSelectionTimeoutMS=timeout_ms)
        client.admin.command("ping")
        info = client.server_info()
        print(f"  {label:7}: CONNECTED [OK] (version {info['version']})")
        client.close()
        return info
    except Exception as e:
        print(f"  {label:7}: FAILED ({type(e).__name__}: {str(e)[:80]})")
        return None


def version_tuple(info):
    return tuple(info.get("versionArray", [])[:3])


def main():
    banner("Lab 2.1 Activity: Atlas vs Docker MongoDB")

    print("Connecting to both deployments...")
    local = get_server_info("Docker", LOCAL_URI, 3000)
    atlas = get_server_info("Atlas", ATLAS_URI, 8000)

    if not local and not atlas:
        print("\n[WARN] Could not connect to either deployment.")
        print("  Docker: docker run -d -p 27017:27017 mongo:7")
        print("  Atlas : set MONGO_URI_ATLAS in your .env file")
        banner("Lab 2.1 Activity Complete")
        return

    # Fields from server_info() to compare
    fields = [
        ("Version", "version"),
        ("Version Array", "versionArray"),
        ("Git Version", "gitVersion"),
        ("Max BSON Object Size", "maxBsonObjectSize"),
        ("Storage Engines", "storageEngines"),
        ("Allocator", "allocator"),
        ("JavaScript Engine", "javascriptEngine"),
        ("Bits", "bits"),
        ("Debug Build", "debug"),
        ("OpenSSL", "openssl"),
    ]

    table = Table(title="Server Info Comparison", show_lines=True)
    table.add_column("Field", style="cyan", width=22)
    table.add_column("Docker (Local)", width=34)
    table.add_column("Atlas", width=34)
    table.add_column("Match?", width=8)

    for label, key in fields:
        l_val = local.get(key, "N/A") if local else "N/A"
        a_val = atlas.get(key, "N/A") if atlas else "N/A"
        match = "Yes" if (local and atlas and l_val == a_val) else "No"
        table.add_row(label, str(l_val)[:32], str(a_val)[:32], match)
    console.print(table)

    # Version verdict
    print("\n--- Version Comparison ---")
    if local and atlas:
        lv, av = version_tuple(local), version_tuple(atlas)
        print(f"  Docker : {local['version']}")
        print(f"  Atlas  : {atlas['version']}")
        if lv == av:
            print("  [OK] Both run the same MongoDB version.")
        elif lv > av:
            print("  [NOTE] Docker is running a newer version than Atlas.")
        else:
            print("  [NOTE] Atlas is running a newer version than Docker.")
        if lv[:2] != av[:2]:
            print("  [TIP] Different major/minor versions may differ in features")
            print("        (e.g. aggregation operators, time-series, Atlas Search/Vector Search).")
    else:
        which = "Docker" if local else "Atlas"
        print(f"  Only {which} is reachable, so no comparison is possible.")

    banner("Lab 2.1 Activity Complete")


if __name__ == "__main__":
    main()
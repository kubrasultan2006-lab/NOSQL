"""Lab 2.2 - Activity: Update Prices of Books Published Before 2010

Adds an update operation that increases the price of all books published
before 2010 by 10 percent, then verifies the result. The collection is left
in place so the change can also be checked in MongoDB Compass.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config.connection import get_db, reset_collection, banner
from rich.console import Console
from rich.table import Table

console = Console()


BOOKS = [
    {"title": "The Pragmatic Programmer", "author": "David Thomas & Andrew Hunt",
     "year": 2019, "genre": "Software Engineering", "price": 49.99, "isbn": "978-0135957059",
     "tags": ["programming", "career", "best-practices"],
     "publisher": {"name": "Addison-Wesley", "location": "Boston"}},
    {"title": "Designing Data-Intensive Applications", "author": "Martin Kleppmann",
     "year": 2017, "genre": "Databases", "price": 45.99, "isbn": "978-1449373320",
     "tags": ["databases", "distributed-systems", "architecture"],
     "publisher": {"name": "O'Reilly Media", "location": "Sebastopol"}},
    {"title": "Deep Learning", "author": "Ian Goodfellow, Yoshua Bengio, Aaron Courville",
     "year": 2016, "genre": "Machine Learning", "price": 72.00, "isbn": "978-0262035613",
     "tags": ["AI", "neural-networks", "theory"],
     "publisher": {"name": "MIT Press", "location": "Cambridge"}},
    {"title": "Clean Code", "author": "Robert C. Martin",
     "year": 2008, "genre": "Software Engineering", "price": 39.99, "isbn": "978-0132350884",
     "tags": ["programming", "clean-code", "refactoring"],
     "publisher": {"name": "Prentice Hall", "location": "Upper Saddle River"}},
    {"title": "Hands-On Machine Learning", "author": "Aurelien Geron",
     "year": 2022, "genre": "Machine Learning", "price": 59.99, "isbn": "978-1098125974",
     "tags": ["AI", "scikit-learn", "tensorflow", "practical"],
     "publisher": {"name": "O'Reilly Media", "location": "Sebastopol"}},
    # Extra pre-2010 titles so the update affects more than one document
    {"title": "Code Complete", "author": "Steve McConnell",
     "year": 2004, "genre": "Software Engineering", "price": 54.99, "isbn": "978-0735619678",
     "tags": ["programming", "construction", "best-practices"],
     "publisher": {"name": "Microsoft Press", "location": "Redmond"}},
    {"title": "Introduction to Algorithms", "author": "Cormen, Leiserson, Rivest, Stein",
     "year": 2009, "genre": "Algorithms", "price": 89.00, "isbn": "978-0262033848",
     "tags": ["algorithms", "theory", "data-structures"],
     "publisher": {"name": "MIT Press", "location": "Cambridge"}},
]

PRE_2010 = {"year": {"$lt": 2010}}


def snapshot(col):
    """Return {title: (year, price)} for every book."""
    return {b["title"]: (b["year"], b["price"])
            for b in col.find({}, {"title": 1, "year": 1, "price": 1, "_id": 0})}


def main():
    banner("Lab 2.2 Activity: Price Update for Pre-2010 Books")
    db = get_db("chapter-02")
    col = reset_collection("chapter-02", "books")

    # --- CREATE ---
    print("=== CREATE: Inserting books ===")
    result = col.insert_many(BOOKS)
    print(f"[OK] Inserted {len(result.inserted_ids)} books")

    # --- BEFORE ---
    print("\n=== BEFORE: Books published before 2010 ===")
    before = snapshot(col)
    matched = col.count_documents(PRE_2010)
    for title, (year, price) in before.items():
        if year < 2010:
            print(f"  {title:<45} ({year}) ${price:.2f}")
    print(f"  Matching documents: {matched}")

    # --- UPDATE: +10% for year < 2010 ---
    # An aggregation-pipeline update lets us round to 2 decimals, so Compass shows
    # clean values like 43.99 instead of 43.989000000000004 (what a plain $mul gives).
    print("\n=== UPDATE: +10% on books published before 2010 ===")
    update_result = col.update_many(
        PRE_2010,
        [{"$set": {"price": {"$round": [{"$multiply": ["$price", 1.10]}, 2]}}}],
    )
    print(f"[OK] Matched {update_result.matched_count}, modified {update_result.modified_count}")

    # --- AFTER / VERIFY ---
    after = snapshot(col)
    table = Table(title="Price Update Verification", show_lines=True)
    table.add_column("Title", style="cyan", width=40)
    table.add_column("Year", width=6)
    table.add_column("Old Price", width=10)
    table.add_column("New Price", width=10)
    table.add_column("Change", width=10)

    all_ok = True
    for title, (year, old_price) in before.items():
        new_price = after[title][1]
        expected = round(old_price * 1.10, 2) if year < 2010 else old_price
        ok = abs(new_price - expected) < 0.005
        all_ok = all_ok and ok
        change = "+10%" if year < 2010 else "unchanged"
        style = "green" if year < 2010 else None
        table.add_row(title, str(year), f"${old_price:.2f}", f"${new_price:.2f}", change, style=style)
    console.print(table)

    print(f"\n  Verification: {'[OK] all prices are as expected' if all_ok else '[FAIL] unexpected prices found'}")

    # --- Compass instructions ---
    print("\n=== VERIFY IN COMPASS ===")
    print("  1. Connect to your MongoDB deployment in Compass")
    print("  2. Open database 'chapter-02' -> collection 'books'")
    print('  3. Filter with:  { "year": { "$lt": 2010 } }')
    print("  4. Compare the 'price' values with the 'New Price' column above")
    print("  5. Clear the filter and confirm books from 2010 or later were not changed")

    banner("Lab 2.2 Activity Complete")


if __name__ == "__main__":
    main()
"""
Activity 14.1 - Try it yourself: send alerts to a webhook (Slack / Discord)

Extends "Lab 14.1 - Build a Monitoring Dashboard.py" (keep it in the same folder). The lab script
already prints tables and WARNINGs; this one also pushes every breach of a threshold to a webhook:

  * Slack     -> {"text": ...}      (hooks.slack.com URLs, detected automatically)
  * Discord   -> {"content": ...}   (discord.com/api/webhooks URLs, detected automatically)
  * generic   -> {"text", "alerts", "host", "time"}   (any other URL)

Extras that make it usable for real:
  * cooldown   : the same alert is re-sent at most once per --cooldown seconds (default 300),
                 instead of a message every 30 seconds while the problem lasts
  * resolved   : when an alert clears, a "resolved" message is sent once
  * error safe : the HTTP call has a timeout, one retry and a try/except, so a broken webhook
                 never stops the monitoring
  * test tools : --test-receiver starts a small local webhook server that prints what it
                 receives (no Slack or Discord account needed); --simulate fakes a breach

Try it without any account (4 samples, 3 seconds apart; sample 1 alerts, 2 is suppressed by the
cooldown, 3 sends "resolved", 4 is quiet):
    python "chapter-14\\Activity for 14.1 - Try it yourself.py" --test-receiver --simulate --interval 3 --count 4
Same, but showing the Slack or Discord message format:
    python "chapter-14\\Activity for 14.1 - Try it yourself.py" --test-receiver --webhook-type discord --simulate --interval 3 --count 4
Real webhook (replace the URL; it is a secret, do not share or commit it):
    python "chapter-14\\Activity for 14.1 - Try it yourself.py" --webhook "https://hooks.slack.com/services/..." --send-test
Real thresholds (alerts only when the cluster really breaches them):
    python "chapter-14\\Activity for 14.1 - Try it yourself.py" --webhook "<url>" --cache-threshold 80 --lag-threshold 10

All options of Lab 14.1 (--uri, --user, --password, --no-auth, --interval, --count, --log,
--cache-threshold, --lag-threshold, --demo-load) work the same here.
Requires: pip install pymongo   (the webhook uses only the Python standard library)
"""

import argparse
import importlib.util
import json
import os
import re
import sys
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime
from http.server import BaseHTTPRequestHandler, HTTPServer
from itertools import count
from pathlib import Path

LAB_FILE = Path(__file__).resolve().parent / "Lab 14.1 - Build a Monitoring Dashboard.py"


# ------------------------------------------------------- reuse the Lab 14.1 code
def load_lab():
    if not LAB_FILE.exists():
        sys.exit(f"Missing '{LAB_FILE.name}'. Keep the Lab 14.1 script in the same folder as this file.")
    spec = importlib.util.spec_from_file_location("lab141", LAB_FILE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# ---------------------------------------------------------------- arguments
def parse_args():
    p = argparse.ArgumentParser(description="MongoDB monitoring with webhook alerts (Activity 14.1)")
    p.add_argument("--uri", default="mongodb://localhost:27047/")
    p.add_argument("--user", default="rsadmin")
    p.add_argument("--password", default="RsLabPass123")
    p.add_argument("--auth-source", default="admin")
    p.add_argument("--no-auth", action="store_true")
    p.add_argument("--interval", type=float, default=30)
    p.add_argument("--count", type=int, default=0)
    p.add_argument("--log", default="metrics.log")
    p.add_argument("--cache-threshold", type=float, default=80.0)
    p.add_argument("--lag-threshold", type=float, default=10.0)
    p.add_argument("--demo-load", action="store_true")
    p.add_argument("--webhook", default=os.environ.get("WEBHOOK_URL"),
                   help="Slack/Discord/other webhook URL (or set the WEBHOOK_URL environment variable)")
    p.add_argument("--webhook-type", choices=["auto", "slack", "discord", "generic"], default="auto")
    p.add_argument("--cooldown", type=float, default=300,
                   help="minimum seconds before the same alert is sent again (default 300)")
    p.add_argument("--send-test", action="store_true", help="send one test message at startup")
    p.add_argument("--test-receiver", action="store_true",
                   help="start a local webhook receiver that prints what it gets, and use it")
    p.add_argument("--simulate", action="store_true",
                   help="fake a cache-hit-ratio breach on samples 1-2 to demonstrate the alerting")
    return p.parse_args()


# ----------------------------------------------------------- message building
def detect_kind(url, requested):
    if requested != "auto":
        return requested
    if "hooks.slack.com" in url:
        return "slack"
    if "discord.com/api/webhooks" in url or "discordapp.com/api/webhooks" in url:
        return "discord"
    return "generic"


def build_payload(kind, title, lines, host):
    bold = {"slack": "*{}*", "discord": "**{}**"}.get(kind, "{}")
    body = bold.format(title) + f" on {host}\n" + "\n".join(f"- {line}" for line in lines)
    if kind == "slack":
        return {"text": body}
    if kind == "discord":
        return {"content": body[:1900]}          # Discord limit is 2000 characters
    return {"text": body, "alerts": lines, "host": host,
            "time": datetime.now().isoformat(timespec="seconds")}


def post_json(url, payload, retries=1):
    """POST JSON. Returns (ok, detail). Never raises."""
    data = json.dumps(payload).encode("utf-8")
    last = "unknown error"
    for attempt in range(retries + 1):
        try:
            request = urllib.request.Request(
                url, data=data, method="POST",
                # Discord rejects the default Python user agent, so set our own
                headers={"Content-Type": "application/json", "User-Agent": "MongoMonitor/1.0"})
            with urllib.request.urlopen(request, timeout=10) as response:
                return True, f"HTTP {response.status}"
        except urllib.error.HTTPError as exc:
            last = f"HTTP {exc.code} {exc.reason}"
        except Exception as exc:  # noqa: BLE001 - timeouts, DNS errors, refused connections
            last = f"{type(exc).__name__}: {exc}"
        if attempt < retries:
            time.sleep(1)
    return False, last


# ------------------------------------------------------ alert state / cooldown
def alert_key(text):
    """'cache hit ratio 72.1% ...' and '... 70.4% ...' are the same alert: ignore the numbers."""
    return re.sub(r"[\d.]+", "#", text)


class Notifier:
    def __init__(self, url, kind, cooldown):
        self.url, self.kind, self.cooldown = url, kind, cooldown
        self.sent = {}            # key -> (time of last send, alert text)

    def send(self, title, lines, host):
        if not self.url:
            return False, "no webhook URL configured"
        return post_json(self.url, build_payload(self.kind, title, lines, host))

    def process(self, alerts, host, now):
        """Send new/due alerts and 'resolved' notices. Returns lines describing what happened."""
        events = []
        current = {alert_key(a): a for a in alerts}

        due = [text for key, text in current.items()
               if key not in self.sent or now - self.sent[key][0] >= self.cooldown]
        quiet = [text for key, text in current.items() if text not in due]
        cleared = [key for key in self.sent if key not in current]

        if due:
            ok, detail = self.send("MongoDB alert", due, host)
            events.append(f"webhook alert ({len(due)}): {'sent, ' if ok else 'FAILED: '}{detail}")
            if ok:
                for text in due:
                    self.sent[alert_key(text)] = (now, text)
        if quiet:
            events.append(f"{len(quiet)} alert(s) still active, not re-sent (cooldown {self.cooldown:g} s)")
        if cleared:
            texts = [self.sent[k][1].replace("WARNING: ", "") for k in cleared]
            ok, detail = self.send("MongoDB alert RESOLVED", texts, host)
            events.append(f"webhook resolved ({len(texts)}): {'sent, ' if ok else 'FAILED: '}{detail}")
            for key in cleared:
                self.sent.pop(key, None)
        return events


# --------------------------------------------------------- local test receiver
class Receiver(BaseHTTPRequestHandler):
    def do_POST(self):
        raw = self.rfile.read(int(self.headers.get("Content-Length", 0)))
        try:
            shown = json.dumps(json.loads(raw), indent=2)
        except ValueError:
            shown = raw.decode("utf-8", "replace")
        print("\n  [test receiver] a webhook message arrived:")
        print("  " + shown.replace("\n", "\n  ") + "\n")
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b"ok")

    def log_message(self, *args):      # keep the console clean
        pass


def start_receiver():
    server = HTTPServer(("127.0.0.1", 0), Receiver)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server, f"http://127.0.0.1:{server.server_port}/webhook"


# --------------------------------------------------------------------- main
def main():
    args = parse_args()
    lab = load_lab()

    receiver = None
    if args.test_receiver:
        receiver, args.webhook = start_receiver()
        print(f"Local test receiver listening at {args.webhook}")
    kind = detect_kind(args.webhook or "", args.webhook_type)
    if args.webhook:
        print(f"Webhook alerts enabled (format: {kind})")
    else:
        print("No webhook URL given: alerts are only printed. Use --webhook <url> or --test-receiver.")
    notifier = Notifier(args.webhook, kind, args.cooldown)

    client = lab.make_client(args)
    try:
        client.admin.command("ping")
    except lab.PyMongoError as exc:
        hint = "Is MongoDB running? For a server without authentication add --no-auth."
        if getattr(exc, "code", None) == 18:
            hint = ("The server rejected the login. Either another MongoDB (for example the Windows\n"
                    "MongoDB service) is answering on this port, or this server has no user "
                    f"'{args.user}' yet.")
        sys.exit(f"Could not connect to {args.uri}: {exc}\n{hint}")

    stop = threading.Event()
    if args.demo_load:
        lab.start_demo_load(client, stop)
        print("Background demo traffic started.")

    if args.send_test:
        ok, detail = notifier.send("MongoDB monitor test message", ["Webhook is working."], "this-computer")
        print(f"Test message: {'sent, ' if ok else 'FAILED: '}{detail}")

    print(f"Monitoring {args.uri} every {args.interval:g} s, logging to {args.log} (Ctrl+C to stop)\n")

    previous, previous_time = None, None
    try:
        with open(args.log, "a", encoding="utf-8") as log:
            for i in count(1):
                started = time.monotonic()
                stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                try:
                    status = lab.collect_server_status(client)
                    repl = lab.collect_replication(client)
                except lab.PyMongoError as exc:
                    message = f"{stamp} ERROR: could not read metrics: {exc}"
                    print(message)
                    log.write(message + "\n")
                    log.flush()
                else:
                    elapsed = (time.monotonic() - previous_time) if previous_time else 0
                    report = lab.build_report(stamp, args.uri, status, repl, previous, elapsed)
                    alerts = lab.check_alerts(status, repl, args.cache_threshold, args.lag_threshold)
                    if args.simulate and i <= 2:
                        alerts.append("WARNING: cache hit ratio 42.0% is below "
                                      f"{args.cache_threshold:g}% (simulated)")
                    events = notifier.process(alerts, status["host"], time.monotonic())
                    block = (report + ("\n\n" + "\n".join(alerts) if alerts else "\n\nNo alerts.")
                             + "".join(f"\n-> {e}" for e in events) + "\n")
                    print(block)
                    log.write(block + "\n")
                    log.flush()
                    previous, previous_time = status, time.monotonic()

                if args.count and i >= args.count:
                    break
                time.sleep(max(args.interval - (time.monotonic() - started), 0))
    except KeyboardInterrupt:
        print("\nStopped by user.")
    finally:
        stop.set()
        client.close()
        if receiver:
            receiver.shutdown()
    print(f"Log written to {args.log}")


if __name__ == "__main__":
    main()

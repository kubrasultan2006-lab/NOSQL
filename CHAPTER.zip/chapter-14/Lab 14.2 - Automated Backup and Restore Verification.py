"""
Lab 14.2: Automated Backup and Restore Verification

Modes (combine as needed):
  --backup-now          one timestamped mongodump + 7-day retention cleanup
  --verify              insert docs -> backup -> modify -> mongorestore -> verify
  --benchmark           time backup/restore for 1,000 / 10,000 / 100,000 docs
  --schedule            run the backup every hour (schedule library)

Requires: pip install pymongo schedule python-dotenv
          MongoDB Database Tools (mongodump / mongorestore) on PATH
"""

import argparse
import os
import shutil
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

from pymongo import MongoClient

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

BACKUP_PREFIX = "backup_"
TEST_DB = "chapter-14"
TEST_COLL = "backup_test"
PAD = "x" * 900  # ~1 KB per document so 100,000 docs is roughly 100 MB


# --------------------------------------------------------------------------
# Backup + retention
# --------------------------------------------------------------------------
def check_tools():
    missing = [t for t in ("mongodump", "mongorestore") if shutil.which(t) is None]
    if missing:
        print(f"ERROR: {', '.join(missing)} not found on PATH.")
        print("Install the MongoDB Database Tools and reopen the terminal:")
        print("https://www.mongodb.com/try/download/database-tools")
        sys.exit(1)


def run_backup(uri, output_dir, ns=None):
    """Run mongodump into a timestamped folder. Returns (return_code, path, seconds)."""
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    target = Path(output_dir) / f"{BACKUP_PREFIX}{stamp}"
    cmd = ["mongodump", "--uri", uri, "--out", str(target)]
    if ns:
        db_name, coll_name = ns.split(".", 1)
        cmd += ["--db", db_name, "--collection", coll_name]
    start = time.perf_counter()
    result = subprocess.run(cmd, capture_output=True, text=True)
    elapsed = time.perf_counter() - start
    if result.returncode != 0:
        print(f"[ALERT] mongodump failed (code {result.returncode}):\n{result.stderr}")
    return result.returncode, target, elapsed


def run_restore(uri, backup_dir, ns):
    """Run mongorestore --drop for one namespace. Returns (return_code, seconds)."""
    cmd = ["mongorestore", "--uri", uri, "--drop", f"--nsInclude={ns}", str(backup_dir)]
    start = time.perf_counter()
    result = subprocess.run(cmd, capture_output=True, text=True)
    elapsed = time.perf_counter() - start
    if result.returncode != 0:
        print(f"[ALERT] mongorestore failed (code {result.returncode}):\n{result.stderr}")
    return result.returncode, elapsed


def apply_retention(output_dir, days=7):
    """Sort backup folders by creation time and delete those older than `days`."""
    out = Path(output_dir)
    if not out.exists():
        return []
    cutoff = time.time() - days * 86400
    folders = sorted(
        (p for p in out.iterdir() if p.is_dir() and p.name.startswith(BACKUP_PREFIX)),
        key=lambda p: p.stat().st_ctime,
    )
    deleted = []
    for folder in folders:
        if folder.stat().st_ctime < cutoff or folder.stat().st_mtime < cutoff:
            shutil.rmtree(folder)
            deleted.append(folder.name)
    return deleted


def backup_job(uri, output_dir, days):
    rc, path, secs = run_backup(uri, output_dir)
    status = "OK" if rc == 0 else "FAILED"
    print(f"[{datetime.now():%Y-%m-%d %H:%M:%S}] backup {status} -> {path} ({secs:.2f}s)")
    removed = apply_retention(output_dir, days)
    if removed:
        print(f"  retention: removed {len(removed)} old backup(s): {', '.join(removed)}")


# --------------------------------------------------------------------------
# Test data helpers
# --------------------------------------------------------------------------
def seed_collection(coll, n):
    coll.drop()
    batch = []
    for i in range(n):
        batch.append({
            "_id": i,
            "seq": i,
            "name": f"user_{i}",
            "verified": True,
            "created_at": datetime.now().isoformat(),
            "payload": PAD,
        })
        if len(batch) == 10000:
            coll.insert_many(batch)
            batch = []
    if batch:
        coll.insert_many(batch)


def snapshot(coll):
    """Return {_id: (seq, name, verified)} for comparison."""
    return {d["_id"]: (d["seq"], d["name"], d["verified"]) for d in coll.find()}


def compare(before, after):
    """Assertion loop; any mismatch prints an alert. Returns number of mismatches."""
    mismatches = 0
    if len(before) != len(after):
        print(f"[ALERT] document count mismatch: expected {len(before)}, got {len(after)}")
        mismatches += 1
    for _id, expected in before.items():
        try:
            assert after.get(_id) == expected, f"_id={_id}: expected {expected}, got {after.get(_id)}"
        except AssertionError as err:
            mismatches += 1
            if mismatches <= 5:
                print(f"[ALERT] value mismatch {err}")
    return mismatches


# --------------------------------------------------------------------------
# Restore verification
# --------------------------------------------------------------------------
def verify_restore(uri, output_dir, n=1000):
    client = MongoClient(uri)
    coll = client[TEST_DB][TEST_COLL]
    ns = f"{TEST_DB}.{TEST_COLL}"

    print(f"1) Inserting {n} test documents into {ns} ...")
    seed_collection(coll, n)
    before = snapshot(coll)
    print(f"   inserted: {len(before)} documents (verified=True)")

    print("2) Taking backup ...")
    rc, path, b_secs = run_backup(uri, output_dir, ns=ns)
    if rc != 0:
        return False
    print(f"   backup folder: {path} ({b_secs:.2f}s)")

    print("3) Modifying data (set verified=False on all documents) ...")
    res = coll.update_many({}, {"$set": {"verified": False}})
    print(f"   modified: {res.modified_count} documents")
    assert snapshot(coll) != before, "modification did not change data"

    print("4) Restoring with mongorestore --drop ...")
    rc, r_secs = run_restore(uri, path, ns)
    if rc != 0:
        return False
    print(f"   restore time: {r_secs:.2f}s")

    print("5) Verifying restored data against the pre-modification state ...")
    after = snapshot(coll)
    mismatches = compare(before, after)
    if mismatches == 0:
        print(f"   PASS: {len(after)} documents recovered, all fields match original.")
    else:
        print(f"   [ALERT] FAIL: {mismatches} mismatch(es) after restore.")

    # Retention demo: fake an 8-day-old backup and confirm it gets removed
    old = Path(output_dir) / f"{BACKUP_PREFIX}old_demo"
    old.mkdir(parents=True, exist_ok=True)
    eight_days = time.time() - 8 * 86400
    os.utime(old, (eight_days, eight_days))
    removed = apply_retention(output_dir, 7)
    # On Windows ctime is creation time (now), so mtime is also checked above.
    print(f"6) Retention check: old demo backup removed = {old.name in removed}")

    client.close()
    return mismatches == 0


# --------------------------------------------------------------------------
# Benchmark + RPO / RTO
# --------------------------------------------------------------------------
def benchmark(uri, output_dir, sizes, restart_seconds, interval_hours=1):
    client = MongoClient(uri)
    coll = client[TEST_DB][TEST_COLL]
    ns = f"{TEST_DB}.{TEST_COLL}"
    rows = []

    for n in sizes:
        print(f"\nBenchmarking {n:,} documents ...")
        seed_collection(coll, n)
        size_mb = client[TEST_DB].command("collstats", TEST_COLL)["size"] / (1024 * 1024)

        rc, path, b_secs = run_backup(uri, output_dir, ns=ns)
        if rc != 0:
            continue

        coll.drop()  # simulate data loss before restoring
        rc, r_secs = run_restore(uri, path, ns)
        if rc != 0:
            continue

        restored = coll.count_documents({})
        ok = "PASS" if restored == n else f"FAIL ({restored})"
        rows.append((n, size_mb, b_secs, r_secs, ok))
        print(f"  backup {b_secs:.2f}s | restore {r_secs:.2f}s | count check {ok}")

    print("\n" + "=" * 72)
    print(f"{'Documents':>10} | {'Data (MB)':>9} | {'Backup (s)':>10} | {'Restore (s)':>11} | {'RTO (s)':>8} | Check")
    print("-" * 72)
    for n, mb, b, r, ok in rows:
        print(f"{n:>10,} | {mb:>9.1f} | {b:>10.2f} | {r:>11.2f} | {r + restart_seconds:>8.2f} | {ok}")
    print("=" * 72)

    if rows:
        worst = max(rows, key=lambda x: x[3])
        print(f"\nRPO = backup interval = {interval_hours} hour(s) "
              f"(up to {interval_hours * 60} minutes of data could be lost)")
        print(f"RTO = restore time + application restart time "
              f"= {worst[3]:.2f}s + {restart_seconds}s = {worst[3] + restart_seconds:.2f}s "
              f"(for {worst[0]:,} documents)")

    client.drop_database(TEST_DB)
    client.close()


# --------------------------------------------------------------------------
# Scheduler
# --------------------------------------------------------------------------
def run_scheduler(uri, output_dir, days, every_seconds=None):
    import schedule

    job = lambda: backup_job(uri, output_dir, days)
    if every_seconds:
        schedule.every(every_seconds).seconds.do(job)
        print(f"Scheduler: backup every {every_seconds}s (demo mode). Ctrl+C to stop.")
    else:
        schedule.every().hour.do(job)
        print("Scheduler: backup every hour. Ctrl+C to stop.")
    job()  # run once immediately
    try:
        while True:
            schedule.run_pending()
            time.sleep(1)
    except KeyboardInterrupt:
        print("\nScheduler stopped.")


# --------------------------------------------------------------------------
def main():
    p = argparse.ArgumentParser(description="Lab 14.2 - Automated backup and restore verification")
    p.add_argument("--uri", default=os.getenv("MONGODB_URI", "mongodb://rsadmin:RsLabPass123@127.0.0.1:27047/?authSource=admin"))
    p.add_argument("--out", default="backups", help="output directory for backups")
    p.add_argument("--retention-days", type=int, default=7)
    p.add_argument("--backup-now", action="store_true")
    p.add_argument("--verify", action="store_true")
    p.add_argument("--benchmark", action="store_true")
    p.add_argument("--schedule", action="store_true")
    p.add_argument("--every-seconds", type=int, help="demo: schedule every N seconds instead of hourly")
    p.add_argument("--docs", type=int, default=1000, help="documents for --verify")
    p.add_argument("--sizes", type=int, nargs="+", default=[1000, 10000, 100000])
    p.add_argument("--restart-seconds", type=float, default=30.0,
                   help="assumed application restart time used for RTO")
    args = p.parse_args()

    if not (args.backup_now or args.verify or args.benchmark or args.schedule):
        args.verify = True  # sensible default

    check_tools()
    os.makedirs(args.out, exist_ok=True)

    if args.backup_now:
        backup_job(args.uri, args.out, args.retention_days)
    if args.verify:
        ok = verify_restore(args.uri, args.out, args.docs)
        print("\nRESULT:", "restore verified" if ok else "VERIFICATION FAILED")
    if args.benchmark:
        benchmark(args.uri, args.out, args.sizes, args.restart_seconds)
    if args.schedule:
        run_scheduler(args.uri, args.out, args.retention_days, args.every_seconds)


if __name__ == "__main__":
    main()
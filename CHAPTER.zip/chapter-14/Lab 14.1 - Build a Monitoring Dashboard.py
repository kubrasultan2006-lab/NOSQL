"""
Lab 14.1 - Build a Monitoring Dashboard

A Python monitoring script that connects to MongoDB and, every 30 seconds:
  1. reads serverStatus  -> connection count, opcounters, WiredTiger cache statistics
  2. reads replSetGetStatus -> replica set members, state and replication lag (if applicable)
  3. prints the metrics as tables and appends them to a log file (metrics.log)
  4. prints a WARNING if the cache hit ratio drops below 80 percent or if the
     replication lag exceeds 10 seconds
  5. (extension) posts every alert to a webhook with a try/except around the request

Defaults match the Lab 13.1 replica set (mongodb://localhost:27017/, user rsadmin).

Run (replica set from Lab 13.1, runs until Ctrl+C):
    python "chapter-14\\Lab 14.1 - Build a Monitoring Dashboard.py"
Quick demo (3 samples, 5 seconds apart, with some background traffic so the counters move):
    python "chapter-14\\Lab 14.1 - Build a Monitoring Dashboard.py" --interval 5 --count 3 --demo-load
Show an alert on purpose (a threshold that real data cannot meet):
    python "chapter-14\\Lab 14.1 - Build a Monitoring Dashboard.py" --count 1 --cache-threshold 100 --lag-threshold 0
Plain single mongod without authentication:
    python "chapter-14\\Lab 14.1 - Build a Monitoring Dashboard.py" --no-auth
Webhook extension:
    python "chapter-14\\Lab 14.1 - Build a Monitoring Dashboard.py" --webhook https://example.com/hook

Requires: pip install pymongo    (the webhook uses only the Python standard library)
"""

import argparse
import json
import sys
import threading
import time
import urllib.request
from datetime import datetime
from itertools import count

from pymongo import MongoClient
from pymongo.errors import OperationFailure, PyMongoError

OPCOUNTER_NAMES = ["insert", "query", "update", "delete", "getmore", "command"]
MIN_CACHE_REQUESTS = 1000   # below this the hit ratio is not meaningful (server just started)
MB = 1024 * 1024


# ---------------------------------------------------------------- arguments
def parse_args():
    p = argparse.ArgumentParser(description="MongoDB monitoring dashboard (Lab 14.1)")
    p.add_argument("--uri", default="mongodb://localhost:27047/", help="connection string")
    p.add_argument("--user", default="rsadmin", help="username (default: rsadmin)")
    p.add_argument("--password", default="RsLabPass123", help="password")
    p.add_argument("--auth-source", default="admin")
    p.add_argument("--no-auth", action="store_true", help="connect without credentials")
    p.add_argument("--interval", type=float, default=30, help="seconds between samples (default 30)")
    p.add_argument("--count", type=int, default=0, help="stop after N samples (default: run until Ctrl+C)")
    p.add_argument("--log", default="metrics.log", help="log file (default metrics.log)")
    p.add_argument("--cache-threshold", type=float, default=80.0,
                   help="WARNING if the cache hit ratio is below this percent (default 80)")
    p.add_argument("--lag-threshold", type=float, default=10.0,
                   help="WARNING if replication lag exceeds this many seconds (default 10)")
    p.add_argument("--webhook", help="URL that receives a JSON POST for every alert")
    p.add_argument("--demo-load", action="store_true",
                   help="run a small background workload so the opcounters move")
    return p.parse_args()


def make_client(args):
    kwargs = {"serverSelectionTimeoutMS": 8000}
    if not args.no_auth:
        kwargs.update(username=args.user, password=args.password, authSource=args.auth_source)
    return MongoClient(args.uri, **kwargs)


# --------------------------------------------------------------- collection
def collect_server_status(client):
    ss = client.admin.command("serverStatus")
    conn = ss.get("connections", {})
    ops = ss.get("opcounters", {})
    cache = ss.get("wiredTiger", {}).get("cache", {})

    requested = cache.get("pages requested from the cache", 0)
    read_in = cache.get("pages read into cache", 0)
    if requested >= MIN_CACHE_REQUESTS:
        hit_ratio = 100.0 * (1 - read_in / requested)
    else:
        hit_ratio = None   # not enough requests yet to judge

    return {
        "host": ss.get("host", "?"),
        "version": ss.get("version", "?"),
        "uptime": ss.get("uptime", 0),
        "connections": {
            "current": conn.get("current", 0),
            "available": conn.get("available", 0),
            "active": conn.get("active", 0),
            "totalCreated": conn.get("totalCreated", 0),
        },
        "opcounters": {name: ops.get(name, 0) for name in OPCOUNTER_NAMES},
        "cache": {
            "used_bytes": cache.get("bytes currently in the cache", 0),
            "max_bytes": cache.get("maximum bytes configured", 0),
            "dirty_bytes": cache.get("tracked dirty bytes in the cache", 0),
            "requested": requested,
            "read_in": read_in,
            "hit_ratio": hit_ratio,
        },
    }


def collect_replication(client):
    """Return a list of member dicts, or None if this server is not a replica set member."""
    try:
        status = client.admin.command("replSetGetStatus")
    except OperationFailure as exc:
        if exc.code == 76 or "not running with --replSet" in str(exc):   # NoReplicationEnabled
            return None
        raise

    members = status.get("members", [])
    primary = next((m for m in members if m.get("stateStr") == "PRIMARY"), None)
    rows = []
    for m in members:
        if m.get("health", 0) != 1 or primary is None:
            lag = None
        elif m is primary:
            lag = 0.0
        else:
            lag = (primary["optimeDate"] - m["optimeDate"]).total_seconds()
        rows.append({"name": m["name"], "state": m.get("stateStr", "?"),
                     "health": m.get("health", 0), "lag": lag})
    return rows


# --------------------------------------------------------------- formatting
def fmt_table(headers, rows):
    """Render a simple ASCII table."""
    rows = [[str(c) for c in r] for r in rows]
    widths = [max(len(h), *(len(r[i]) for r in rows)) if rows else len(h)
              for i, h in enumerate(headers)]
    line = "+" + "+".join("-" * (w + 2) for w in widths) + "+"

    def fmt_row(cells):
        return "| " + " | ".join(c.ljust(w) for c, w in zip(cells, widths)) + " |"

    return "\n".join([line, fmt_row(headers), line, *(fmt_row(r) for r in rows), line])


def build_report(stamp, uri, status, repl, previous, elapsed):
    out = []
    out.append(f"===== MongoDB metrics  {stamp}  ({uri}) =====")
    out.append(f"Server {status['host']}, version {status['version']}, uptime {status['uptime']:.0f} s")

    out.append("\nConnections")
    c = status["connections"]
    out.append(fmt_table(["Current", "Available", "Active", "Total created"],
                         [[c["current"], c["available"], c["active"], c["totalCreated"]]]))

    out.append("\nOpcounters")
    rows = []
    for name in OPCOUNTER_NAMES:
        total = status["opcounters"][name]
        if previous and elapsed > 0:
            rate = f"{max(total - previous['opcounters'][name], 0) / elapsed:.1f}"
        else:
            rate = "-"
        rows.append([name, total, rate])
    out.append(fmt_table(["Operation", "Total since start", "Per second"], rows))

    out.append("\nWiredTiger cache")
    ca = status["cache"]
    used_pct = 100.0 * ca["used_bytes"] / ca["max_bytes"] if ca["max_bytes"] else 0.0
    hit = f"{ca['hit_ratio']:.1f} %" if ca["hit_ratio"] is not None else "n/a (too few requests)"
    out.append(fmt_table(
        ["Used (MB)", "Max (MB)", "Used %", "Dirty (MB)", "Pages requested", "Pages read in", "Hit ratio"],
        [[f"{ca['used_bytes'] / MB:.1f}", f"{ca['max_bytes'] / MB:.1f}", f"{used_pct:.1f}",
          f"{ca['dirty_bytes'] / MB:.2f}", ca["requested"], ca["read_in"], hit]]))

    out.append("\nReplica set")
    if repl is None:
        out.append("Not a replica set member (standalone server).")
    else:
        out.append(fmt_table(
            ["Member", "State", "Health", "Lag behind primary (s)"],
            [[m["name"], m["state"], m["health"],
              "n/a" if m["lag"] is None else f"{m['lag']:.1f}"] for m in repl]))
    return "\n".join(out)


# ----------------------------------------------------------------- alerting
def check_alerts(status, repl, cache_threshold, lag_threshold):
    alerts = []
    ratio = status["cache"]["hit_ratio"]
    if ratio is not None and ratio < cache_threshold:
        alerts.append(f"WARNING: cache hit ratio {ratio:.1f}% is below {cache_threshold:g}%")
    for m in repl or []:
        if m["lag"] is not None and m["lag"] > lag_threshold:
            alerts.append(f"WARNING: replication lag of {m['name']} is {m['lag']:.1f} s "
                          f"(limit {lag_threshold:g} s)")
        if m["health"] != 1:
            alerts.append(f"WARNING: replica set member {m['name']} is unhealthy (state {m['state']})")
    return alerts


def send_webhook(url, alerts, host):
    """Extension: POST the alerts as JSON. Errors are reported, never raised."""
    payload = {"text": "MongoDB alert on " + host, "alerts": alerts,
               "time": datetime.now().isoformat(timespec="seconds")}
    try:
        request = urllib.request.Request(
            url, data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"}, method="POST")
        with urllib.request.urlopen(request, timeout=10) as response:
            print(f"(webhook answered HTTP {response.status})")
    except Exception as exc:  # noqa: BLE001 - a broken webhook must not stop monitoring
        print(f"(webhook failed: {exc})")


# -------------------------------------------------------------- demo traffic
def start_demo_load(client, stop):
    """Small background workload so the opcounters change between samples."""
    def worker():
        coll = client["chapter-14"]["events"]
        n = 0
        while not stop.is_set():
            try:
                coll.insert_one({"n": n, "t": time.time()})
                coll.find_one({"n": n})
                n += 1
            except PyMongoError:
                time.sleep(1)
            time.sleep(0.05)
    threading.Thread(target=worker, daemon=True).start()


# --------------------------------------------------------------------- main
def main():
    args = parse_args()
    client = make_client(args)
    try:
        client.admin.command("ping")
    except PyMongoError as exc:
        hint = "Is MongoDB running? For a server without authentication add --no-auth."
        if getattr(exc, "code", None) == 18:   # AuthenticationFailed
            hint = ("The server rejected the login. Either another MongoDB (for example the Windows\n"
                    "MongoDB service) is answering on this port, or this server has no user "
                    f"'{args.user}' yet.")
        sys.exit(f"Could not connect to {args.uri}: {exc}\n{hint}")

    stop = threading.Event()
    if args.demo_load:
        start_demo_load(client, stop)
        print("Background demo traffic started.")

    print(f"Monitoring {args.uri} every {args.interval:g} s, logging to {args.log} "
          f"(Ctrl+C to stop)\n")

    previous, previous_time = None, None
    try:
        with open(args.log, "a", encoding="utf-8") as log:
            for i in count(1):
                started = time.monotonic()
                stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                try:
                    status = collect_server_status(client)
                    repl = collect_replication(client)
                except PyMongoError as exc:
                    message = f"{stamp} ERROR: could not read metrics: {exc}"
                    print(message)
                    log.write(message + "\n")
                    log.flush()
                else:
                    elapsed = (time.monotonic() - previous_time) if previous_time else 0
                    report = build_report(stamp, args.uri, status, repl, previous, elapsed)
                    alerts = check_alerts(status, repl, args.cache_threshold, args.lag_threshold)
                    block = report + ("\n\n" + "\n".join(alerts) if alerts else "\n\nNo alerts.") + "\n"
                    print(block)
                    log.write(block + "\n")
                    log.flush()
                    if alerts and args.webhook:
                        send_webhook(args.webhook, alerts, status["host"])
                    previous, previous_time = status, time.monotonic()

                if args.count and i >= args.count:
                    break
                time.sleep(max(args.interval - (time.monotonic() - started), 0))
    except KeyboardInterrupt:
        print("\nStopped by user.")
    finally:
        stop.set()
        client.close()
    print(f"Log written to {args.log}")


if __name__ == "__main__":
    main()
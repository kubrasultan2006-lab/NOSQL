"""
Lab 9.2: Simulate a Network Partition

Usage (from the pymongo-quickstart folder, with the 3-node replica set from
Chapter 8 running and healthy):

    python "chapter-09/Lab 9.2 - Simulate a network partition.py" --base-port 28017

What it does:
  1. Finds the 3 members (base-port, base-port+1, base-port+2) and their Docker containers.
  2. Starts a background observer that polls every member each second and logs role changes.
  3. Phase 1: disconnects ONE secondary, then inserts with w:1 and w:majority (both should succeed).
  4. Phase 2: disconnects the SECOND secondary, then tries w:majority (should time out)
     and waits for the primary to step down (replica set becomes read-only).
  5. Waits until the partition has lasted --partition-seconds, reconnects both secondaries,
     waits for a primary to be elected, and counts documents on every member (catch-up check).
  6. Prints the timeline and saves it to lab-9.2-timeline.txt.

Requires: pip install pymongo
"""

import argparse
import json
import subprocess
import threading
import time
from datetime import datetime, timezone

from pymongo import MongoClient
from pymongo.errors import PyMongoError
from pymongo.read_preferences import ReadPreference
from pymongo.write_concern import WriteConcern

DB_NAME = "chapter-09"
COLL_NAME = "partition_test"

START = time.time()
TIMELINE = []
LOCK = threading.Lock()


def log(msg):
    """Print a message with seconds since script start and keep it for the timeline."""
    elapsed = time.time() - START
    line = f"[{elapsed:7.2f}s] {msg}"
    with LOCK:
        TIMELINE.append(line)
        print(line, flush=True)


# --------------------------------------------------------------------------- docker helpers
def docker(*args):
    result = subprocess.run(["docker", *args], capture_output=True, text=True)
    if result.returncode != 0:
        raise RuntimeError(f"docker {' '.join(args)} failed: {result.stderr.strip()}")
    return result.stdout.strip()


def find_container(port):
    """Return (container_id, container_name) of the container publishing the given host port."""
    out = docker("ps", "--format", "{{.ID}}\t{{.Names}}\t{{.Ports}}")
    for line in out.splitlines():
        cid, name, ports = line.split("\t")
        if f":{port}->" in ports:
            return cid, name
    raise RuntimeError(f"No running container publishes host port {port}. Is the replica set up?")


def container_networks(container_id):
    info = json.loads(docker("inspect", container_id))[0]
    return info["NetworkSettings"]["Networks"]


def disconnect(member, network):
    member["aliases"] = container_networks(member["id"]).get(network, {}).get("Aliases") or []
    docker("network", "disconnect", network, member["id"])
    member["disconnected"] = True
    log(f"PARTITION: disconnected {member['name']} ({member['id']}, port {member['port']}) from {network}")


def reconnect(member, network):
    cmd = ["network", "connect"]
    for alias in member.get("aliases", []):
        cmd += ["--alias", alias]
    cmd += [network, member["id"]]
    docker(*cmd)
    member["disconnected"] = False
    log(f"HEALED: reconnected {member['name']} ({member['id']}, port {member['port']}) to {network}")


# --------------------------------------------------------------------------- mongo helpers
def client_for(port, timeout_ms=1500):
    return MongoClient(
        "localhost",
        port,
        directConnection=True,
        serverSelectionTimeoutMS=timeout_ms,
        connectTimeoutMS=timeout_ms,
    )


def role_of(port):
    """Return PRIMARY, SECONDARY, OTHER or UNREACHABLE for the member on this port."""
    c = client_for(port, 1000)
    try:
        hello = c.admin.command("hello")
        if hello.get("isWritablePrimary"):
            return "PRIMARY"
        if hello.get("secondary"):
            return "SECONDARY"
        return "OTHER"
    except PyMongoError:
        return "UNREACHABLE"
    finally:
        c.close()


def find_primary(members):
    for m in members:
        if role_of(m["port"]) == "PRIMARY":
            return m
    return None


def wait_for(predicate, timeout, interval=1.0):
    """Poll predicate() until it returns something truthy or the timeout expires."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        value = predicate()
        if value:
            return value
        time.sleep(interval)
    return None


class Observer(threading.Thread):
    """Polls every member once per second and logs whenever a member's state changes."""

    def __init__(self, members):
        super().__init__(daemon=True)
        self.members = members
        self.stop_event = threading.Event()
        self.last = {}

    def run(self):
        while not self.stop_event.is_set():
            for m in self.members:
                state = role_of(m["port"])
                if self.last.get(m["port"]) != state:
                    log(f"OBSERVER: {m['name']} (port {m['port']}) -> {state}")
                    self.last[m["port"]] = state
            self.stop_event.wait(1.0)

    def stop(self):
        self.stop_event.set()


def timed_insert(port, label, w, count=3, wtimeout_ms=5000):
    """Insert `count` documents with write concern w. Log success/failure and latency each time."""
    results = []
    for i in range(count):
        c = client_for(port, 3000)
        coll = c[DB_NAME].get_collection(COLL_NAME, write_concern=WriteConcern(w=w, wtimeout=wtimeout_ms))
        doc = {"phase": label, "w": str(w), "i": i, "at": datetime.now(timezone.utc)}
        t0 = time.time()
        try:
            coll.insert_one(doc)
            outcome = "SUCCESS"
        except PyMongoError as exc:
            outcome = f"FAILED ({type(exc).__name__})"
        finally:
            c.close()
        ms = (time.time() - t0) * 1000
        log(f"INSERT [{label}] w:{w} #{i + 1}: {outcome} in {ms:.0f} ms")
        results.append(outcome)
    return results


def count_docs(port):
    c = client_for(port, 3000)
    try:
        coll = c[DB_NAME].get_collection(COLL_NAME, read_preference=ReadPreference.SECONDARY_PREFERRED)
        return coll.count_documents({})
    except PyMongoError as exc:
        return f"error ({type(exc).__name__})"
    finally:
        c.close()


# --------------------------------------------------------------------------- main lab
def main():
    parser = argparse.ArgumentParser(description="Lab 9.2: simulate a network partition")
    parser.add_argument("--base-port", type=int, default=28017, help="host port of the first member")
    parser.add_argument("--network", default=None, help="Docker network name (auto-detected if omitted)")
    parser.add_argument("--partition-seconds", type=int, default=30, help="minimum partition duration")
    parser.add_argument("--wtimeout-ms", type=int, default=5000, help="write concern timeout")
    args = parser.parse_args()

    # 1. Discover members
    members = []
    for offset in range(3):
        port = args.base_port + offset
        cid, name = find_container(port)
        members.append({"port": port, "id": cid, "name": name, "disconnected": False})
    network = args.network or next(iter(container_networks(members[0]["id"])))
    log(f"Members: {[(m['name'], m['port']) for m in members]}  network: {network}")

    primary = find_primary(members)
    if primary is None:
        raise SystemExit("No primary found. Make sure the replica set is healthy first (rs.status()).")
    secondaries = [m for m in members if m is not primary]
    log(f"Healthy replica set. Primary: {primary['name']} (port {primary['port']})")

    observer = Observer(members)
    observer.start()
    time.sleep(2)

    partition_started = None
    stepdown_seen_at = None
    try:
        # 2. Phase 1: isolate one secondary (primary + 1 secondary still form a majority)
        partition_started = time.time()
        disconnect(secondaries[0], network)
        time.sleep(3)
        log("Phase 1: one secondary partitioned; majority (2 of 3) is still available")
        timed_insert(primary["port"], "phase1", 1, wtimeout_ms=args.wtimeout_ms)
        timed_insert(primary["port"], "phase1", "majority", wtimeout_ms=args.wtimeout_ms)

        # 3. Phase 2: isolate the second secondary (primary alone, no majority)
        disconnect(secondaries[1], network)
        t_second = time.time()
        log("Phase 2: both secondaries partitioned; the primary has no majority")
        timed_insert(primary["port"], "phase2", "majority", count=1, wtimeout_ms=args.wtimeout_ms)

        # Primary steps down after it fails to reach a majority (about one election timeout, ~10 s)
        log("Waiting for the primary to step down ...")
        stepped = wait_for(lambda: role_of(primary["port"]) != "PRIMARY", timeout=40)
        if stepped:
            stepdown_seen_at = time.time()
            log(f"PRIMARY STEPPED DOWN {stepdown_seen_at - t_second:.1f} s after the second disconnect")
            timed_insert(primary["port"], "phase2-readonly", 1, count=1, wtimeout_ms=args.wtimeout_ms)
        else:
            log("Primary did not step down within 40 s (check electionTimeoutMillis / checkQuorum)")

        # 4. Keep the partition for at least --partition-seconds
        remaining = args.partition_seconds - (time.time() - partition_started)
        if remaining > 0:
            log(f"Holding the partition for another {remaining:.0f} s ...")
            time.sleep(remaining)
    finally:
        # 5. Heal the partition no matter what happened above
        for m in members:
            if m["disconnected"]:
                try:
                    reconnect(m, network)
                except RuntimeError as exc:
                    log(f"Could not reconnect {m['name']}: {exc}")
        healed_at = time.time()

    # 6. Watch the replica set recover
    log("Waiting for an election and for all members to rejoin ...")
    new_primary = wait_for(lambda: find_primary(members), timeout=60)
    if new_primary:
        log(f"ELECTED: {new_primary['name']} (port {new_primary['port']}) is primary "
            f"{time.time() - healed_at:.1f} s after healing")
        if new_primary is primary:
            log("The former primary regained its role.")
        else:
            log("A different member became primary.")
    else:
        log("No primary elected within 60 s")

    wait_for(lambda: all(role_of(m["port"]) in ("PRIMARY", "SECONDARY") for m in members), timeout=60)
    log("All members are reachable again")

    # Give the secondaries a moment to finish replication, then compare document counts
    time.sleep(5)
    for m in members:
        log(f"Document count on {m['name']} (port {m['port']}): {count_docs(m['port'])}")

    observer.stop()
    observer.join(timeout=3)

    # 7. Timeline
    print("\n=== Lab 9.2 timeline ===")
    with LOCK:
        text = "\n".join(TIMELINE)
    print(text)
    with open("lab-9.2-timeline.txt", "w", encoding="utf-8") as f:
        f.write(text + "\n")
    print("\nSaved to lab-9.2-timeline.txt")


if __name__ == "__main__":
    main()
r"""
Lab 9.1: Measure Write Concern Latency
Prerequisite: running replica set from Lab 8.1 (rs0, ports 28017-28019).

Inserts 1,000 documents one at a time with each write concern and measures
total time and per-write latency:

    w:1         primary only acknowledges
    w:majority  a majority of voting members acknowledge
    w:all       EVERY data-bearing member acknowledges
                (MongoDB has no literal "w: all": use w = number of
                 data-bearing members; arbiters cannot acknowledge writes)

Usage (from the repo root):
    python chapter-09\lab9_1_write_concern_latency.py --base-port 28017
    python chapter-09\lab9_1_write_concern_latency.py --count 500 --keep
"""
import argparse
import statistics
import sys
import time

from pymongo import MongoClient
from pymongo.errors import PyMongoError
from pymongo.write_concern import WriteConcern

try:
    from rich.console import Console
    from rich.table import Table
    console = Console()
except ImportError:
    console = None

HOST = "host.docker.internal"
REPLSET = "rs0"
WARMUP = 50


def show(title, headers, rows):
    if console:
        t = Table(title=title, show_lines=True)
        for h in headers:
            t.add_column(h)
        for r in rows:
            t.add_row(*[str(c) for c in r])
        console.print(t)
    else:
        print(f"\n{title}")
        print(" | ".join(headers))
        for r in rows:
            print(" | ".join(str(c) for c in r))


def percentile(sorted_vals, pct):
    idx = min(len(sorted_vals) - 1, int(round(pct / 100 * (len(sorted_vals) - 1))))
    return sorted_vals[idx]


def measure(db, name, wc, count):
    """Insert `count` docs one by one; return list of per-write latencies (ms)."""
    coll = db[f"lab91_{name}"].with_options(write_concern=wc)
    coll.drop()
    for i in range(WARMUP):                       # warm up connections/cache
        coll.insert_one({"warmup": i})
    coll.delete_many({})

    latencies = []
    t_total = time.perf_counter()
    for i in range(count):
        doc = {"_id": i, "concern": name, "payload": "x" * 100}
        t0 = time.perf_counter()
        coll.insert_one(doc)                      # blocks until acknowledged
        latencies.append((time.perf_counter() - t0) * 1000)
    total = time.perf_counter() - t_total
    return total, latencies


def main(argv=None):
    ap = argparse.ArgumentParser(description="Lab 9.1")
    ap.add_argument("--base-port", type=int, default=28017)
    ap.add_argument("--count", type=int, default=1000)
    ap.add_argument("--keep", action="store_true",
                    help="keep the test collections afterwards")
    args = ap.parse_args(argv)

    hosts = ",".join(f"{HOST}:{args.base_port + i}" for i in range(3))
    client = MongoClient(f"mongodb://{hosts}/?replicaSet={REPLSET}",
                         serverSelectionTimeoutMS=5000)
    try:
        cfg = client.admin.command("replSetGetConfig")["config"]
    except PyMongoError as e:
        print(f"Cannot reach the replica set: {e}")
        return 1

    members = cfg["members"]
    data_nodes = [m for m in members if not m.get("arbiterOnly")]
    voting = [m for m in members if m.get("votes", 1) > 0]
    n_all = len(data_nodes)
    n_major = len(voting) // 2 + 1

    show("Replica set", ["Item", "Value"], [
        ("Members", len(members)),
        ("Data-bearing members", n_all),
        ("Voting members", len(voting)),
        ("Acks for w:majority", n_major),
        ("Acks for w:all (= every data-bearing member)", n_all),
    ])

    concerns = [
        ("w:1", 1, 1),
        ("w:majority", "majority", n_major),
        ("w:all", n_all, n_all),
    ]
    db = client["chapter-09"]
    results = []
    for label, w, acks in concerns:
        print(f"Running {args.count} inserts with {label} ...", flush=True)
        wc = WriteConcern(w=w, wtimeout=15000)
        try:
            total, lat = measure(db, label.replace(":", ""), wc, args.count)
        except PyMongoError as e:
            print(f"  {label} failed: {e}")
            return 1
        lat_sorted = sorted(lat)
        results.append({
            "label": label, "acks": acks, "total": total,
            "avg": statistics.mean(lat),
            "median": statistics.median(lat),
            "p95": percentile(lat_sorted, 95),
            "max": lat_sorted[-1],
            "ops": args.count / total,
        })

    base = results[0]["avg"]
    show(f"Lab 9.1 - Write concern latency ({args.count} inserts each)",
         ["Write concern", "Acks needed", "Total (s)", "Avg / write (ms)",
          "Median (ms)", "p95 (ms)", "Max (ms)", "Writes/s", "vs w:1"],
         [(r["label"], r["acks"], f"{r['total']:.2f}", f"{r['avg']:.2f}",
           f"{r['median']:.2f}", f"{r['p95']:.2f}", f"{r['max']:.2f}",
           f"{r['ops']:.0f}", f"{r['avg'] / base:.2f}x") for r in results])

    show("Why the results differ", ["Concern", "What the write waits for"], [
        ("w:1", "Only the primary applies the write. No network round trip "
                "to secondaries, lowest latency. If the primary fails before "
                "replication, the write can be rolled back."),
        ("w:majority", "The primary plus enough secondaries to form a "
                       "majority must have the write. Adds at least one "
                       "replication round trip. Survives a failover; the "
                       "usual safe default."),
        ("w:all", "Every data-bearing member must acknowledge, so latency "
                  "follows the SLOWEST member. Strongest durability, but if "
                  "any member is down the write blocks until wtimeout."),
    ])
    show("Next", ["Next", "Command / value"], [
        ("Inspect the data", "docker exec -it chapter-09-mongo1 mongosh "
                             "--eval \"db.getSiblingDB('chapter-09').getCollectionNames()\""),
        ("Re-run with more writes",
         "python chapter-09\\lab9_1_write_concern_latency.py --count 5000"),
    ])

    if not args.keep:
        for label, _, _ in concerns:
            db[f"lab91_{label.replace(':', '')}"].drop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
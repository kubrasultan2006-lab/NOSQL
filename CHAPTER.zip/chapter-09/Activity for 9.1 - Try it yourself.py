r"""
Activity for 9.1: Try it yourself
Repeat the Lab 9.1 experiment with j:true and j:false for each write concern.
Does journaling add significant latency?

Prerequisite: running replica set from Lab 8.1 (rs0, ports 28017-28019).

Usage (from the repo root):
    python "chapter-09\Activity for 9.1 - Try it yourself.py" --base-port 28017
    python "chapter-09\Activity for 9.1 - Try it yourself.py" --count 2000 --rounds 3
"""
import argparse
import statistics
import sys
import time

from pymongo import MongoClient
from pymongo.errors import PyMongoError
from pymongo.write_concern import WriteConcern

try:
    from rich.console import Console
    from rich.table import Table
    console = Console()
except ImportError:
    console = None

HOST = "host.docker.internal"
REPLSET = "rs0"
WARMUP = 50
# "Significant" = journaling costs more than this much, in BOTH ms and percent
SIG_MS = 0.5
SIG_PCT = 25.0


def show(title, headers, rows):
    if console:
        t = Table(title=title, show_lines=True)
        for h in headers:
            t.add_column(h)
        for r in rows:
            t.add_row(*[str(c) for c in r])
        console.print(t)
    else:
        print(f"\n{title}")
        print(" | ".join(headers))
        for r in rows:
            print(" | ".join(str(c) for c in r))


def percentile(sorted_vals, pct):
    idx = min(len(sorted_vals) - 1, int(round(pct / 100 * (len(sorted_vals) - 1))))
    return sorted_vals[idx]


def measure(db, name, wc, count):
    coll = db[f"act91_{name}"].with_options(write_concern=wc)
    coll.drop()
    for i in range(WARMUP):
        coll.insert_one({"warmup": i})
    coll.delete_many({})

    lat = []
    t_total = time.perf_counter()
    for i in range(count):
        t0 = time.perf_counter()
        coll.insert_one({"_id": i, "payload": "x" * 100})
        lat.append((time.perf_counter() - t0) * 1000)
    return time.perf_counter() - t_total, lat


def main(argv=None):
    ap = argparse.ArgumentParser(description="Activity for 9.1")
    ap.add_argument("--base-port", type=int, default=28017)
    ap.add_argument("--count", type=int, default=1000)
    ap.add_argument("--rounds", type=int, default=1,
                    help="repeat the whole experiment and pool the latencies")
    ap.add_argument("--keep", action="store_true")
    args = ap.parse_args(argv)

    hosts = ",".join(f"{HOST}:{args.base_port + i}" for i in range(3))
    client = MongoClient(f"mongodb://{hosts}/?replicaSet={REPLSET}",
                         serverSelectionTimeoutMS=5000)
    try:
        cfg = client.admin.command("replSetGetConfig")["config"]
    except PyMongoError as e:
        print(f"Cannot reach the replica set: {e}")
        return 1

    members = cfg["members"]
    n_all = len([m for m in members if not m.get("arbiterOnly")])
    concerns = [("w:1", 1), ("w:majority", "majority"), ("w:all", n_all)]
    journals = [False, True]                      # j:false first, then j:true

    db = client["chapter-09"]
    data = {}                                     # (concern, j) -> latencies/total
    for rnd in range(1, args.rounds + 1):
        for label, w in concerns:
            for j in journals:
                key = (label, j)
                print(f"Round {rnd}/{args.rounds}: {args.count} inserts with "
                      f"{label}, j:{str(j).lower()} ...", flush=True)
                wc = WriteConcern(w=w, j=j, wtimeout=15000)
                try:
                    total, lat = measure(db, f"{label.replace(':', '')}_{j}",
                                         wc, args.count)
                except PyMongoError as e:
                    print(f"  failed: {e}")
                    return 1
                d = data.setdefault(key, {"total": 0.0, "lat": []})
                d["total"] += total
                d["lat"].extend(lat)

    n_writes = args.count * args.rounds
    rows, summary, any_sig = [], [], False
    for label, _ in concerns:
        avg = {}
        for j in journals:
            d = data[(label, j)]
            lat = sorted(d["lat"])
            avg[j] = statistics.mean(lat)
            rows.append((label, f"j:{str(j).lower()}", f"{d['total']:.2f}",
                         f"{avg[j]:.2f}", f"{statistics.median(lat):.2f}",
                         f"{percentile(lat, 95):.2f}", f"{lat[-1]:.2f}",
                         f"{n_writes / d['total']:.0f}"))
        diff = avg[True] - avg[False]
        pct = diff / avg[False] * 100 if avg[False] else 0.0
        sig = diff > SIG_MS and pct > SIG_PCT
        any_sig = any_sig or sig
        summary.append((label, f"{avg[False]:.2f}", f"{avg[True]:.2f}",
                        f"{diff:+.2f}", f"{pct:+.0f}%",
                        "YES" if sig else "no"))

    show(f"Activity for 9.1 - latency by write concern and journaling "
         f"({n_writes} inserts each)",
         ["Write concern", "Journal", "Total (s)", "Avg / write (ms)",
          "Median (ms)", "p95 (ms)", "Max (ms)", "Writes/s"], rows)

    show("Journaling overhead (j:true minus j:false)",
         ["Write concern", "Avg j:false (ms)", "Avg j:true (ms)",
          "Overhead (ms)", "Overhead (%)",
          f"Significant? (> {SIG_MS} ms and > {SIG_PCT:.0f}%)"], summary)

    show("How to read it", ["Point", "Explanation"], [
        ("j:false", "Acknowledged once the write is applied in memory; the "
                    "journal is flushed later (default every 100 ms)."),
        ("j:true", "Acknowledged only after the write is in the on-disk "
                   "journal, so the write survives a mongod crash. Costs one "
                   "disk flush (fsync) on each member that must acknowledge."),
        ("Where it matters", "Mostly w:1, where journaling is the only extra "
                             "wait. With w:majority / w:all the replication "
                             "round trip already dominates, so the added "
                             "relative cost is smaller."),
        ("Caveat", "Since MongoDB 5.0, w:majority is journaled by default "
                   "(writeConcernMajorityJournalDefault), so an explicit "
                   "j:false vs j:true gap can be small there. Results depend "
                   "on your disk (Docker Desktop on Windows uses a VM disk)."),
    ])
    print("\nConclusion from THIS run: journaling "
          + ("adds significant latency for at least one write concern."
             if any_sig else
             "did not add significant latency for any write concern."))

    show("Next", ["Next", "Command / value"], [
        ("More reliable numbers",
         "python \"chapter-09\\Activity for 9.1 - Try it yourself.py\" "
         "--count 2000 --rounds 3"),
        ("Inspect the data", "docker exec -it chapter-09-mongo1 mongosh "
                             "--eval \"db.getSiblingDB('chapter-09').getCollectionNames()\""),
    ])

    if not args.keep:
        for label, _ in concerns:
            for j in journals:
                db[f"act91_{label.replace(':', '')}_{j}"].drop()
    return 0


if __name__ == "__main__":
    sys.exit(main())
    
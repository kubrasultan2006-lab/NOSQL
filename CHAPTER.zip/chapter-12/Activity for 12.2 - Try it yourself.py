"""
Activity 12.2 - TLS / Encryption-in-Transit for MongoDB

What this script does
  1. Generates a certificate chain with the `cryptography` library:
       CA (self-signed)  ->  server cert (SAN: localhost, 127.0.0.1)
                         ->  client cert (clientAuth)
  2. Starts a MongoDB container "mongo-tls" on port 27019 with
       --tlsMode requireTLS --tlsCertificateKeyFile --tlsCAFile
  3. Documents the certificate chain (subject, issuer, validity, SAN, serial,
     fingerprint, signature check).
  4. Prints the negotiated TLS version and cipher.
  5. Runs a PASS/FAIL table:
       - plain (non-TLS) connection is rejected
       - TLS without a client certificate is rejected
       - TLS with the wrong CA is rejected
       - TLS with the right CA + client certificate works (insert + find)

Requirements:  pip install pymongo cryptography     (Docker must be running)
Run:           python "chapter-12\\Activity for 12.2 - Try it yourself.py"
Clean up:      python "chapter-12\\Activity for 12.2 - Try it yourself.py" --cleanup
"""

import datetime
import ipaddress
import socket
import ssl
import subprocess
import sys
import time
from pathlib import Path

from cryptography import x509
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.x509.oid import ExtendedKeyUsageOID, NameOID
from pymongo import MongoClient

CONTAINER = "mongo-tls"
PORT = 27029
IMAGE = "mongo:7"
CERT_DIR = Path(__file__).resolve().parent / "tls-certs"
DB_NAME = "chapter-12"

# ---------------------------------------------------------------- certificates
def new_key():
    return rsa.generate_private_key(public_exponent=65537, key_size=2048)


def name(cn):
    return x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, cn)])


def write_key(path, key):
    path.write_bytes(key.private_bytes(
        serialization.Encoding.PEM,
        serialization.PrivateFormat.TraditionalOpenSSL,
        serialization.NoEncryption()))


def write_cert(path, cert):
    path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))


def build_cert(subject_cn, issuer_cn, pub, signing_key, days, is_ca=False,
               san=None, client_auth=False, server_auth=False):
    now = datetime.datetime.now(datetime.timezone.utc)
    # Python 3.13+ verifies certificates in strict mode: every certificate needs
    # a Subject Key Identifier + Authority Key Identifier, and a CA needs
    # keyCertSign in its Key Usage.
    b = (x509.CertificateBuilder()
         .subject_name(name(subject_cn))
         .issuer_name(name(issuer_cn))
         .public_key(pub)
         .serial_number(x509.random_serial_number())
         .not_valid_before(now - datetime.timedelta(minutes=5))
         .not_valid_after(now + datetime.timedelta(days=days))
         .add_extension(x509.BasicConstraints(ca=is_ca, path_length=None), critical=True)
         .add_extension(x509.SubjectKeyIdentifier.from_public_key(pub), critical=False)
         .add_extension(
             x509.AuthorityKeyIdentifier.from_issuer_public_key(signing_key.public_key()),
             critical=False)
         .add_extension(
             x509.KeyUsage(
                 digital_signature=True,
                 content_commitment=False,
                 key_encipherment=not is_ca,
                 data_encipherment=False,
                 key_agreement=False,
                 key_cert_sign=is_ca,
                 crl_sign=is_ca,
                 encipher_only=False,
                 decipher_only=False),
             critical=True))
    if san:
        b = b.add_extension(x509.SubjectAlternativeName(san), critical=False)
    usages = []
    if server_auth:
        usages.append(ExtendedKeyUsageOID.SERVER_AUTH)
    if client_auth:
        usages.append(ExtendedKeyUsageOID.CLIENT_AUTH)
    if usages:
        b = b.add_extension(x509.ExtendedKeyUsage(usages), critical=False)
    return b.sign(signing_key, hashes.SHA256())


def generate_certs():
    CERT_DIR.mkdir(exist_ok=True)

    ca_key = new_key()
    ca_crt = build_cert("MongoDB-CA", "MongoDB-CA", ca_key.public_key(), ca_key,
                        365, is_ca=True)

    srv_key = new_key()
    srv_crt = build_cert(
        "mongodb", "MongoDB-CA", srv_key.public_key(), ca_key, 365, server_auth=True,
        san=[x509.DNSName("localhost"), x509.DNSName("mongodb"),
             x509.IPAddress(ipaddress.ip_address("127.0.0.1"))])

    cli_key = new_key()
    cli_crt = build_cert("pymongo-client", "MongoDB-CA", cli_key.public_key(),
                         ca_key, 365, client_auth=True)

    # a second, unrelated CA used to prove that a wrong CA is rejected
    bad_key = new_key()
    bad_crt = build_cert("Untrusted-CA", "Untrusted-CA", bad_key.public_key(),
                         bad_key, 365, is_ca=True)

    write_key(CERT_DIR / "ca.key", ca_key)
    write_cert(CERT_DIR / "ca.crt", ca_crt)
    write_key(CERT_DIR / "server.key", srv_key)
    write_cert(CERT_DIR / "server.crt", srv_crt)
    write_key(CERT_DIR / "client.key", cli_key)
    write_cert(CERT_DIR / "client.crt", cli_crt)
    write_cert(CERT_DIR / "wrong-ca.crt", bad_crt)

    # mongod wants key + certificate in one PEM file
    (CERT_DIR / "server.pem").write_bytes(
        (CERT_DIR / "server.key").read_bytes() + (CERT_DIR / "server.crt").read_bytes())
    (CERT_DIR / "client.pem").write_bytes(
        (CERT_DIR / "client.key").read_bytes() + (CERT_DIR / "client.crt").read_bytes())
    return ca_crt, srv_crt, cli_crt


def describe_chain(ca_crt, srv_crt, cli_crt):
    print("\n=== Certificate chain documentation ===")
    for label, c in (("CA", ca_crt), ("Server", srv_crt), ("Client", cli_crt)):
        print(f"\n[{label}]")
        print("  Subject    :", c.subject.rfc4514_string())
        print("  Issuer     :", c.issuer.rfc4514_string())
        print("  Serial     :", hex(c.serial_number))
        print("  Valid from :", c.not_valid_before_utc.date())
        print("  Valid to   :", c.not_valid_after_utc.date())
        print("  SHA-256    :", c.fingerprint(hashes.SHA256()).hex(":")[:47] + "...")
        try:
            san = c.extensions.get_extension_for_class(x509.SubjectAlternativeName).value
            print("  SAN        :", ", ".join(str(v.value) for v in san))
        except x509.ExtensionNotFound:
            pass

    print("\n[Signature verification against the CA public key]")
    for label, c in (("Server", srv_crt), ("Client", cli_crt)):
        try:
            ca_crt.public_key().verify(c.signature, c.tbs_certificate_bytes,
                                       padding.PKCS1v15(), c.signature_hash_algorithm)
            print(f"  {label} cert signed by MongoDB-CA : OK")
        except Exception as e:  # noqa: BLE001
            print(f"  {label} cert signed by MongoDB-CA : FAILED ({e})")
    print("\nChain:  MongoDB-CA (self-signed root)")
    print("          |-- server.crt  CN=mongodb  (SAN localhost, 127.0.0.1)")
    print("          `-- client.crt  CN=pymongo-client")


# ---------------------------------------------------------------------- docker
def run(cmd):
    return subprocess.run(cmd, capture_output=True, text=True)


def start_container():
    run(["docker", "rm", "-f", CONTAINER])
    r = run([
        "docker", "run", "-d", "--name", CONTAINER,
        "-p", f"{PORT}:27017",
        "-v", f"{CERT_DIR}:/certs:ro",
        IMAGE, "mongod",
        "--tlsMode", "requireTLS",
        "--tlsCertificateKeyFile", "/certs/server.pem",
        "--tlsCAFile", "/certs/ca.crt",
        "--bind_ip_all",
    ])
    if r.returncode != 0:
        sys.exit("Could not start the container:\n" + r.stderr)


def tls_client(**extra):
    return MongoClient(
        f"mongodb://localhost:{PORT}/", tls=True,
        tlsCAFile=str(CERT_DIR / "ca.crt"),
        tlsCertificateKeyFile=str(CERT_DIR / "client.pem"),
        serverSelectionTimeoutMS=3000, **extra)


def wait_ready(timeout=40):
    end = time.time() + timeout
    while time.time() < end:
        try:
            tls_client().admin.command("ping")
            return True
        except Exception:  # noqa: BLE001
            time.sleep(1.5)
    return False


def tls_handshake_info():
    ctx = ssl.create_default_context(cafile=str(CERT_DIR / "ca.crt"))
    ctx.load_cert_chain(CERT_DIR / "client.crt", CERT_DIR / "client.key")
    with socket.create_connection(("localhost", PORT), timeout=5) as s:
        with ctx.wrap_socket(s, server_hostname="localhost") as t:
            return t.version(), t.cipher()[0]


# ----------------------------------------------------------------------- tests
def fails(fn):
    """Return (True, error-type) if fn() raises, else (False, '')."""
    try:
        fn()
        return False, ""
    except Exception as e:  # noqa: BLE001
        return True, type(e).__name__


def main():
    if "--cleanup" in sys.argv:
        run(["docker", "rm", "-f", CONTAINER])
        print(f"Removed container {CONTAINER}.")
        return

    print("Generating certificates...")
    ca, srv, cli = generate_certs()
    describe_chain(ca, srv, cli)

    print(f"\nStarting {CONTAINER} on port {PORT} with --tlsMode requireTLS ...")
    start_container()
    if not wait_ready():
        sys.exit(f"MongoDB did not become ready. Check: docker logs {CONTAINER}")

    version, cipher = tls_handshake_info()
    print(f"\nNegotiated TLS: {version}, cipher {cipher}")

    results = []

    # 1. plain connection must be rejected
    plain = lambda: MongoClient(f"mongodb://localhost:{PORT}/",
                                serverSelectionTimeoutMS=3000).admin.command("ping")
    failed, err = fails(plain)
    results.append(("Plain (non-TLS) connection is rejected", failed, err))

    # 2. TLS but no client certificate must be rejected
    no_cert = lambda: MongoClient(
        f"mongodb://localhost:{PORT}/", tls=True,
        tlsCAFile=str(CERT_DIR / "ca.crt"),
        serverSelectionTimeoutMS=3000).admin.command("ping")
    failed, err = fails(no_cert)
    results.append(("TLS without client certificate is rejected", failed, err))

    # 3. TLS with the wrong CA must be rejected (server cert not trusted)
    wrong_ca = lambda: MongoClient(
        f"mongodb://localhost:{PORT}/", tls=True,
        tlsCAFile=str(CERT_DIR / "wrong-ca.crt"),
        tlsCertificateKeyFile=str(CERT_DIR / "client.pem"),
        serverSelectionTimeoutMS=3000).admin.command("ping")
    failed, err = fails(wrong_ca)
    results.append(("TLS with untrusted CA is rejected", failed, err))

    # 4. correct TLS connection works: insert + find
    ok_client = tls_client()
    coll = ok_client[DB_NAME]["test"]
    coll.delete_many({})
    coll.insert_one({"msg": "hello over TLS", "n": 1})
    doc = coll.find_one({"n": 1})
    results.append(("TLS + CA + client cert: find_one() works",
                    doc is not None and doc["msg"] == "hello over TLS", ""))
    results.append((f"Connection uses modern TLS ({version})",
                    version in ("TLSv1.2", "TLSv1.3"), ""))

    print("\n=== Test results ===")
    print(f"{'Check':<48} {'Result':<7} Detail")
    print("-" * 78)
    passed = 0
    for label, ok, detail in results:
        passed += ok
        print(f"{label:<48} {'PASS' if ok else 'FAIL':<7} {detail}")
    print("-" * 78)
    print(f"{passed}/{len(results)} checks passed")
    print("\nFound document:", {k: v for k, v in (doc or {}).items() if k != '_id'})
    print(f"\nCertificates are in: {CERT_DIR}")
    print("Remove the container with:  --cleanup")


if __name__ == "__main__":
    main()
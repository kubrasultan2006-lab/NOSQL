"""
Activity for 12.1: Try it yourself
Configure field-level redaction using a view that excludes a 'salary' field
for users who do not have the HR role.

Uses the same authentication-enabled MongoDB as Lab 12.1 (Docker container mongo-auth on port 27018):

    docker run -d --name mongo-auth -p 27018:27017 `
        -e MONGO_INITDB_ROOT_USERNAME=admin -e MONGO_INITDB_ROOT_PASSWORD=AdminPass123! `
        mongo:8.0 --auth

Run from the pymongo-quickstart folder:

    python "chapter-12\\Activity for 12.1 - Try it yourself.py"

What it does (database chapter-12):
  1. Creates employees (with salary) and the view employees_public, whose pipeline is
     [{$project: {salary: 0}}].
  2. Creates two roles:  hrRole    find on employees (the real collection)
                         staffRole find on employees_public (the view only)
  3. Creates users:  hr_manager (hrRole), staff_user (staffRole), and dev_user, who has the
     broad built-in read role to show the classic pitfall.
  4. Logs in as each user and prints what they can and cannot do, as a PASS/FAIL table.

Requires: pip install pymongo
"""

import argparse
import json

from pymongo import MongoClient
from pymongo.errors import OperationFailure, PyMongoError

DB = "chapter-12"
USERS = {
    "hr_manager": "HrPass123!",
    "staff_user": "StaffPass123!",
    "dev_user": "DevPass123!",
}


def heading(text):
    print(f"\n=== {text} ===")


def connect(args, user=None, password=None):
    kwargs = {"host": "localhost", "port": args.port, "serverSelectionTimeoutMS": 4000}
    if user:
        kwargs.update(username=user, password=password, authSource="admin")
    return MongoClient(**kwargs)


def attempt(fn):
    """Run fn. Returns (allowed, detail). Error code 13 means 'not authorized'."""
    try:
        return True, fn() or ""
    except OperationFailure as exc:
        if exc.code == 13:
            return False, "not authorized"
        return False, f"error {exc.code}"


def without_id(doc):
    return {k: v for k, v in doc.items() if k != "_id"}


def drop_quietly(db, command, name):
    try:
        db.command(command, name)
    except OperationFailure:
        pass


def setup(admin):
    heading("Step 1: data and the redacting view (as admin)")
    db = admin[DB]
    db.employees.drop()
    db.drop_collection("employees_public")
    db.employees.insert_many([
        {"name": "Asha", "dept": "Sales", "salary": 52000},
        {"name": "Ben", "dept": "IT", "salary": 61000},
        {"name": "Chen", "dept": "HR", "salary": 58000},
        {"name": "Dara", "dept": "IT", "salary": 75000},
    ])
    print(f"[OK] {DB}.employees: 4 documents, each with a salary field")

    pipeline = [{"$project": {"salary": 0}}]
    db.command("create", "employees_public", viewOn="employees", pipeline=pipeline)
    info = db.command("listCollections", filter={"name": "employees_public"})["cursor"]["firstBatch"][0]
    print(f"[OK] view employees_public created: {json.dumps(info['options'])}")

    heading("Step 2: roles and users (as admin)")
    adm = admin["admin"]
    for user in USERS:
        drop_quietly(adm, "dropUser", user)
    for role in ("hrRole", "staffRole"):
        drop_quietly(adm, "dropRole", role)

    adm.command("createRole", "hrRole", roles=[], privileges=[
        {"resource": {"db": DB, "collection": "employees"}, "actions": ["find"]}])
    adm.command("createRole", "staffRole", roles=[], privileges=[
        {"resource": {"db": DB, "collection": "employees_public"}, "actions": ["find"]}])
    print("[OK] Roles: hrRole (find on employees), staffRole (find on employees_public only)")

    adm.command("createUser", "hr_manager", pwd=USERS["hr_manager"], roles=[{"role": "hrRole", "db": "admin"}])
    adm.command("createUser", "staff_user", pwd=USERS["staff_user"], roles=[{"role": "staffRole", "db": "admin"}])
    adm.command("createUser", "dev_user", pwd=USERS["dev_user"], roles=[{"role": "read", "db": DB}])
    print("[OK] Users: hr_manager (hrRole), staff_user (staffRole), dev_user (built-in read on the whole database)")


def run_tests(args):
    heading("Step 3: what each user sees")
    hr = connect(args, "hr_manager", USERS["hr_manager"])[DB]
    staff = connect(args, "staff_user", USERS["staff_user"])[DB]
    dev = connect(args, "dev_user", USERS["dev_user"])[DB]

    print("staff_user  reads the view      :", without_id(staff.employees_public.find_one({"name": "Ben"})))
    print("hr_manager  reads the collection:", without_id(hr.employees.find_one({"name": "Ben"})))

    def view_has_no_salary():
        docs = list(staff.employees_public.find())
        return f"{len(docs)} docs, salary hidden" if all("salary" not in d for d in docs) else "salary VISIBLE"

    def per_dept():
        rows = list(staff.employees_public.aggregate([{"$group": {"_id": "$dept", "n": {"$sum": 1}}}]))
        return f"headcount per dept works ({len(rows)} groups)"

    def payroll_total():
        rows = list(staff.employees_public.aggregate([{"$group": {"_id": None, "total": {"$sum": "$salary"}}}]))
        return f"total payroll = {rows[0]['total']} (field is not visible)"

    def filter_on_salary():
        n = len(list(staff.employees_public.find({"salary": {"$gt": 50000}})))
        return f"{n} docs match: cannot probe salaries"

    def hr_sees_salary():
        doc = hr.employees.find_one()
        return "salary VISIBLE" if "salary" in doc else "salary hidden"

    def dev_sees_salary():
        doc = dev.employees.find_one()
        return "salary VISIBLE (bypasses the view!)" if "salary" in doc else "salary hidden"

    tests = [
        # user, operation, expected allowed?, function, text the detail must contain
        ("staff_user", "find on view employees_public", True, view_has_no_salary, "salary hidden"),
        ("staff_user", "aggregate headcount on the view", True, per_dept, None),
        ("staff_user", "aggregate payroll total on the view", True, payroll_total, "= 0"),
        ("staff_user", "filter salary > 50000 on the view", True, filter_on_salary, "0 docs"),
        ("staff_user", "find on employees (real collection)", False, lambda: staff.employees.find_one() and "", None),
        ("staff_user", "insert into the view", False, lambda: staff.employees_public.insert_one({"x": 1}) and "", None),
        ("hr_manager", "find on employees (real collection)", True, hr_sees_salary, "salary VISIBLE"),
        ("hr_manager", "update on employees", False, lambda: hr.employees.update_one({}, {"$set": {"x": 1}}) and "", None),
        ("dev_user", "find on employees (pitfall)", True, dev_sees_salary, "salary VISIBLE"),
    ]

    print()
    print(f"{'user':<12}{'operation':<38}{'expected':<10}{'actual':<10}{'result':<8}note")
    print("-" * 110)
    passed = 0
    for user, op, expected, fn, must in tests:
        allowed, detail = attempt(fn)
        ok = allowed == expected and (must is None or must in detail)
        passed += ok
        print(f"{user:<12}{op:<38}{('allowed' if expected else 'denied'):<10}"
              f"{('allowed' if allowed else 'denied'):<10}{('PASS' if ok else 'FAIL'):<8}{detail}")
    print("-" * 110)
    print(f"{passed}/{len(tests)} checks passed")
    print("\nTakeaway: the view only protects the salary field if non-HR users have NO privilege on the")
    print("underlying collection. dev_user has the broad 'read' role on the database, so the view does not")
    print("restrict them. Grant find on the view only (as staffRole does), never read on the whole database.")


def main():
    parser = argparse.ArgumentParser(description="Activity 12.1: field-level redaction with a view")
    parser.add_argument("--port", type=int, default=27028)
    parser.add_argument("--admin-user", default="admin")
    parser.add_argument("--admin-pass", default="AdminPass123!")
    args = parser.parse_args()

    print("Activity 12.1: field-level redaction with a view")
    admin = connect(args, args.admin_user, args.admin_pass)
    try:
        admin.admin.command("listDatabases")
    except PyMongoError as exc:
        raise SystemExit(f"Could not log in as {args.admin_user}: {exc}\n"
                         "Is the mongo-auth container running with --auth, and are the credentials right?")
    print(f"[OK] Logged in as {args.admin_user}")

    setup(admin)
    run_tests(args)
    admin.close()


if __name__ == "__main__":
    main()
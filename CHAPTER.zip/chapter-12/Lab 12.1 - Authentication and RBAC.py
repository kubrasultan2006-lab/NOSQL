"""
Lab 12.1: Configure Authentication and RBAC

Runs against a MongoDB server that was started WITH authentication (--auth).
Start one in Docker on a spare port so your normal 27017 server is not touched:

    docker run -d --name mongo-auth -p 27018:27017 `
        -e MONGO_INITDB_ROOT_USERNAME=admin -e MONGO_INITDB_ROOT_PASSWORD=AdminPass123! `
        mongo:8.0 --auth

Then, from the pymongo-quickstart folder:

    python "chapter-12\\Lab 12.1 - Authentication and RBAC.py"

What it does:
  1. Shows that an unauthenticated client is rejected (authentication is enforced).
  2. Logs in as the admin user and creates sample data.
  3. Creates roles and users (same users as the shell script):
       analyst     read on chapter-12 and chapter-12-bookstore
       app_writer  readWrite on chapter-12
       log_writer  custom role limitedWriter: find/insert/update on chapter-12.logs, find on the rest
       view_user   can only query the view chapter-12-hr.employees_public (salary removed with $project)
       hr_user     can query the underlying chapter-12-hr.employees (sees salary)
  4. Logs in as each user and tries allowed and forbidden operations, then prints a PASS/FAIL table.

Requires: pip install pymongo
"""

import argparse
import sys

from pymongo import MongoClient
from pymongo.errors import OperationFailure, PyMongoError

APP_DB = "chapter-12"
BOOK_DB = "chapter-12-bookstore"
HR_DB = "chapter-12-hr"

USERS = {
    "analyst": "AnalystPass123!",
    "app_writer": "WriterPass123!",
    "log_writer": "LogPass123!",
    "view_user": "ViewPass123!",
    "hr_user": "HrPass123!",
}


def heading(text):
    print(f"\n=== {text} ===")


def connect(args, user=None, password=None):
    kwargs = {"host": "localhost", "port": args.port, "serverSelectionTimeoutMS": 4000}
    if user:
        kwargs.update(username=user, password=password, authSource="admin")
    return MongoClient(**kwargs)


def touch(*_):
    return ""


def attempt(fn):
    """Run fn. Returns (allowed, detail). 'Unauthorized' (code 13) means denied."""
    try:
        return True, fn() or ""
    except OperationFailure as exc:
        if exc.code == 13:
            return False, "not authorized"
        return False, f"error {exc.code}"


# --------------------------------------------------------------------------- steps
def step_unauthenticated(args):
    heading("Step 1: unauthenticated access must be rejected")
    client = connect(args)
    allowed, detail = attempt(lambda: touch(client.admin.command("listDatabases")))
    if allowed:
        print("[WARNING] The server did not ask for authentication. Was it started with --auth?")
        print("          Stop here: the tests below would not mean anything.")
        sys.exit(1)
    print(f"[OK] listDatabases without credentials rejected ({detail})")
    allowed, detail = attempt(lambda: touch(client[APP_DB].products.find_one()))
    print(f"[OK] find on {APP_DB}.products without credentials rejected ({detail})" if not allowed
          else "[ERROR] find without credentials succeeded")
    client.close()


def step_seed(admin):
    heading("Step 2: sample data (as admin)")
    seed = {
        (APP_DB, "products"): [{"name": "Mouse", "price": 19.99}, {"name": "Keyboard", "price": 49.5}],
        (APP_DB, "logs"): [{"msg": "service started"}, {"msg": "user login"}],
        (BOOK_DB, "books"): [{"title": "NoSQL Distilled"}, {"title": "MongoDB: The Definitive Guide"}],
        (HR_DB, "employees"): [
            {"name": "Asha", "dept": "Sales", "salary": 52000},
            {"name": "Ben", "dept": "IT", "salary": 61000},
            {"name": "Chen", "dept": "HR", "salary": 58000},
        ],
    }
    for (db, coll), docs in seed.items():
        admin[db][coll].drop()
        admin[db][coll].insert_many(docs)
        print(f"[OK] {db}.{coll}: {len(docs)} documents")
    admin[HR_DB].drop_collection("employees_public")
    admin[HR_DB].command("create", "employees_public", viewOn="employees", pipeline=[{"$project": {"salary": 0}}])
    print(f"[OK] view {HR_DB}.employees_public created (removes the salary field)")


def drop_quietly(admin, command, name):
    try:
        admin.command(command, name)
    except OperationFailure:
        pass


def step_roles_and_users(admin):
    heading("Step 3: roles and users (as admin)")
    db = admin["admin"]
    for user in USERS:
        drop_quietly(db, "dropUser", user)
    for role in ("limitedWriter", "hrReader", "viewReader"):
        drop_quietly(db, "dropRole", role)

    db.command("createRole", "limitedWriter", roles=[], privileges=[
        {"resource": {"db": APP_DB, "collection": "logs"}, "actions": ["find", "insert", "update"]},
        {"resource": {"db": APP_DB, "collection": ""}, "actions": ["find"]},
    ])
    db.command("createRole", "hrReader", roles=[], privileges=[
        {"resource": {"db": HR_DB, "collection": "employees"}, "actions": ["find"]}])
    db.command("createRole", "viewReader", roles=[], privileges=[
        {"resource": {"db": HR_DB, "collection": "employees_public"}, "actions": ["find"]}])
    print("[OK] Created roles: limitedWriter, hrReader, viewReader")

    definitions = {
        "analyst": ([{"role": "read", "db": APP_DB}, {"role": "read", "db": BOOK_DB}],
                    f"read-only on {APP_DB} and {BOOK_DB}"),
        "app_writer": ([{"role": "readWrite", "db": APP_DB}], f"readWrite on {APP_DB}"),
        "log_writer": ([{"role": "limitedWriter", "db": "admin"}],
                       f"custom role: insert+update on logs, read everything else in {APP_DB}"),
        "view_user": ([{"role": "viewReader", "db": "admin"}], "can query only the view employees_public"),
        "hr_user": ([{"role": "hrReader", "db": "admin"}], "can query the underlying employees collection"),
    }
    for user, (roles, text) in definitions.items():
        db.command("createUser", user, pwd=USERS[user], roles=roles)
        print(f"[OK] Created user {user}: {text}")


def step_tests(args, admin):
    heading("Step 4: log in as each user and test permissions")
    clients = {u: connect(args, u, p) for u, p in USERS.items()}
    for user, c in clients.items():
        status = c.admin.command("connectionStatus")["authInfo"]
        roles = ", ".join(f"{r['role']}@{r['db']}" for r in status["authenticatedUserRoles"])
        print(f"  logged in as {user}: roles = {roles}")

    a, w, l, v, h = (clients[u] for u in ("analyst", "app_writer", "log_writer", "view_user", "hr_user"))

    def employee_detail(client, coll):
        doc = client[HR_DB][coll].find_one()
        return "salary VISIBLE" if "salary" in doc else "salary hidden"

    tests = [
        # user, operation, should it be allowed?, function, text the detail must contain
        ("analyst", f"find {APP_DB}.products", True, lambda: touch(a[APP_DB].products.find_one()), None),
        ("analyst", f"find {BOOK_DB}.books", True, lambda: touch(a[BOOK_DB].books.find_one()), None),
        ("analyst", f"insert {APP_DB}.products", False, lambda: touch(a[APP_DB].products.insert_one({"_test": True})), None),
        ("analyst", f"delete {APP_DB}.products", False, lambda: touch(a[APP_DB].products.delete_one({"_test": True})), None),
        ("app_writer", f"find {APP_DB}.products", True, lambda: touch(w[APP_DB].products.find_one()), None),
        ("app_writer", f"insert {APP_DB}.products", True, lambda: touch(w[APP_DB].products.insert_one({"_test": True})), None),
        ("app_writer", f"delete {APP_DB}.products", True, lambda: touch(w[APP_DB].products.delete_one({"_test": True})), None),
        ("app_writer", f"find {BOOK_DB}.books", False, lambda: touch(w[BOOK_DB].books.find_one()), None),
        ("log_writer", f"find {APP_DB}.products", True, lambda: touch(l[APP_DB].products.find_one()), None),
        ("log_writer", f"insert {APP_DB}.logs", True, lambda: touch(l[APP_DB].logs.insert_one({"_test": True})), None),
        ("log_writer", f"update {APP_DB}.logs", True, lambda: touch(l[APP_DB].logs.update_one({"_test": True}, {"$set": {"seen": True}})), None),
        ("log_writer", f"delete {APP_DB}.logs", False, lambda: touch(l[APP_DB].logs.delete_one({"_test": True})), None),
        ("log_writer", f"insert {APP_DB}.products", False, lambda: touch(l[APP_DB].products.insert_one({"_test": True})), None),
        ("view_user", f"find {HR_DB}.employees_public", True, lambda: employee_detail(v, "employees_public"), "salary hidden"),
        ("view_user", f"find {HR_DB}.employees", False, lambda: touch(v[HR_DB].employees.find_one()), None),
        ("hr_user", f"find {HR_DB}.employees", True, lambda: employee_detail(h, "employees"), "salary VISIBLE"),
        ("hr_user", f"insert {HR_DB}.employees", False, lambda: touch(h[HR_DB].employees.insert_one({"_test": True})), None),
    ]

    print()
    print(f"{'user':<12}{'operation':<38}{'expected':<10}{'actual':<10}{'result':<8}note")
    print("-" * 94)
    passed = 0
    for user, op, expected, fn, must in tests:
        allowed, detail = attempt(fn)
        ok = allowed == expected and (must is None or must in detail)
        passed += ok
        print(f"{user:<12}{op:<38}{('allowed' if expected else 'denied'):<10}"
              f"{('allowed' if allowed else 'denied'):<10}{('PASS' if ok else 'FAIL'):<8}{detail}")
    print("-" * 94)
    print(f"{passed}/{len(tests)} checks passed")

    # clean up test documents and close connections
    for coll in ("products", "logs"):
        admin[APP_DB][coll].delete_many({"_test": True})
    for c in clients.values():
        c.close()


def main():
    parser = argparse.ArgumentParser(description="Lab 12.1: authentication and RBAC")
    parser.add_argument("--port", type=int, default=27028)
    parser.add_argument("--admin-user", default="admin")
    parser.add_argument("--admin-pass", default="AdminPass123!")
    args = parser.parse_args()

    print("Lab 12.1: Authentication and RBAC")
    step_unauthenticated(args)

    admin = connect(args, args.admin_user, args.admin_pass)
    try:
        admin.admin.command("connectionStatus")
        admin.admin.command("listDatabases")
    except PyMongoError as exc:
        raise SystemExit(f"Could not log in as {args.admin_user}: {exc}\n"
                         "Check --admin-user / --admin-pass and the container's root credentials.")
    print(f"\n[OK] Logged in as {args.admin_user}")

    step_seed(admin)
    step_roles_and_users(admin)
    step_tests(args, admin)
    admin.close()


if __name__ == "__main__":
    main()
import argparse, os, random, itertools
from collections import defaultdict, Counter
import numpy as np
import networkx as nx
from networkx.algorithms.community import greedy_modularity_communities

random.seed(7)
TYPES = ["phishing", "malware", "botnet", "ddos", "scan"]


def generate(n, n_sources=500, ring_size=15):
    sources = [f"SRC{i:04d}" for i in range(n_sources)]
    ring = set(sources[:ring_size])
    ring_targets = [f"10.0.0.{i}" for i in range(5)]
    docs = []
    for i in range(n):
        if random.random() < 0.15:
            s, tgt, typ = random.choice(sorted(ring)), random.choice(ring_targets), "scan"
        else:
            s = random.choice(sources)
            tgt, typ = f"10.{random.randint(0, 20)}.{random.randint(0, 255)}.{random.randint(0, 255)}", random.choice(TYPES)
        docs.append({"_id": i, "from_source": s, "target": tgt, "type": typ, "ts": i})
    return docs, ring


def build_edges(docs):
    by_attr = defaultdict(set)                      # (target,type) -> sources
    for d in docs:
        by_attr[(d["target"], d["type"])].add(d["from_source"])
    w = Counter()
    for srcs in by_attr.values():
        if 1 < len(srcs) <= 40:
            for a, b in itertools.combinations(sorted(srcs), 2):
                w[(a, b)] += 1                      # SUSPICIOUS {weight}
    return w


def load_live(docs, w):
    from pymongo import MongoClient
    from neo4j import GraphDatabase
    col = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))["threat_db"]["full_threats"]
    col.drop(); col.insert_many(docs); col.create_index([("from_source", 1), ("ts", -1)])
    drv = GraphDatabase.driver(os.environ.get("NEO4J_URI", "bolt://localhost:7687"),
                               auth=(os.environ.get("NEO4J_USER", "neo4j"), os.environ["NEO4J_PASSWORD"]))
    rows = [{"a": a, "b": b, "w": c} for (a, b), c in w.items()]
    with drv.session() as s:
        s.run("MATCH (n) DETACH DELETE n")
        for i in range(0, len(rows), 5000):
            s.run("UNWIND $r AS x MERGE (a:Source {id:x.a}) MERGE (b:Source {id:x.b}) "
                  "MERGE (a)-[:SUSPICIOUS {weight:x.w}]->(b)", r=rows[i:i + 5000])
        res = s.run("MATCH (a:Source)-[r:SUSPICIOUS]->(b:Source) RETURN a.id AS a, b.id AS b, r.weight AS w")
        edges = [(r["a"], r["b"], r["w"]) for r in res]
    return col, edges


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--offline", action="store_true")
    ap.add_argument("--n", type=int, default=100000)
    a = ap.parse_args()

    docs, ring = generate(a.n)
    w = build_edges(docs)
    print(f"Threats: {len(docs):,} | SUSPICIOUS edges: {len(w):,}")

    if a.offline:
        mongo = defaultdict(list)                   # in-memory stand-in for full_threats
        for d in docs:
            mongo[d["from_source"]].append(d)
        edges = [(x, y, c) for (x, y), c in w.items()]
        fetch = lambda src: mongo[src]
    else:
        col, edges = load_live(docs, w)
        fetch = lambda src: list(col.find({"from_source": src}))

    G = nx.Graph(); G.add_weighted_edges_from(edges)
    comms = [c for c in greedy_modularity_communities(G, weight="weight") if len(c) >= 3]

    def density(c):
        sub = G.subgraph(c)
        return sum(d["weight"] for *_, d in sub.edges(data=True)) / max(len(c), 1)

    scores = np.array([density(c) for c in comms])
    z = (scores - scores.mean()) / (scores.std() or 1)
    print(f"Communities (size>=3): {len(comms)}\n")

    for c, sc, zz in sorted(zip(comms, scores, z), key=lambda t: -t[2]):
        if zz < 2:
            continue
        threats = [t for s in c for t in fetch(s)]
        types = Counter(t["type"] for t in threats).most_common(3)
        targets = Counter(t["target"] for t in threats).most_common(3)
        overlap = len(set(c) & ring) / len(c)
        print(f"FLAGGED community: {len(c)} sources | weight/source={sc:.1f} | z={zz:.1f}")
        print(f"  Mongo cross-ref: {len(threats):,} threats | top types={types}")
        print(f"  top targets={targets}")
        print(f"  overlap with planted ring: {overlap:.0%}  -> review as likely false-positive cluster\n")


if __name__ == "__main__":
    main()
import argparse, os, random, itertools
from collections import defaultdict, Counter
import numpy as np
import networkx as nx
from networkx.algorithms.community import greedy_modularity_communities

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

random.seed(7)
TYPES = ["phishing", "malware", "botnet", "ddos", "scan"]


def generate(n, n_sources=500, ring_size=15):
    sources = [f"SRC{i:04d}" for i in range(n_sources)]
    ring = set(sources[:ring_size])
    ring_targets = [f"10.0.0.{i}" for i in range(5)]
    docs = []
    for i in range(n):
        if random.random() < 0.15:
            s, tgt, typ = random.choice(sorted(ring)), random.choice(ring_targets), "scan"
        else:
            s = random.choice(sources)
            tgt, typ = f"10.{random.randint(0, 20)}.{random.randint(0, 255)}.{random.randint(0, 255)}", random.choice(TYPES)
        docs.append({"_id": i, "from_source": s, "target": tgt, "type": typ, "ts": i})
    return docs, ring


def build_edges(docs):
    by_attr = defaultdict(set)                      # (target,type) -> sources
    for d in docs:
        by_attr[(d["target"], d["type"])].add(d["from_source"])
    w = Counter()
    for srcs in by_attr.values():
        if 1 < len(srcs) <= 40:
            for a, b in itertools.combinations(sorted(srcs), 2):
                w[(a, b)] += 1                      # SUSPICIOUS {weight}
    return w


def load_live(docs, w, db_name="chapter-18"):
    from pymongo import MongoClient
    from neo4j import GraphDatabase
    col = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))[db_name]["full_threats"]
    col.drop(); col.insert_many(docs); col.create_index([("from_source", 1), ("ts", -1)])
    drv = GraphDatabase.driver(os.environ.get("NEO4J_URI", "bolt://localhost:7687"),
                               auth=(os.environ.get("NEO4J_USER", "neo4j"), os.environ["NEO4J_PASSWORD"]))
    rows = [{"a": a, "b": b, "w": c} for (a, b), c in w.items()]
    with drv.session() as s:
        s.run("MATCH (n) DETACH DELETE n")
        for i in range(0, len(rows), 5000):
            s.run("UNWIND $r AS x MERGE (a:Source {id:x.a}) MERGE (b:Source {id:x.b}) "
                  "MERGE (a)-[:SUSPICIOUS {weight:x.w}]->(b)", r=rows[i:i + 5000])
        res = s.run("MATCH (a:Source)-[r:SUSPICIOUS]->(b:Source) RETURN a.id AS a, b.id AS b, r.weight AS w")
        edges = [(r["a"], r["b"], r["w"]) for r in res]
    return col, edges


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--offline", action="store_true")
    ap.add_argument("--n", type=int, default=100000)
    ap.add_argument("--db", default="chapter-18")
    a = ap.parse_args()

    docs, ring = generate(a.n)
    w = build_edges(docs)
    print(f"Threats: {len(docs):,} | SUSPICIOUS edges: {len(w):,}")

    if a.offline:
        mongo = defaultdict(list)                   # in-memory stand-in for full_threats
        for d in docs:
            mongo[d["from_source"]].append(d)
        edges = [(x, y, c) for (x, y), c in w.items()]
        fetch = lambda src: mongo[src]
    else:
        col, edges = load_live(docs, w, db_name=a.db)
        fetch = lambda src: list(col.find({"from_source": src}))

    G = nx.Graph(); G.add_weighted_edges_from(edges)
    comms = [c for c in greedy_modularity_communities(G, weight="weight") if len(c) >= 3]

    def density(c):
        sub = G.subgraph(c)
        return sum(d["weight"] for *_, d in sub.edges(data=True)) / max(len(c), 1)

    scores = np.array([density(c) for c in comms])
    z = (scores - scores.mean()) / (scores.std() or 1)
    print(f"Communities (size>=3): {len(comms)}\n")

    for c, sc, zz in sorted(zip(comms, scores, z), key=lambda t: -t[2]):
        if zz < 2:
            continue
        threats = [t for s in c for t in fetch(s)]
        types = Counter(t["type"] for t in threats).most_common(3)
        targets = Counter(t["target"] for t in threats).most_common(3)
        overlap = len(set(c) & ring) / len(c)
        print(f"FLAGGED community: {len(c)} sources | weight/source={sc:.1f} | z={zz:.1f}")
        print(f"  Mongo cross-ref: {len(threats):,} threats | top types={types}")
        print(f"  top targets={targets}")
        print(f"  overlap with planted ring: {overlap:.0%}  -> review as likely false-positive cluster\n")


if __name__ == "__main__":
    main()
import os, re

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "Lab 18.1 - Comparative Report.txt")

table = "(Run Lab 18.1 first - its latency table will be inserted here.)"
setup = ""
if os.path.exists(SRC):
    txt = open(SRC, encoding="utf-8").read()
    m = re.search(r"4\. Results \(ms, lower is better\)\n(.*?)\n\n5\. Analysis", txt, re.S)
    if m: table = m.group(1)
    m = re.search(r"Mode\s*:\s*(.*)", txt)
    if m: setup = m.group(1).strip()

REPORT = r"""LAB 18.2 - COMPARATIVE ANALYSIS REPORT
MongoDB vs Cassandra vs Neo4j for False-Positive Detection in a Threat Intelligence Service

======================================================================
1. EXECUTIVE SUMMARY
======================================================================
No single database wins every access pattern. For the false-positive detection system we recommend a polyglot design:
MongoDB as the system of record and fast "recent threats" store, plus Neo4j for relationship analysis (shared targets,
suspicious source communities), which is the core of false-positive detection. Cassandra becomes the right choice for
the ingest path once volume reaches roughly 100M+ threats or sustained write rates that a single MongoDB replica set
cannot absorb. Neo4j should not be the primary ingest store at scale because its writes are not horizontally scalable
in the same way as Cassandra's or sharded MongoDB's.

======================================================================
2. METHODOLOGY
======================================================================
Data volume   : 1,00,000 synthetic threats, 500 sources, 30 days, 5 threat types. A group of 15 sources shares a small
                set of targets so there is a known "suspicious" cluster to detect.
Query patterns: (1) threat history for a source (last 50), (2) target and spread (which targets a source hit and which
                other sources hit the same targets), (3) daily volume analytics (count per day and type),
                (4) real-time insert throughput (batch inserts).
Measurement   : each query run 10 times after one warm-up; the MEDIAN latency is reported.
Environment   : @@MODE@@
Caveat        : scalability numbers in section 7 are planning estimates from public architecture guidance and the
                schema sizes below, not measurements. Validate them with a load test before sizing production.

======================================================================
3. SYSTEM ARCHITECTURE DIAGRAM
======================================================================
   Threat feeds / sensors
            |
            v
   +----------------------+
   |  Ingest API / queue  |
   +----------------------+
        |            |
        |            +-----------------------------+
        v                                          v
   +----------------+   +--------------------+   +--------------------+
   |    MongoDB     |   | Cassandra          |   |      Neo4j         |
   |  threat (last  |   | threats_by_source  |   | Source-SENT->Threat|
   |  50 embedded)  |   | threats_by_type    |   | -TARGETS->Target   |
   |  full_threats  |   | (scale-out ingest) |   | SUSPICIOUS links   |
   +----------------+   +--------------------+   +--------------------+
        |                        |                         |
        +------------+-----------+-------------------------+
                     v
        +---------------------------------+
        | Detection service               |
        |  1. Neo4j: communities of       |
        |     highly inter-connected      |
        |     sources                     |
        |  2. MongoDB: threat details for |
        |     flagged sources             |
        |  3. Analyst dashboard           |
        +---------------------------------+

======================================================================
4. SCHEMA DESIGN AND DATA MODELING ANALYSIS
======================================================================
MongoDB
  threat       : { _id: source, recent_threats: [ last 50 threats ] }   -> one read for dashboard history
  full_threats : { id, from_source, target, type, ts, day }             -> full history and aggregation
  Indexes      : (from_source, ts desc) for history, target for spread.
  Decisions    : embed the hot, bounded data (last 50); keep unbounded data in a separate collection to avoid
                 oversized documents. Flexible schema suits changing threat attributes.

Cassandra
  threats_by_source : PK (source), clustering (ts DESC, id)      -> history is one partition read
  threats_by_type   : PK ((type, day)), clustering (ts, id)      -> daily analytics is one partition per type/day
  Decisions         : query-first design; every threat is written to both tables (denormalization). Day is part of the
                      partition key to keep partitions bounded. Cost: more storage, more write work, and no joins,
                      so "spread" needs client-side work or a third table (threats_by_target).

Neo4j
  (Source {id})-[:SENT]->(Threat {id,type,day,ts})-[:TARGETS]->(Target {ip})
  (Source)-[:SUSPICIOUS {weight}]->(Source)   built from shared threat attributes
  Decisions         : model the relationships explicitly so "who else hit the same target" is a traversal, not a join.
                      Cost: heavier writes (node + relationships per threat) and full scans for analytics like daily
                      counts unless pre-aggregated.

Fit summary
  Document model : best for flexible records and fast single-entity reads.
  Wide-column    : best for known, high-volume queries and time-series style writes.
  Graph model    : best when the question is about connections between entities, as false-positive detection is.

======================================================================
5. QUERY PERFORMANCE COMPARISON (latency table, median ms)
======================================================================
@@TABLE@@

Reading the table: the table comes from Lab 18.1. If it was produced offline it comes from in-memory models of each
schema, so use it for the relative shape (which database does least work for each query) and replace it with the live
run for submission. Expected pattern on real servers: Cassandra is strongest on history, daily counts and inserts;
Neo4j is strongest on target-and-spread; MongoDB sits in the middle and is the most balanced.

======================================================================
6. ERGONOMICS (DEVELOPER EXPERIENCE)
======================================================================
MongoDB   : JSON-like documents map directly to Python dicts (pymongo); the aggregation pipeline is expressive but
            verbose. Low learning curve; the easiest of the three to start with.
Cassandra : CQL looks like SQL but has strict rules (no joins, filtering needs the partition key). You must know every
            query up front; changing a query often means a new table. Steepest modeling curve.
Neo4j     : Cypher pattern matching reads like the question being asked ("sources that hit the same targets"), which
            makes graph questions short and readable. Needs graph-modeling skills; tabular analytics feel awkward.

======================================================================
7. SCALABILITY ASSESSMENT (1M, 10M, 100M TRANSACTIONS)
======================================================================
Horizontal scaling mechanisms
  MongoDB   : replica sets for HA and read scaling; sharding (mongos routers + config servers + shards) for write and
              storage scale. Shard key choice is critical (e.g. hashed from_source for even writes; a time-leading
              key creates a hot shard).
  Cassandra : masterless ring with consistent hashing and virtual nodes. Add nodes to scale reads, writes and storage
              roughly linearly; replication factor and tunable consistency (ONE / QUORUM) control durability vs latency.
  Neo4j     : clustering (Enterprise) gives HA and read scale-out with secondaries, but writes go through a primary
              per database, so write scale is vertical. Federation (Fabric) and the newer sharded-graph features in
              recent releases help at very large scale; check the exact features of your version and license.

Planning estimates (about 300 bytes per threat raw; indexes, replication and denormalization multiply it)
  Scale  Raw data   MongoDB                         Cassandra (RF=3, 2 tables)       Neo4j
  -----  ---------  ------------------------------  -------------------------------  ----------------------------------
  1M     ~0.3 GB    1 node, 4 vCPU / 8 GB RAM       3 nodes, 4 vCPU / 16 GB          1 node, 4 vCPU / 8 GB RAM
                    (3-node replica set for HA)     (smallest HA ring)               (3-node cluster for HA)
  10M    ~3 GB      3-node replica set,             3 to 4 nodes, 8 vCPU / 32 GB,    1 primary + 2 secondaries,
                    8 vCPU / 32 GB, ~100 GB SSD     ~300 GB SSD total                8 vCPU / 32 GB (graph fits in RAM)
  100M   ~30 GB     sharded: 3 shards x 3-node      6 to 9 nodes, 16 vCPU / 64 GB,   1 large primary, 16 to 32 vCPU /
                    replica sets + 3 config +       NVMe, ~2 TB total (about 6x      128 to 256 GB RAM, + secondaries;
                    mongos; 16 vCPU / 64 GB each    raw because of RF=3 x 2 tables)  writes are the bottleneck

Behaviour as volume grows
  1M   : all three are comfortable on small hardware; choose on data model, not scale.
  10M  : MongoDB and Neo4j still run on one primary; unindexed scans (daily analytics) start to hurt, so pre-aggregate.
  100M : Cassandra scales by adding nodes with predictable latency; MongoDB needs sharding and a well-chosen shard key;
         Neo4j needs large RAM for its page cache and its write path becomes the limit, so keep the graph focused on
         sources, targets and SUSPICIOUS links rather than every raw event.

Operational complexity
  Backup     : MongoDB - mongodump, filesystem/cloud snapshots, point-in-time via oplog (Atlas or Ops Manager).
               Cassandra - nodetool snapshots + incremental backups per node (Medusa or similar); restore is per node.
               Neo4j - neo4j-admin database backup (online in Enterprise); dump/load (offline) in Community.
  Monitoring : MongoDB - Atlas / Ops Manager, mongostat, replication lag, chunk balance.
               Cassandra - nodetool status/tpstats, compaction backlog, pending repairs, p99 latency, disk usage.
               Neo4j - page cache hit ratio, transaction/heap metrics, cluster role and lag.
  Skills     : MongoDB - general backend developer plus index and shard-key knowledge.
               Cassandra - distributed-systems skills: data modeling, repairs, compaction tuning (highest ops burden).
               Neo4j - Cypher and graph modeling; cluster operations are simpler than Cassandra, but write scale
               needs vertical planning.

======================================================================
8. RECOMMENDATION (BY ACCESS PATTERN)
======================================================================
  Access pattern                    Best choice   Why
  --------------------------------  ------------  ------------------------------------------------------------
  Threat history for a source       Cassandra     One pre-sorted partition read; MongoDB's embedded last-50 array
                                    (or MongoDB)  is nearly as fast and simpler to operate.
  Target and spread                 Neo4j         One traversal answers "who else hit these targets"; others need
                                                  multiple lookups or client-side filtering.
  Daily volume analytics            Cassandra     (type, day) partitions make counts cheap; MongoDB works with
                                    (or MongoDB)  pre-aggregation or an aggregation pipeline.
  Real-time insert throughput       Cassandra     Log-structured writes and linear scale-out; Neo4j is the costliest
                                                  because each threat adds a node and relationships.
  False-positive community          Neo4j         Graph algorithms and pattern matching on SUSPICIOUS links;
  detection (Activity 18.1)                       cross-reference details from MongoDB.

Final recommendation: MongoDB + Neo4j for the detection system up to roughly 10M to 100M threats; add Cassandra as the
ingest and time-series store when write volume or retention outgrows a MongoDB replica set. Keep Neo4j as the analysis
layer, fed from the ingest store, rather than the system of record.
"""

out = REPORT.replace("@@TABLE@@", table).replace("@@MODE@@", setup or "see Lab 18.1 report")
path = os.path.join(HERE, "Lab 18.2 - Comparative Analysis Report.txt")
open(path, "w", encoding="utf-8").write(out)
print(f"Report written: {path}")

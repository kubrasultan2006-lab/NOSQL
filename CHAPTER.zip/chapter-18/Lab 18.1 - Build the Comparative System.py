import argparse, os, random, statistics, time
from collections import defaultdict, Counter
from datetime import datetime, timedelta

random.seed(18)
TYPES = ["phishing", "malware", "botnet", "ddos", "scan"]
BASE, DAYS, RUNS = datetime(2026, 10, 1), 30, 10
SOURCES = [f"SRC{i:04d}" for i in range(500)]
RING, RING_TARGETS = SOURCES[:15], [f"10.0.0.{i}" for i in range(5)]


def make(n, start=0, total=None):
    step = DAYS * 86400 / (total or n)
    out = []
    for i in range(start, start + n):
        ts = BASE + timedelta(seconds=i * step)
        if random.random() < 0.15:
            s, tgt, typ = random.choice(RING), random.choice(RING_TARGETS), "scan"
        else:
            s = random.choice(SOURCES)
            tgt = f"10.{random.randint(0, 20)}.{random.randint(0, 255)}.{random.randint(0, 255)}"
            typ = random.choice(TYPES)
        out.append({"id": i, "from_source": s, "target": tgt, "type": typ, "ts": ts, "day": ts.strftime("%Y-%m-%d")})
    return out


# ---------------- offline: in-memory models of each schema ----------------
class MongoSim:
    name = "MongoDB"
    def __init__(self, docs):
        self.full, self.by_src, self.by_tgt, self.recent = [], defaultdict(list), defaultdict(list), defaultdict(list)
        self.insert(docs)
    def history(self, src):                       # embedded recent_threats (last 50)
        return len(list(reversed(self.recent[src])))
    def spread(self, src):                        # index on target -> $in lookup
        tg = {d["target"] for d in self.by_src[src]}
        others = {d["from_source"] for t in tg for d in self.by_tgt[t]}
        return len(tg), len(others)
    def daily(self):                              # $group aggregation = scan
        return len(Counter((d["day"], d["type"]) for d in self.full))
    def insert(self, batch):
        for d in batch:
            self.full.append(d); self.by_src[d["from_source"]].append(d); self.by_tgt[d["target"]].append(d)
            r = self.recent[d["from_source"]]; r.append(d)
            if len(r) > 50: del r[0]


class CassandraSim:
    name = "Cassandra"
    def __init__(self, docs):
        self.by_source, self.by_type = defaultdict(list), defaultdict(list)
        self.insert(docs)
    def history(self, src):                       # single partition read
        return len(self.by_source[src][-50:][::-1])
    def spread(self, src):                        # no joins: read partitions + client-side filter
        rows = self.by_source[src]
        tg = {d["target"] for d in rows}
        parts = {(d["type"], d["day"]) for d in rows}
        others = {d["from_source"] for p in parts for d in self.by_type[p] if d["target"] in tg}
        return len(tg), len(others)
    def daily(self):                              # one count per (type, day) partition
        return sum(1 for k, v in self.by_type.items() if len(v))
    def insert(self, batch):                      # write to both tables
        for d in batch:
            self.by_source[d["from_source"]].append(d); self.by_type[(d["type"], d["day"])].append(d)


class Neo4jSim:
    name = "Neo4j"
    def __init__(self, docs):
        self.threats, self.sent, self.hit_by = [], defaultdict(list), defaultdict(set)
        self.insert(docs)
    def history(self, src):
        return len(self.sent[src][-50:][::-1])
    def spread(self, src):                        # 2-hop traversal via relationships
        tg = {d["target"] for d in self.sent[src]}
        others = set().union(*(self.hit_by[t] for t in tg)) - {src}
        return len(tg), len(others)
    def daily(self):                              # label scan + group
        return len(Counter((d["day"], d["type"]) for d in self.threats))
    def insert(self, batch):
        for d in batch:
            self.threats.append(d); self.sent[d["from_source"]].append(d); self.hit_by[d["target"]].add(d["from_source"])


# ---------------- live: real databases ----------------
class MongoLive:
    name = "MongoDB"
    def __init__(self, docs):
        from pymongo import MongoClient, ASCENDING, DESCENDING
        db = MongoClient(os.environ.get("MONGO_URI", "mongodb://localhost:27017/"))["threat_db"]
        db.full_threats.drop(); db.threat.drop()
        self.full, self.threat = db.full_threats, db.threat
        self.full.insert_many([dict(d) for d in docs])
        self.full.create_index([("from_source", ASCENDING), ("ts", DESCENDING)])
        self.full.create_index("target")
        rec = defaultdict(list)
        for d in docs:
            rec[d["from_source"]].append({k: v for k, v in d.items()})
            rec[d["from_source"]] = rec[d["from_source"]][-50:]
        self.threat.insert_many([{"_id": s, "recent_threats": v} for s, v in rec.items()])
    def history(self, src):
        return len(self.threat.find_one({"_id": src})["recent_threats"])
    def spread(self, src):
        tg = self.full.distinct("target", {"from_source": src})
        return len(tg), len(self.full.distinct("from_source", {"target": {"$in": tg}}))
    def daily(self):
        return len(list(self.full.aggregate([{"$group": {"_id": {"d": "$day", "t": "$type"}, "n": {"$sum": 1}}}])))
    def insert(self, batch):
        self.full.insert_many([dict(d) for d in batch])


class CassandraLive:
    name = "Cassandra"
    def __init__(self, docs):
        from cassandra.cluster import Cluster
        from cassandra.concurrent import execute_concurrent_with_args
        self.cc = execute_concurrent_with_args
        self.s = Cluster([os.environ.get("CASSANDRA_HOST", "127.0.0.1")]).connect()
        s = self.s
        s.execute("CREATE KEYSPACE IF NOT EXISTS threat_ks WITH replication={'class':'SimpleStrategy','replication_factor':1}")
        s.set_keyspace("threat_ks")
        s.execute("DROP TABLE IF EXISTS threats_by_source"); s.execute("DROP TABLE IF EXISTS threats_by_type")
        s.execute("CREATE TABLE threats_by_source (source text, ts timestamp, id int, target text, type text, day text, "
                  "PRIMARY KEY (source, ts, id)) WITH CLUSTERING ORDER BY (ts DESC, id DESC)")
        s.execute("CREATE TABLE threats_by_type (type text, day text, ts timestamp, id int, source text, target text, "
                  "PRIMARY KEY ((type, day), ts, id))")
        self.i1 = s.prepare("INSERT INTO threats_by_source (source, ts, id, target, type, day) VALUES (?,?,?,?,?,?)")
        self.i2 = s.prepare("INSERT INTO threats_by_type (type, day, ts, id, source, target) VALUES (?,?,?,?,?,?)")
        self.q_hist = s.prepare("SELECT id FROM threats_by_source WHERE source=? LIMIT 50")
        self.q_src = s.prepare("SELECT target, type, day FROM threats_by_source WHERE source=?")
        self.q_part = s.prepare("SELECT source, target FROM threats_by_type WHERE type=? AND day=?")
        self.q_cnt = s.prepare("SELECT COUNT(*) FROM threats_by_type WHERE type=? AND day=?")
        self.parts = set()
        self.insert(docs)
    def history(self, src):
        return len(list(self.s.execute(self.q_hist, (src,))))
    def spread(self, src):
        rows = list(self.s.execute(self.q_src, (src,)))
        tg = {r.target for r in rows}
        parts = list({(r.type, r.day) for r in rows})
        others = set()
        for ok, res in self.cc(self.s, self.q_part, parts, concurrency=32, results_generator=False):
            others |= {r.source for r in res if r.target in tg}
        return len(tg), len(others)
    def daily(self):
        res = self.cc(self.s, self.q_cnt, list(self.parts), concurrency=32)
        return sum(r[0].count for ok, r in res)
    def insert(self, batch):
        self.cc(self.s, self.i1, [(d["from_source"], d["ts"], d["id"], d["target"], d["type"], d["day"]) for d in batch], concurrency=64)
        self.cc(self.s, self.i2, [(d["type"], d["day"], d["ts"], d["id"], d["from_source"], d["target"]) for d in batch], concurrency=64)
        self.parts |= {(d["type"], d["day"]) for d in batch}


class Neo4jLive:
    name = "Neo4j"
    LOAD = ("UNWIND $rows AS r MERGE (s:Source {id:r.source}) MERGE (g:Target {ip:r.target}) "
            "CREATE (t:Threat {id:r.id, type:r.type, day:r.day, ts:r.ts}) CREATE (s)-[:SENT]->(t)-[:TARGETS]->(g)")
    def __init__(self, docs):
        from neo4j import GraphDatabase
        self.drv = GraphDatabase.driver(os.environ.get("NEO4J_URI", "bolt://localhost:7687"),
                                        auth=(os.environ.get("NEO4J_USER", "neo4j"), os.environ["NEO4J_PASSWORD"]))
        with self.drv.session() as s:
            s.run("MATCH (n) DETACH DELETE n")
            s.run("CREATE CONSTRAINT src_id IF NOT EXISTS FOR (s:Source) REQUIRE s.id IS UNIQUE")
            s.run("CREATE CONSTRAINT tgt_ip IF NOT EXISTS FOR (g:Target) REQUIRE g.ip IS UNIQUE")
            s.run("CREATE INDEX threat_id IF NOT EXISTS FOR (t:Threat) ON (t.id)")
        self.insert(docs)
    def _run(self, q, **p):
        with self.drv.session() as s:
            return list(s.run(q, **p))
    def history(self, src):
        return len(self._run("MATCH (:Source {id:$s})-[:SENT]->(t:Threat) RETURN t.id ORDER BY t.ts DESC LIMIT 50", s=src))
    def spread(self, src):
        r = self._run("MATCH (s:Source {id:$s})-[:SENT]->(:Threat)-[:TARGETS]->(g:Target)<-[:TARGETS]-(:Threat)<-[:SENT]-(o:Source) "
                      "WHERE o<>s RETURN count(DISTINCT g) AS g, count(DISTINCT o) AS o", s=src)[0]
        return r["g"], r["o"]
    def daily(self):
        return len(self._run("MATCH (t:Threat) RETURN t.day AS d, t.type AS ty, count(*) AS n"))
    def insert(self, batch):
        rows = [{"source": d["from_source"], "target": d["target"], "id": d["id"], "type": d["type"],
                 "day": d["day"], "ts": int(d["ts"].timestamp())} for d in batch]
        for i in range(0, len(rows), 5000):
            self._run(self.LOAD, rows=rows[i:i + 5000])


# ---------------- benchmark ----------------
def median_ms(fn):
    fn()                                           # warm-up (not counted)
    t = []
    for _ in range(RUNS):
        a = time.perf_counter(); fn(); t.append((time.perf_counter() - a) * 1000)
    return statistics.median(t)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--offline", action="store_true")
    ap.add_argument("--n", type=int, default=100000)
    ap.add_argument("--batch", type=int, default=1000)
    a = ap.parse_args()

    docs = make(a.n)
    hot = Counter(d["from_source"] for d in docs).most_common(1)[0][0]
    engines = [MongoSim, CassandraSim, Neo4jSim] if a.offline else [MongoLive, CassandraLive, Neo4jLive]
    results, load_s = {}, {}
    next_id = [a.n]

    for E in engines:
        try:
            t0 = time.perf_counter(); db = E(docs); load_s[E.name] = time.perf_counter() - t0
        except Exception as e:
            print(f"[skip] {E.name}: {e}"); continue
        def ins():
            b = make(a.batch, start=next_id[0], total=a.n); next_id[0] += a.batch; db.insert(b)
        r = {"1. Threat history": median_ms(lambda: db.history(hot)),
             "2. Target and spread": median_ms(lambda: db.spread(hot)),
             "3. Daily volume analytics": median_ms(db.daily)}
        r["4. Insert batch"] = median_ms(ins)
        r["4. Insert throughput (threats/s)"] = a.batch / (r["4. Insert batch"] / 1000)
        results[E.name] = r
        print(f"loaded {E.name}: {len(docs):,} threats in {load_s[E.name]:.1f}s")

    names = list(results)
    qs = ["1. Threat history", "2. Target and spread", "3. Daily volume analytics", "4. Insert batch"]
    lines = [f"{'Query (median of ' + str(RUNS) + ' runs, ms)':<36}" + "".join(f"{n:>12}" for n in names) + "   Fastest"]
    for q in qs:
        best = min(names, key=lambda n: results[n][q])
        lines.append(f"{q:<36}" + "".join(f"{results[n][q]:>12.3f}" for n in names) + f"   {best}")
    lines.append(f"{'4. Insert throughput (threats/s)':<36}" + "".join(f"{results[n]['4. Insert throughput (threats/s)']:>12,.0f}" for n in names))
    lines.append(f"{'Bulk load time (s)':<36}" + "".join(f"{load_s[n]:>12.2f}" for n in names))
    table = "\n".join(lines)
    print("\n" + table)

    mode = "OFFLINE (in-memory models of each schema; relative shape only, not real server latency)" if a.offline \
        else "LIVE (real MongoDB, Cassandra, Neo4j servers)"
    report = f"""LAB 18.1 - COMPARATIVE REPORT: THREAT INTELLIGENCE FALSE-POSITIVE DETECTION

1. Objective
Implement the threat-intelligence system in MongoDB, Cassandra and Neo4j, benchmark 4 queries and compare.

2. Setup
Mode        : {mode}
Dataset     : {a.n:,} threats, {len(SOURCES)} sources, {DAYS} days, types = {', '.join(TYPES)}
Hot source  : {hot} (most active; used for queries 1 and 2)
Method      : each query run {RUNS} times after 1 warm-up, MEDIAN reported. Insert = batch of {a.batch}.

3. Schema design
MongoDB   : threat collection (embedded recent_threats = last 50) + full_threats; index (from_source, ts) + target.
Cassandra : threats_by_source (PK source, clustering ts DESC) + threats_by_type (PK (type, day)); every threat written to both.
Neo4j     : (Source)-[:SENT]->(Threat)-[:TARGETS]->(Target); SUSPICIOUS links between sources sharing attributes.

4. Results (ms, lower is better)
{table}

5. Analysis (typical behaviour on real servers; compare with the table above)
Threat history : Cassandra reads one pre-sorted partition; MongoDB reads one embedded array; Neo4j needs a relationship
                 expansion + sort. All are cheap; Cassandra/MongoDB are the most direct.
Target & spread: this is a multi-hop question. Neo4j answers it with one traversal (Source->Threat->Target->Threat->Source).
                 MongoDB needs two index lookups; Cassandra has no joins, so partitions are read and filtered in the client.
Daily volume   : aggregation-style. Cassandra's (type, day) partitions make counts cheap; MongoDB ($group) and Neo4j
                 (label scan) must touch every threat unless pre-aggregated.
Insert         : Cassandra's log-structured writes scale best; MongoDB updates indexes + embedded array; Neo4j creates
                 nodes and relationships per threat, which is the costliest.

6. Recommendation
Use Neo4j for relationship / false-positive community detection, Cassandra for high-volume ingestion and time-based
analytics, and MongoDB for flexible threat documents and fast recent-history display. A polyglot design (Mongo + Neo4j,
with Cassandra for ingest at scale) fits this use case best.
"""
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Lab 18.1 - Comparative Report.txt")
    open(path, "w", encoding="utf-8").write(report)
    print(f"\nReport written: {path}")


if __name__ == "__main__":
    main()

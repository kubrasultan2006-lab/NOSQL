"""Lab 3.1 - Embedded Document Schema (Lab Tasks + Try It Yourself)

PART A  Lab tasks
  1. Course collection with embedded students (name, ID, grade) and schedule,
     3+ course documents, query for all courses that meet on Monday.
  2. JSON Schema validation requiring title (course_name), code, instructor, schedule.
  3. Query that finds all students enrolled in courses taught by a specific instructor.

PART B  Try it yourself: course prerequisites, EMBEDDED approach
  (an alternative to storing plain course_code references)
  Prerequisites are embedded as small snapshots {course_code, course_name, min_grade}.

  Why embed here?
    - The minimum grade required is a property of the RELATIONSHIP (AIML301 needs a C or
      better in AIML201), so it has no natural home in either course document; embedding
      gives it one.
    - A course page almost always shows its prerequisites with their names, so one read
      returns everything with no $lookup.
    - Only a tiny, rarely-changing snapshot is copied, not the whole prerequisite course.
  Cost: the copied course_name can go stale, so renames must be propagated (demonstrated below).
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config.connection import get_db, banner
from rich.console import Console
from rich.table import Table

console = Console()


# ---------------------------------------------------------------- shared data
def student(sid, name, grade):
    return {"student_id": sid, "name": name, "email": f"{name.split()[0].lower()}@college.edu", "grade": grade}


COURSES = [
    {"course_name": "Introduction to Machine Learning", "course_code": "AIML101",
     "instructor": "Dr. Priya Sharma", "credits": 4,
     "schedule": {"days": ["Monday", "Wednesday"], "time": "10:00-11:30", "room": "LH-201"},
     "enrolled_students": [student("S1001", "Arjun Mehta", "A"), student("S1002", "Sneha Reddy", "B+"),
                           student("S1004", "Rahul Kumar", "A-")]},
    {"course_name": "Statistics for Data Science", "course_code": "AIML102",
     "instructor": "Dr. Priya Sharma", "credits": 3,
     "schedule": {"days": ["Tuesday", "Thursday"], "time": "09:00-10:30", "room": "LH-110"},
     "enrolled_students": [student("S1001", "Arjun Mehta", "A-"), student("S1005", "Divya Patel", "B")]},
    {"course_name": "Natural Language Processing", "course_code": "AIML201",
     "instructor": "Dr. Meera Joshi", "credits": 3,
     "schedule": {"days": ["Monday", "Wednesday", "Friday"], "time": "09:00-10:00", "room": "LH-102"},
     "enrolled_students": [student("S1002", "Sneha Reddy", None), student("S1004", "Rahul Kumar", None)]},
    {"course_name": "Deep Learning with PyTorch", "course_code": "AIML301",
     "instructor": "Dr. Anil Gupta", "credits": 3,
     "schedule": {"days": ["Tuesday", "Thursday"], "time": "14:00-15:30", "room": "LH-305"},
     "enrolled_students": [student("S1003", "Kavya Nair", None), student("S1001", "Arjun Mehta", None)]},
]

STUDENT_SCHEMA = {
    "bsonType": "object",
    "required": ["student_id", "name", "email"],
    "properties": {
        "student_id": {"bsonType": "string"},
        "name": {"bsonType": "string"},
        "email": {"bsonType": "string"},
        "grade": {"bsonType": ["string", "null"]},
    },
}

SCHEDULE_SCHEMA = {
    "bsonType": "object",
    "required": ["days", "time", "room"],
    "properties": {
        "days": {"bsonType": "array", "items": {"bsonType": "string"}},
        "time": {"bsonType": "string"},
        "room": {"bsonType": "string"},
    },
}


def make_validator(extra_required=None, extra_props=None):
    required = ["course_name", "course_code", "instructor", "schedule", "enrolled_students"]
    props = {
        "course_name": {"bsonType": "string"},
        "course_code": {"bsonType": "string", "pattern": r"^[A-Z]{4}\d{3}$"},
        "instructor": {"bsonType": "string"},
        "credits": {"bsonType": "int", "minimum": 1, "maximum": 6},
        "schedule": SCHEDULE_SCHEMA,
        "enrolled_students": {"bsonType": "array", "items": STUDENT_SCHEMA},
    }
    return {"$jsonSchema": {"bsonType": "object",
                            "required": required + (extra_required or []),
                            "properties": {**props, **(extra_props or {})}}}


def fresh_collection(db, name, validator):
    if name in db.list_collection_names():
        db.drop_collection(name)
    db.create_collection(name, validator=validator)
    return db[name]


# ------------------------------------------------------------------- PART A
def part_a(db):
    banner("PART A: Lab 3.1 Tasks")

    # Tasks 1 + 2: collection with validation, then insert 3+ courses
    col = fresh_collection(db, "courses", make_validator())
    col.insert_many(COURSES)
    print(f"[OK] Created 'courses' with JSON Schema validation and inserted {len(COURSES)} courses.\n")

    print("=== Task 1: Courses that meet on Monday ===")
    for c in col.find({"schedule.days": "Monday"}, {"course_name": 1, "schedule": 1, "_id": 0}):
        s = c["schedule"]
        print(f"  {c['course_name']:<36} {s['time']} in {s['room']} ({', '.join(s['days'])})")

    print("\n=== Task 2: Validation rejects incomplete documents ===")
    bad_docs = [
        ("missing instructor and schedule", {"course_name": "Bad Course", "course_code": "AIML999",
                                              "enrolled_students": []}),
        ("code not in format XXXX000", {"course_name": "Bad Code", "course_code": "ml-1", "instructor": "X",
                                        "schedule": {"days": ["Monday"], "time": "10:00", "room": "R1"},
                                        "enrolled_students": []}),
    ]
    for label, doc in bad_docs:
        try:
            col.insert_one(doc)
            print(f"  [ERROR] '{label}' should have been rejected!")
        except Exception:
            print(f"  [OK] Rejected: {label}")

    # Task 3: all students in courses taught by a specific instructor
    instructor = "Dr. Priya Sharma"
    print(f"\n=== Task 3: Students enrolled in courses taught by {instructor} ===")
    pipeline = [
        {"$match": {"instructor": instructor}},
        {"$unwind": "$enrolled_students"},
        {"$group": {"_id": "$enrolled_students.student_id",
                    "name": {"$first": "$enrolled_students.name"},
                    "email": {"$first": "$enrolled_students.email"},
                    "courses": {"$push": "$course_code"}}},
        {"$sort": {"_id": 1}},
    ]
    table = Table(show_lines=True)
    table.add_column("Student ID", style="cyan", width=11)
    table.add_column("Name", width=16)
    table.add_column("Email", width=22)
    table.add_column("Courses with this instructor", width=28)
    for s in col.aggregate(pipeline):
        table.add_row(s["_id"], s["name"], s["email"], ", ".join(s["courses"]))
    console.print(table)
    print("  (students in several of the instructor's courses appear once, thanks to $group)")


# ------------------------------------------------------------------- PART B
def part_b(db):
    banner("PART B: Try It Yourself - Embedded Prerequisites")

    prereq_item = {
        "bsonType": "object",
        "required": ["course_code", "course_name", "min_grade"],
        "properties": {
            "course_code": {"bsonType": "string", "pattern": r"^[A-Z]{4}\d{3}$"},
            "course_name": {"bsonType": "string"},
            "min_grade": {"bsonType": "string", "enum": ["A", "B", "C", "D"]},
        },
    }
    validator = make_validator(
        extra_required=["prerequisites"],
        extra_props={"prerequisites": {"bsonType": "array", "items": prereq_item}},
    )
    col = fresh_collection(db, "courses_prereq_embedded", validator)

    def pre(code, name, grade):
        return {"course_code": code, "course_name": name, "min_grade": grade}

    prereqs = {
        "AIML101": [],
        "AIML102": [],
        "AIML201": [pre("AIML101", "Introduction to Machine Learning", "C"),
                    pre("AIML102", "Statistics for Data Science", "C")],
        "AIML301": [pre("AIML101", "Introduction to Machine Learning", "B"),
                    pre("AIML201", "Natural Language Processing", "C")],
    }
    docs = [{**c, "prerequisites": prereqs[c["course_code"]]} for c in COURSES]
    col.insert_many(docs)
    col.create_index("prerequisites.course_code")
    print(f"[OK] Inserted {len(docs)} courses with embedded prerequisite snapshots.\n")

    # 1. One read returns prerequisites with names and required grades
    print("=== 1. Prerequisites in a single read (no $lookup) ===")
    c = col.find_one({"course_code": "AIML301"}, {"course_name": 1, "prerequisites": 1, "_id": 0})
    print(f"  {c['course_name']} requires:")
    for p in c["prerequisites"]:
        print(f"    {p['course_code']} {p['course_name']} (min grade {p['min_grade']})")

    # 2. Reverse lookup via index on the embedded field
    print("\n=== 2. Courses that require AIML101 ===")
    for c in col.find({"prerequisites.course_code": "AIML101"}, {"course_code": 1, "prerequisites": 1, "_id": 0}):
        grade = next(p["min_grade"] for p in c["prerequisites"] if p["course_code"] == "AIML101")
        print(f"  {c['course_code']} (needs at least {grade})")

    # 3. Eligibility after completing courses
    completed = ["AIML101", "AIML102"]
    print(f"\n=== 3. Courses open to a student who completed {completed} ===")
    eligible = col.find(
        {"course_code": {"$nin": completed},
         "$expr": {"$setIsSubset": [
             {"$map": {"input": "$prerequisites", "as": "p", "in": "$$p.course_code"}}, completed]}},
        {"course_code": 1, "course_name": 1, "_id": 0},
    )
    for c in eligible:
        print(f"  {c['course_code']}: {c['course_name']}")

    # 4. The cost of embedding: a rename makes the copies stale
    print("\n=== 4. The trade-off: renaming AIML101 ===")
    new_name = "Foundations of Machine Learning"
    col.update_one({"course_code": "AIML101"}, {"$set": {"course_name": new_name}})
    stale = col.count_documents({"prerequisites": {"$elemMatch": {"course_code": "AIML101",
                                                                  "course_name": {"$ne": new_name}}}})
    print(f"  Renamed AIML101 -> '{new_name}'")
    print(f"  Courses now holding a STALE embedded name: {stale}")

    result = col.update_many(
        {"prerequisites.course_code": "AIML101"},
        {"$set": {"prerequisites.$[p].course_name": new_name}},
        array_filters=[{"p.course_code": "AIML101"}],
    )
    print(f"  Propagated rename with arrayFilters to {result.modified_count} course(s)")
    stale = col.count_documents({"prerequisites": {"$elemMatch": {"course_code": "AIML101",
                                                                  "course_name": {"$ne": new_name}}}})
    print(f"  Stale copies remaining: {stale}")

    # 5. Summary
    print("\n=== Embedded vs Referenced Prerequisites ===")
    table = Table(show_lines=True)
    table.add_column("Aspect", style="cyan", width=24)
    table.add_column("Embedded snapshot (this file)", width=34)
    table.add_column("Reference by code (lab_3_1_activity.py)", width=38)
    table.add_row("Reading a course page", "1 read, names included", "needs $lookup for names")
    table.add_row("Required grade per link", "stored naturally on the link", "needs extra structure")
    table.add_row("Renaming a course", "must update every copy", "single update")
    table.add_row("Whole prerequisite chain", "walk with repeated queries", "one $graphLookup")
    table.add_row("Best when", "reads dominate, names rarely change", "data changes often, deep chains")
    console.print(table)


def main():
    banner("Lab 3.1: Embedded Document Schema (Tasks + Try It Yourself)")
    db = get_db("chapter-03")
    part_a(db)
    part_b(db)
    banner("Lab 3.1 Complete")


if __name__ == "__main__":
    main()
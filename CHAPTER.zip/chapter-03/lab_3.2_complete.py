"""Lab 3.2 - Migrate from Referenced to Embedded Design (Lab Tasks + Try It Yourself)

PART A  Lab tasks
  1. Referenced design: separate posts and comments collections (5 posts, 10 comments).
  2. $lookup query returning a post with its comments in a single query.
  3. Migrate to an embedded design using an aggregation pipeline ($lookup + $out).
  4. Compare the number of database queries needed to show a post with its comments.

PART B  Try it yourself: a post with 10,000 comments
  Why embedding becomes a problem:
    - BSON documents are capped at 16 MB; an array that grows without bound will eventually
      hit that hard limit and inserts/updates start failing.
    - Every read of the post loads ALL comments, even when the page shows only 20.
    - Every new comment rewrites a bigger and bigger document and bloats the cache.
    - Indexes on the array become huge multikey indexes (one entry per comment).
  Alternatives demonstrated:
    1. Reference design + index on (post_id, created) + pagination
    2. Subset pattern: the post embeds only the latest few comments plus a comment_count;
       the full history stays in the comments collection.
    (Bucket pattern - e.g. 100 comments per bucket document - is a third option.)
"""

import sys, os, time
from datetime import datetime, timedelta
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import bson
from config.connection import get_db, reset_collection, banner
from rich.console import Console
from rich.table import Table

console = Console()

MAX_BSON = 16 * 1024 * 1024  # MongoDB's per-document limit


# ------------------------------------------------------------------- PART A
POSTS = [
    {"title": "Why NoSQL Matters for AI", "author": "arjun", "tags": ["nosql", "ai"], "created": "2024-01-15"},
    {"title": "MongoDB Aggregation Tips", "author": "sneha", "tags": ["mongodb", "aggregation"], "created": "2024-01-20"},
    {"title": "Vector Search Deep Dive", "author": "kavya", "tags": ["vector", "ai", "search"], "created": "2024-02-01"},
    {"title": "CAP Theorem Explained", "author": "arjun", "tags": ["cap", "distributed"], "created": "2024-02-10"},
    {"title": "Graph Databases for Fraud", "author": "rahul", "tags": ["neo4j", "fraud", "graph"], "created": "2024-02-15"},
]

# (post index, comment text, author): 10 comments in total
COMMENTS = [
    (0, "Great overview!", "reader1"), (0, "I prefer SQL though", "reader2"),
    (1, "The $lookup stage is powerful", "reader4"), (1, "Can you cover $facet next?", "reader1"),
    (2, "HNSW vs IVF comparison?", "reader6"), (2, "How does this scale?", "reader2"),
    (3, "AP systems are underrated", "reader7"), (3, "Good for interviews too", "reader3"),
    (4, "Neo4j Cypher is intuitive", "reader8"), (4, "Graph + Vector hybrid?", "reader6"),
]


def part_a(db):
    banner("PART A: Lab 3.2 Tasks")

    # ---- Task 1: referenced design
    print("=== Task 1: Referenced design (posts + comments collections) ===")
    posts = reset_collection("chapter-03", "blog_posts")
    comments = reset_collection("chapter-03", "blog_comments")
    post_ids = posts.insert_many([dict(p) for p in POSTS]).inserted_ids
    comments.insert_many([{"post_id": post_ids[i], "text": t, "author": a} for i, t, a in COMMENTS])
    comments.create_index("post_id")
    print(f"  Inserted {posts.count_documents({})} posts and {comments.count_documents({})} comments")

    # ---- Task 2: $lookup in a single query
    print("\n=== Task 2: Post + comments with $lookup (1 query) ===")
    pipeline = [
        {"$match": {"_id": post_ids[0]}},
        {"$lookup": {"from": "blog_comments", "localField": "_id", "foreignField": "post_id", "as": "comments"}},
    ]
    t0 = time.perf_counter()
    result = list(posts.aggregate(pipeline))[0]
    lookup_ms = (time.perf_counter() - t0) * 1000
    print(f"  '{result['title']}' -> {len(result['comments'])} comments ({lookup_ms:.2f} ms)")
    for c in result["comments"]:
        print(f"    - {c['author']}: {c['text']}")

    # Same result without $lookup, to count queries honestly
    t0 = time.perf_counter()
    post = posts.find_one({"_id": post_ids[0]})                  # query 1
    post_comments = list(comments.find({"post_id": post_ids[0]}))  # query 2
    two_query_ms = (time.perf_counter() - t0) * 1000

    # ---- Task 3: migrate to embedded using an aggregation pipeline
    print("\n=== Task 3: Migrate to embedded design (aggregation pipeline with $out) ===")
    migrate = [
        {"$lookup": {"from": "blog_comments", "localField": "_id", "foreignField": "post_id", "as": "comments"}},
        {"$project": {"comments.post_id": 0}},        # the parent is now implied by nesting
        {"$out": "blog_posts_embedded"},
    ]
    list(posts.aggregate(migrate))
    embedded = db["blog_posts_embedded"]
    migrated_comments = sum(len(p["comments"]) for p in embedded.find())
    ok = (embedded.count_documents({}) == posts.count_documents({})
          and migrated_comments == comments.count_documents({}))
    print(f"  Migrated {embedded.count_documents({})} posts with {migrated_comments} embedded comments")
    print(f"  Migration check: {'[OK] counts match the referenced design' if ok else '[FAIL] counts differ'}")

    # ---- Task 4: compare queries
    print("\n=== Task 4: Queries needed to display a post with its comments ===")
    t0 = time.perf_counter()
    emb_post = embedded.find_one({"_id": post_ids[0]})           # one find, no join
    embedded_ms = (time.perf_counter() - t0) * 1000
    print(f"  Embedded: '{emb_post['title']}' -> {len(emb_post['comments'])} comments")

    table = Table(title="Query Comparison", show_lines=True)
    table.add_column("Design / method", style="cyan", width=34)
    table.add_column("DB queries", width=11)
    table.add_column("Time (ms)", width=10)
    table.add_row("Referenced, two separate queries", "2", f"{two_query_ms:.2f}")
    table.add_row("Referenced, $lookup", "1", f"{lookup_ms:.2f}")
    table.add_row("Embedded, find_one", "1", f"{embedded_ms:.2f}")
    console.print(table)
    print("  (timings on 10 comments are tiny and noisy; the query COUNT is what matters here)")


# ------------------------------------------------------------------- PART B
def make_comment(i, post_id=None, text_len=300):
    c = {"text": f"Comment #{i}: " + ("lorem ipsum " * 40)[:text_len],
         "author": f"user{i % 500}",
         "created": datetime(2024, 3, 1) + timedelta(minutes=i)}
    if post_id is not None:
        c["post_id"] = post_id
    return c


def kb(n):
    return f"{n / 1024:,.1f} KB"


def part_b(db):
    banner("PART B: Try It Yourself - A Post With 10,000 Comments")
    n = 10_000
    post_base = {"title": "The Viral Post", "author": "arjun", "tags": ["viral"], "created": "2024-03-01"}

    # ---- Problem: embedding 10,000 comments
    print("=== The problem: embedding 10,000 comments ===")
    embedded_doc = {**post_base, "comments": [make_comment(i) for i in range(n)]}
    size = len(bson.encode(embedded_doc))
    per_comment = size / n
    capacity = int(MAX_BSON / per_comment)
    print(f"  Embedded post document size : {kb(size)} ({size / MAX_BSON:.0%} of the 16 MB limit)")
    print(f"  Average size per comment    : {per_comment:,.0f} bytes")
    print(f"  Hard cap at this comment size: about {capacity:,} comments, then writes fail")

    big = {**post_base, "comments": [make_comment(i, text_len=1500) for i in range(n)]}
    big_size = len(bson.encode(big))
    print(f"  With longer comments (~1.5 KB each) the doc would be {big_size / 1024 / 1024:.1f} MB")
    try:
        db["viral_embedded_too_big"].insert_one(big)
        print("  [ERROR] insert should have been rejected!")
    except Exception as e:
        print(f"  [OK] Insert rejected: {type(e).__name__}")

    emb_col = reset_collection("chapter-03", "viral_post_embedded")
    emb_id = emb_col.insert_one(embedded_doc).inserted_id

    # ---- Alternative 1: referenced + index + pagination
    ref_posts = reset_collection("chapter-03", "viral_post_ref")
    ref_comments = reset_collection("chapter-03", "viral_comments")
    ref_id = ref_posts.insert_one(dict(post_base)).inserted_id
    ref_comments.insert_many([make_comment(i, ref_id) for i in range(n)])
    ref_comments.create_index([("post_id", 1), ("created", -1)])

    # ---- Alternative 2: subset pattern (latest 5 embedded + count)
    sub_posts = reset_collection("chapter-03", "viral_post_subset")
    latest = sorted((make_comment(i) for i in range(n)), key=lambda c: c["created"], reverse=True)[:5]
    sub_id = sub_posts.insert_one({**post_base, "comment_count": n, "recent_comments": latest}).inserted_id

    # ---- Measure: rendering page 1 of the post (title + 20 newest comments)
    print("\n=== Rendering the post page (post + 20 newest comments) ===")

    def timed(fn, runs=5):
        best = float("inf")
        for _ in range(runs):
            t0 = time.perf_counter()
            out = fn()
            best = min(best, (time.perf_counter() - t0) * 1000)
        return out, best

    # Embedded: must pull the whole document to show 20 comments
    doc, emb_ms = timed(lambda: emb_col.find_one({"_id": emb_id}))
    emb_bytes = len(bson.encode(doc))

    # Referenced: post + one indexed, limited query
    def ref_page():
        p = ref_posts.find_one({"_id": ref_id})
        cs = list(ref_comments.find({"post_id": ref_id}).sort("created", -1).limit(20))
        return p, cs
    (p, cs), ref_ms = timed(ref_page)
    ref_bytes = len(bson.encode(p)) + sum(len(bson.encode(c)) for c in cs)

    # Subset: one read, small document, count already stored
    sub_doc, sub_ms = timed(lambda: sub_posts.find_one({"_id": sub_id}))
    sub_bytes = len(bson.encode(sub_doc))

    table = Table(title="Page Load: Embedded vs Alternatives (10,000 comments)", show_lines=True)
    table.add_column("Design", style="cyan", width=34)
    table.add_column("Queries", width=8)
    table.add_column("Data transferred", width=17)
    table.add_column("Best time (ms)", width=14)
    table.add_row("Embedded (all 10,000 inside)", "1", kb(emb_bytes), f"{emb_ms:.2f}")
    table.add_row("Referenced + index + limit 20", "2", kb(ref_bytes), f"{ref_ms:.2f}")
    table.add_row("Subset (latest 5 + count)", "1", kb(sub_bytes), f"{sub_ms:.2f}")
    console.print(table)

    # ---- Keeping the subset pattern up to date when a comment arrives
    print("\n=== Subset pattern: adding a new comment ===")
    new_c = make_comment(n + 1)
    new_c["text"] = "Brand new comment!"
    ref_comments.insert_one({**new_c, "post_id": sub_id})   # full history lives in comments collection
    sub_posts.update_one(
        {"_id": sub_id},
        {"$inc": {"comment_count": 1},
         "$push": {"recent_comments": {"$each": [new_c], "$sort": {"created": -1}, "$slice": 5}}},
    )
    after = sub_posts.find_one({"_id": sub_id})
    print(f"  comment_count = {after['comment_count']:,}, recent_comments kept at {len(after['recent_comments'])}")
    print(f"  Newest comment shown: '{after['recent_comments'][0]['text']}'")

    # ---- Pagination for 'load more'
    print("\n=== 'Load more': range-based pagination (no skip) ===")
    page1 = list(ref_comments.find({"post_id": ref_id}).sort("created", -1).limit(20))
    cursor = page1[-1]["created"]
    page2 = list(ref_comments.find({"post_id": ref_id, "created": {"$lt": cursor}}).sort("created", -1).limit(20))
    print(f"  Page 1: {len(page1)} comments, Page 2: {len(page2)} comments (continues from the last 'created' value)")

    # ---- Summary
    print("\n=== Recommendation ===")
    summary = Table(show_lines=True)
    summary.add_column("Design", style="cyan", width=24)
    summary.add_column("Use when", width=40)
    summary.add_column("Weakness", width=36)
    summary.add_row("Embed all comments", "Few, bounded comments (< ~100)", "16 MB cap, big reads and writes")
    summary.add_row("Reference + pagination", "Comments are unbounded or large", "Needs a second query")
    summary.add_row("Subset pattern (best here)", "Page shows a few recent comments", "Count/recent list must be maintained")
    summary.add_row("Bucket pattern", "Time-ordered streams of small items", "More complex updates and queries")
    console.print(summary)
    print("\n  Answer: embedding 10,000 comments is problematic because the array is unbounded, risks the 16 MB")
    print("  limit and makes every read and write move the whole document. Use the subset pattern on top of a")
    print("  referenced comments collection indexed on (post_id, created), with pagination for older comments.")


def main():
    banner("Lab 3.2: Embed vs Reference (Tasks + Try It Yourself)")
    db = get_db("chapter-03")
    part_a(db)
    part_b(db)
    banner("Lab 3.2 Complete")


if __name__ == "__main__":
    main()
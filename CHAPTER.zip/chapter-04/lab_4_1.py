"""Lab 4.1 (Amazon dataset) - Product Query API + $regex text search

Uses the Kaggle "Amazon Sales Dataset" (amazon.csv, ~1,465 rows, 16 columns):
  https://www.kaggle.com/datasets/karkavelrajaj/amazon-sales-dataset
Download amazon.csv and put it next to this script, or set AMAZON_CSV=/path/to/amazon.csv

The CSV has no inventory data and its prices are in rupees, so the loader:
  - converts the selling price (discounted_price) to USD at a fixed demo rate (INR_TO_USD)
  - simulates 'stock' with a seeded random generator (about 15% out of stock)
  - builds 'tags' from the first two category levels, plus 'wireless' / 'premium'
Everything else (name, rating, rating_count, category, ...) comes from the file.

PART A  Lab 4.1 tasks (validation, comparison / logical / array operators, pagination)
PART B  Activity: case-insensitive $regex search on product name
"""

import sys, os, re, csv, math, random
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config.connection import get_db, banner
from rich.console import Console
from rich.table import Table

from rich.markup import escape      # <-- add this line



console = Console()

INR_TO_USD = 0.012          # demo exchange rate (assumption, not from the dataset)
PREMIUM_USD = 60            # products at or above this price get the 'premium' tag
OUT_OF_STOCK_RATE = 0.15
SEED = 42
KAGGLE_URL = "https://www.kaggle.com/datasets/karkavelrajaj/amazon-sales-dataset"

PRODUCT_VALIDATOR = {
    "$jsonSchema": {
        "bsonType": "object",
        "required": ["name", "price", "stock", "tags"],
        "properties": {
            "name": {"bsonType": "string", "minLength": 1},
            "price": {"bsonType": "number", "minimum": 0, "exclusiveMinimum": True},
            "stock": {"bsonType": "int", "minimum": 0},
            "tags": {"bsonType": "array", "items": {"bsonType": "string"}},
        },
    }
}


# ----------------------------------------------------------------- loading
def find_csv():
    here = os.path.dirname(os.path.abspath(__file__))
    candidates = [os.getenv("AMAZON_CSV"), os.path.join(here, "amazon.csv"),
                  os.path.join(here, "data", "amazon.csv"), "amazon.csv"]
    return next((p for p in candidates if p and os.path.isfile(p)), None)


def clean_number(text):
    """'₹1,099' -> 1099.0, '24,269' -> 24269.0, anything unparseable -> None."""
    cleaned = re.sub(r"[^\d.]", "", text or "")
    try:
        return float(cleaned)
    except ValueError:
        return None


def build_product(row, rng):
    name = (row.get("product_name") or "").strip()
    price_inr = clean_number(row.get("discounted_price"))
    if not name or not price_inr:
        return None
    price = round(price_inr * INR_TO_USD, 2)
    if price <= 0:
        return None

    levels = [c.strip() for c in (row.get("category") or "").split("|") if c.strip()]
    tags = [lvl.lower() for lvl in levels[:2]]
    if re.search(r"wireless|bluetooth", name, re.I):
        tags.append("wireless")
    if price >= PREMIUM_USD:
        tags.append("premium")

    doc = {
        "product_id": row.get("product_id"),
        "name": name,
        "price": price,
        "stock": 0 if rng.random() < OUT_OF_STOCK_RATE else rng.randint(1, 500),
        "tags": tags,
        "category": levels,
        "price_inr": price_inr,
    }
    list_price = clean_number(row.get("actual_price"))
    rating = clean_number(row.get("rating"))
    rating_count = clean_number(row.get("rating_count"))
    if list_price:
        doc["list_price_inr"] = list_price
    if rating is not None and rating <= 5:
        doc["rating"] = rating
    if rating_count is not None:
        doc["rating_count"] = int(rating_count)
    return doc


def load_products(path):
    rng = random.Random(SEED)
    products, seen = [], set()
    with open(path, newline="", encoding="utf-8-sig") as f:
        for row in csv.DictReader(f):
            pid = row.get("product_id")
            if pid in seen:                  # the CSV repeats a product once per review
                continue
            seen.add(pid)
            doc = build_product(row, rng)
            if doc:
                products.append(doc)
    return products


# ----------------------------------------------------------------- helpers
def show(col, title, query, sort=("name", 1), limit=10):
    total = col.count_documents(query)
    table = Table(title=f"{title}  [{total} match(es), showing up to {limit}]")
    table.add_column("Name", style="cyan", width=44)
    table.add_column("Price", justify="right", width=9)
    table.add_column("Stock", justify="right", width=6)
    table.add_column("Tags", width=40)
    for p in col.find(query, {"_id": 0}).sort(*sort).limit(limit):
        table.add_row(p["name"][:42], f"${p['price']:.2f}", str(p["stock"]), ", ".join(p["tags"]))
    console.print(table)
    print()


def get_products_page(col, page, per_page, query=None):
    """One page of products sorted by name, plus paging metadata."""
    if page < 1 or per_page < 1:
        raise ValueError("page and per_page must be 1 or greater")
    query = query or {}
    total = col.count_documents(query)
    items = list(col.find(query, {"_id": 0}).sort("name", 1)
                 .skip((page - 1) * per_page).limit(per_page))
    return {"page": page, "per_page": per_page, "total_items": total,
            "total_pages": max(1, math.ceil(total / per_page)), "items": items}


def search_products(col, term, mode="contains", escape=True, limit=0):
    """Case-insensitive name search with $regex (contains / starts / ends)."""
    term = term.strip()
    if not term:
        return []
    pattern = re.escape(term) if escape else term
    if mode == "starts":
        pattern = "^" + pattern
    elif mode == "ends":
        pattern = pattern + "$"
    cursor = col.find({"name": {"$regex": pattern, "$options": "i"}},
                      {"_id": 0, "name": 1, "price": 1}).sort("name", 1)
    return list(cursor.limit(limit) if limit else cursor)


def report(label, results, preview=3):
    names = "; ".join(r["name"][:38] for r in results[:preview]) or "(no matches)"
    more = f" ... +{len(results) - preview} more" if len(results) > preview else ""
    print(f"  {label:<34} -> {len(results):>4}: {names}{more}")


# ------------------------------------------------------------------ PART A
def part_a(col):
    banner("PART A: Lab 4.1 Tasks on Amazon Data")

    print("=== Task 1: Validation ===")
    for label, doc in [
        ("negative price", {"name": "Bad", "price": -5.0, "stock": 1, "tags": []}),
        ("zero price", {"name": "Bad", "price": 0, "stock": 1, "tags": []}),
        ("negative stock", {"name": "Bad", "price": 5.0, "stock": -1, "tags": []}),
        ("fractional stock", {"name": "Bad", "price": 5.0, "stock": 2.5, "tags": []}),
        ("tags not strings", {"name": "Bad", "price": 5.0, "stock": 1, "tags": [1]}),
    ]:
        try:
            col.insert_one(doc)
            print(f"  [ERROR] '{label}' should have been rejected!")
        except Exception:
            print(f"  [OK] Rejected: {label}")
    print()

    print("=== Task 2: Comparison operators ===")
    show(col, "price between $20 and $50 ($gte/$lte)", {"price": {"$gte": 20, "$lte": 50}}, ("price", 1))
    show(col, "out of stock (stock == 0)", {"stock": {"$eq": 0}})

    print("=== Task 3: Logical operators ===")
    show(col, "out of stock OR price > $100 ($or)",
         {"$or": [{"stock": 0}, {"price": {"$gt": 100}}]}, ("price", -1))
    show(col, "in stock AND tagged 'premium' ($and)",
         {"$and": [{"stock": {"$gt": 0}}, {"tags": "premium"}]}, ("price", -1))

    print("=== Task 4: Array operators ===")
    show(col, "tags contain BOTH 'electronics' AND 'wireless' ($all)",
         {"tags": {"$all": ["electronics", "wireless"]}})
    show(col, "exactly 2 tags ($size)", {"tags": {"$size": 2}})

    print("=== Task 5: Pagination ===")
    per_page = 8
    first = get_products_page(col, 1, per_page)
    print(f"  {first['total_items']} products, {per_page} per page -> {first['total_pages']} pages")
    for page in (1, 2, first["total_pages"]):
        r = get_products_page(col, page, per_page)
        print(f"  Page {page}/{r['total_pages']}: " + "; ".join(p["name"][:22] for p in r["items"][:3]) + " ...")
    beyond = get_products_page(col, first["total_pages"] + 1, per_page)
    print(f"  Page past the end -> {len(beyond['items'])} items")


# ------------------------------------------------------------------ PART B
def part_b(col):
    banner("PART B: Activity - Text Search with $regex")

    print("=== Name contains a search string (case-insensitive) ===")
    for term in ["usb", "USB", "bluetooth", "charger"]:
        report(f"search '{term}'", search_products(col, term))

    print("\n=== Starts with / ends with ===")
    report("starts with 'boat'", search_products(col, "boat", mode="starts"))
    report("ends with 'cable'", search_products(col, "cable", mode="ends"))

    print("\n=== Special characters ===")
    report("'(1.5 m' escaped (correct)", search_products(col, "(1.5 m"))
    try:
        search_products(col, "(1.5 m", escape=False)
    except Exception as e:
        print(f"  '(1.5 m' unescaped raises {type(e).__name__} (invalid regex)")
    print(f"  Blank search returns {len(search_products(col, '  '))} results (guarded)")

    print("\n=== Autocomplete style (limit 5) ===")
    report("search 'smart', limit 5", search_products(col, "smart", limit=5), preview=5)

    print("\n=== Performance ===")
    col.create_index("name")
    table = Table(show_lines=True)
    table.add_column("Query", style="cyan", width=30)
    table.add_column("Keys examined", justify="right", width=14)
    table.add_column("Docs examined", justify="right", width=14)
    table.add_column("Returned", justify="right", width=9)
    for label, q in [("case-insensitive contains", {"name": {"$regex": "usb", "$options": "i"}}),
                     ("case-sensitive prefix ^boAt", {"name": {"$regex": "^boAt"}})]:
        s = col.find(q).explain()["executionStats"]
        table.add_row(label, str(s["totalKeysExamined"]), str(s["totalDocsExamined"]), str(s["nReturned"]))
    console.print(table)
    print("  Unanchored / case-insensitive regex scans every key; use $text or Atlas Search at scale.")


def main():
    banner("Lab 4.1: Amazon Product Dataset")
    path = find_csv()
    if not path:
        print("[ERROR] amazon.csv not found.")
        print(f"  Download it from {KAGGLE_URL}")
        print("  then place it next to this script or set AMAZON_CSV=/path/to/amazon.csv")
        return

    products = load_products(path)
    print(f"[OK] Read {len(products)} unique products from {path}")
    print(f"     prices converted at 1 INR = {INR_TO_USD} USD; stock is simulated (seed {SEED})\n")

    db = get_db("chapter-04")
    if "amazon_products" in db.list_collection_names():
        db.drop_collection("amazon_products")
    db.create_collection("amazon_products", validator=PRODUCT_VALIDATOR)
    col = db["amazon_products"]
    col.insert_many(products)
    print(f"[OK] Inserted {col.count_documents({})} products into 'amazon_products' with validation\n")

    part_a(col)
    part_b(col)
    banner("Lab 4.1 (Amazon) Complete")


if __name__ == "__main__":
    main()
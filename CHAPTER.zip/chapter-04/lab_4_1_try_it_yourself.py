"""Lab 4.1 - Activity (Amazon dataset): Text Search with $regex

Adds a text search capability that finds products whose name contains a search
string (case-insensitive) using the $regex operator, on the Kaggle Amazon Sales
Dataset.

This file reuses the CSV loader from lab_4_1_amazon.py, so keep both files in the
same folder. If the 'amazon_products' collection already exists (created by
lab_4_1_amazon.py) it is reused; otherwise it is built from amazon.csv.
"""

import sys, os, re
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config.connection import get_db, banner
from lab_4_1 import find_csv, load_products, PRODUCT_VALIDATOR, KAGGLE_URL
from rich.console import Console
from rich.markup import escape as markup_escape
from rich.table import Table

console = Console()


# ------------------------------------------------------------ search functions
def build_pattern(term, mode="contains", escape=True):
    pattern = re.escape(term) if escape else term
    if mode == "starts":
        return "^" + pattern
    if mode == "ends":
        return pattern + "$"
    return pattern


def search_products(col, term, mode="contains", escape=True, extra=None, sort=("rating_count", -1),
                    limit=0, skip=0):
    """Case-insensitive $regex search on the product name.

    term:  text to look for (escaped by default so '(' or '+' are plain characters)
    mode:  'contains' | 'starts' | 'ends'
    extra: additional filter merged into the query (price, stock, tags, ...)
    """
    term = term.strip()
    if not term:
        return [], 0
    query = {"name": {"$regex": build_pattern(term, mode, escape), "$options": "i"}}
    if extra:
        query = {"$and": [query, extra]}
    total = col.count_documents(query)
    cursor = col.find(query, {"_id": 0}).sort(*sort)
    if skip:
        cursor = cursor.skip(skip)
    if limit:
        cursor = cursor.limit(limit)
    return list(cursor), total


def search_all_words(col, text, **kwargs):
    """Every word must appear in the name, in any order ('cable usb' == 'usb cable')."""
    words = [w for w in text.split() if w]
    if not words:
        return [], 0
    clauses = [{"name": {"$regex": re.escape(w), "$options": "i"}} for w in words]
    query = {"$and": clauses}
    total = col.count_documents(query)
    cursor = col.find(query, {"_id": 0}).sort("rating_count", -1)
    if kwargs.get("limit"):
        cursor = cursor.limit(kwargs["limit"])
    return list(cursor), total


# -------------------------------------------------------------------- display
def highlight(name, term, width=46):
    """Truncate a name and bold the matched text (rich markup)."""
    name = name[:width]
    parts = re.split(f"({re.escape(term)})", name, flags=re.I) if term else [name]
    return "".join(f"[bold yellow]{markup_escape(p)}[/]" if term and p.lower() == term.lower()
                   else markup_escape(p) for p in parts)


def show(title, results, total, term=None):
    table = Table(title=f"{title}  [{total} match(es), showing {len(results)}]")
    table.add_column("Name", width=48)
    table.add_column("Price", justify="right", width=9)
    table.add_column("Rating", justify="right", width=7)
    table.add_column("# Ratings", justify="right", width=10)
    for p in results:
        table.add_row(highlight(p["name"], term), f"${p['price']:.2f}", str(p.get("rating", "-")),
                      f"{p.get('rating_count', 0):,}")
    console.print(table)
    print()


def get_collection(db):
    col = db["amazon_products"]
    if col.count_documents({}) > 0:
        return col
    path = find_csv()
    if not path:
        print("[ERROR] amazon.csv not found and 'amazon_products' is empty.")
        print(f"  Download it from {KAGGLE_URL}")
        print("  then place it next to this script or set AMAZON_CSV=/path/to/amazon.csv")
        return None
    if "amazon_products" in db.list_collection_names():
        db.drop_collection("amazon_products")
    db.create_collection("amazon_products", validator=PRODUCT_VALIDATOR)
    col = db["amazon_products"]
    col.insert_many(load_products(path))
    return col


def main():
    banner("Lab 4.1 Activity (Amazon): Text Search with $regex")
    db = get_db("chapter-04")
    col = get_collection(db)
    if col is None:
        return
    print(f"[OK] Searching {col.count_documents({})} Amazon products\n")

    # 1. Name contains a search string
    print("=== 1. Name contains a search string ===")
    print('  Raw query: {"name": {"$regex": "usb", "$options": "i"}}\n')
    results, total = search_products(col, "usb", limit=5)
    show("search 'usb' (most-rated first)", results, total, "usb")

    # 2. Case-insensitivity
    print("=== 2. Case-insensitive ($options: 'i') ===")
    for term in ["charger", "CHARGER", "ChArGeR"]:
        _, n = search_products(col, term)
        print(f"  search '{term}': {n} match(es)")
    sensitive = col.count_documents({"name": {"$regex": "charger"}})
    print(f"  Without the 'i' option, 'charger' matches only {sensitive} (exact lowercase only)\n")

    # 3. Anchors
    print("=== 3. Starts with / ends with ===")
    results, total = search_products(col, "boat", mode="starts", limit=3)
    show("name starts with 'boat'", results, total, "boat")
    results, total = search_products(col, "cable", mode="ends", limit=3)
    show("name ends with 'cable'", results, total, "cable")

    # 4. Several words, any order
    print("=== 4. Multiple words (all must appear, any order) ===")
    _, a = search_all_words(col, "usb cable")
    _, b = search_all_words(col, "cable usb")
    print(f"  'usb cable' -> {a} matches, 'cable usb' -> {b} matches (same set)")
    results, total = search_all_words(col, "wireless mouse", limit=3)
    show("words: 'wireless' + 'mouse'", results, total)

    # 5. Combine $regex with other operators
    print("=== 5. $regex combined with other filters ===")
    results, total = search_products(col, "cable", extra={"stock": {"$gt": 0}, "price": {"$lt": 5}},
                                     sort=("price", 1), limit=5)
    show("name contains 'cable' AND in stock AND price < $5 (cheapest first)", results, total, "cable")
    results, total = search_products(col, "mouse", extra={"tags": "computers&accessories"}, limit=3)
    show("name contains 'mouse' AND tagged 'computers&accessories'", results, total, "mouse")

    # 6. Paginated search results
    print("=== 6. Paginated search results ===")
    per_page = 5
    _, total = search_products(col, "cable")
    pages = max(1, -(-total // per_page))
    print(f"  'cable': {total} matches -> {pages} pages of {per_page}")
    for page in (1, 2):
        results, _ = search_products(col, "cable", sort=("name", 1), limit=per_page, skip=(page - 1) * per_page)
        print(f"  Page {page}: " + "; ".join(r["name"][:24] for r in results))

    # 7. Special characters and empty input
    print("\n=== 7. Special characters and empty input ===")
    _, escaped = search_products(col, "(1.5 m")
    print(f"  '(1.5 m' escaped (correct): {escaped} match(es)")
    try:
        search_products(col, "(1.5 m", escape=False)
    except Exception as e:
        print(f"  '(1.5 m' unescaped raises {type(e).__name__} (invalid regex)")
    _, blank = search_products(col, "   ")
    print(f"  Blank search returns {blank} results (guarded, not 'match everything')")

    # 8. Performance
    print("\n=== 8. Performance: $regex and indexes ===")
    col.create_index("name")
    table = Table(show_lines=True)
    table.add_column("Query", style="cyan", width=30)
    table.add_column("Keys examined", justify="right", width=14)
    table.add_column("Docs examined", justify="right", width=14)
    table.add_column("Returned", justify="right", width=9)
    for label, q in [("case-insensitive contains", {"name": {"$regex": "usb", "$options": "i"}}),
                     ("case-sensitive prefix ^boAt", {"name": {"$regex": "^boAt"}})]:
        s = col.find(q).explain()["executionStats"]
        table.add_row(label, str(s["totalKeysExamined"]), str(s["totalDocsExamined"]), str(s["nReturned"]))
    console.print(table)
    print("  Unanchored / case-insensitive regex scans every key. For real text search on a large")
    print("  catalog, create a text index ($text) or use Atlas Search.")

    banner("Lab 4.1 Activity (Amazon) Complete")


if __name__ == "__main__":
    main()
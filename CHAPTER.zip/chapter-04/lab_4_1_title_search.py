"""Lab 4.1 - Activity: Text Search with $regex (field: "title") + optional HTML search page

The task text says 'name', but the product export uses the field "title", so the search
filter targets that field:

    {"title": {"$regex": term, "$options": "i"}}

Points covered
  - "i" makes the search case-insensitive ("cotton" and "Cotton" find the same products)
  - re.escape(term): the term comes from a user; typing "(pack" unescaped is an invalid
    regex and MongoDB raises OperationFailure
  - explain("executionStats"): judge an index by the BOUNDS and keys examined, not by the
    stage name (every version says IXSCAN):
        /cotton/i   -> bounds ["", {})  = walks the whole index
        /^Cotton/   -> a real range     = scans only a couple of keys
        /^Cotton/i  -> still scans broadly (a case-insensitive regex cannot form a range)
  - real case-insensitive search: a text index, or a lower-cased copy of the field with an
    anchored regex
  - optional: writes search_demo.html, a search box that rebuilds the filter and shows
    matching products live. The JSON is inlined because a file:// page cannot fetch local
    JSON (CORS). Rows that have an "image" are shown with their picture.

Data: set PRODUCTS_JSON=/path/to/export.json (a list of objects with "title", and optionally
"price" and "image"), or the script uses a built-in sample catalog.
"""

import sys, os, re, json, random
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pymongo.errors import OperationFailure
from config.connection import get_db, banner
from rich.console import Console
from rich.table import Table
from rich.markup import escape      # <-- add this line


console = Console()

FIELD = "title"
HTML_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "search_demo.html")


# ---------------------------------------------------------------------- data
SAMPLE_TITLES = [
    ("Cotton Crew Neck T-Shirt (Pack of 3)", 24.99), ("Organic Cotton Hoodie", 54.00),
    ("cotton socks - 6 pack", 12.50), ("COTTON Bedsheet Set, Queen", 39.99),
    ("Cottonwood Hiking Boots", 89.00), ("Pure Cotton Handkerchiefs (pack of 12)", 9.99),
    ("Linen Button-Down Shirt", 44.00), ("Wool Blend Sweater", 69.00),
    ("Denim Jacket", 79.50), ("Slim Fit Chinos", 49.00),
]
FILLER_STYLES = ["Linen", "Wool", "Denim", "Silk", "Fleece", "Nylon", "Leather", "Polyester"]
FILLER_ITEMS = ["Shirt", "Jacket", "Scarf", "Trousers", "Cap", "Gloves", "Dress", "Shorts"]


def load_products():
    path = os.getenv("PRODUCTS_JSON")
    if path and os.path.isfile(path):
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        data = data.get("products", data) if isinstance(data, dict) else data
        return [{k: v for k, v in row.items() if k != "_id"} for row in data if row.get(FIELD)]

    rng = random.Random(7)
    products = [{"title": t, "price": p, "image": None} for t, p in SAMPLE_TITLES]
    for i in range(3000):      # filler so index scans are visibly different in size
        products.append({"title": f"{rng.choice(FILLER_STYLES)} {rng.choice(FILLER_ITEMS)} {i}",
                         "price": round(rng.uniform(8, 120), 2), "image": None})
    return products


# -------------------------------------------------------------------- search
def search_titles(col, term, limit=0):
    """Case-insensitive 'title contains term' search (the term is escaped)."""
    term = term.strip()
    if not term:
        return []
    query = {FIELD: {"$regex": re.escape(term), "$options": "i"}}
    cursor = col.find(query, {"_id": 0, FIELD: 1, "price": 1}).sort(FIELD, 1)
    return list(cursor.limit(limit) if limit else cursor)


def find_stage(plan, name):
    """Walk an explain plan tree and return the first stage with the given name."""
    if not isinstance(plan, dict):
        return None
    if plan.get("stage") == name:
        return plan
    children = [plan.get("inputStage"), plan.get("queryPlan")] + list(plan.get("inputStages", []))
    for child in children:
        found = find_stage(child, name)
        if found:
            return found
    return None


def explain_row(col, label, query):
    out = col.database.command("explain", {"find": col.name, "filter": query},
                               verbosity="executionStats")
    stats = out["executionStats"]
    ix = find_stage(out["queryPlanner"]["winningPlan"], "IXSCAN")
    stage = "IXSCAN" if ix else "COLLSCAN/other"
    bounds = ""
    if ix:
        key_bounds = list(ix.get("indexBounds", {}).values())
        bounds = " | ".join(key_bounds[0]) if key_bounds else ""
    return (label, stage, str(stats["totalKeysExamined"]), str(stats["totalDocsExamined"]),
            str(stats["nReturned"]), bounds[:60])


# ---------------------------------------------------------------------- HTML
HTML = """<!doctype html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Product Title Search</title>
<style>
:root{--bg:#fff;--fg:#1d1d1f;--muted:#6b6b70;--card:#f5f5f7;--line:#dcdce0;--hl:#ffe45c;--err:#b3261e}
@media (prefers-color-scheme:dark){:root{--bg:#18181b;--fg:#ececef;--muted:#9a9aa2;--card:#26262b;--line:#3a3a41;--hl:#7a6a00;--err:#ff8a80}}
body{margin:0;padding:16px;background:var(--bg);color:var(--fg);font:15px/1.5 system-ui,sans-serif}
main{max-width:860px;margin:0 auto}
input[type=search]{width:100%;box-sizing:border-box;padding:10px 12px;font-size:16px;border:1px solid var(--line);border-radius:8px;background:var(--card);color:var(--fg)}
label{margin-right:16px;color:var(--muted);font-size:14px}
pre{background:var(--card);padding:10px 12px;border-radius:8px;overflow-x:auto;margin:12px 0}
.err{color:var(--err)} .muted{color:var(--muted)}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:12px;margin-top:12px}
.card{background:var(--card);border:1px solid var(--line);border-radius:10px;overflow:hidden}
.card .pic{height:110px;display:flex;align-items:center;justify-content:center;font-size:36px;color:var(--muted);background:var(--line)}
.card img{width:100%;height:110px;object-fit:cover}
.card .body{padding:8px 10px;font-size:14px}
mark{background:var(--hl);color:inherit;border-radius:2px}
</style></head><body><main>
<h1 style="font-size:20px">Search products by __FIELD__</h1>
<input id="q" type="search" placeholder="Try: cotton, Cotton, (pack" autofocus>
<p><label><input id="ci" type="checkbox" checked> case-insensitive ("i")</label>
<label><input id="esc" type="checkbox" checked> escape special characters (re.escape)</label></p>
<pre id="filter"></pre>
<p id="status" class="muted"></p>
<div id="results" class="grid"></div>
</main>
<script>
const DATA = __DATA__;
const FIELD = "__FIELD__";
const $ = id => document.getElementById(id);
const escapeRegex = s => s.replace(/[.*+?^${}()|[\\]\\\\]/g, "\\\\$&");

function render() {
  const term = $("q").value.trim(), ci = $("ci").checked, esc = $("esc").checked;
  const filter = {};
  if (term) { filter[FIELD] = {"$regex": term}; if (ci) filter[FIELD]["$options"] = "i"; }
  $("filter").textContent = "find(" + JSON.stringify(filter) + ")";
  const out = $("results"), status = $("status");
  out.textContent = "";
  if (!term) { status.className = "muted"; status.textContent = DATA.length + " products. Type to search."; return; }
  let re;
  try { re = new RegExp(esc ? escapeRegex(term) : term, ci ? "ig" : "g"); }
  catch (e) { status.className = "err"; status.textContent = "OperationFailure: invalid regular expression (turn escaping back on)"; return; }
  const hits = DATA.filter(p => { re.lastIndex = 0; return re.test(p[FIELD] || ""); });
  status.className = "muted";
  status.textContent = hits.length + " of " + DATA.length + " products match";
  hits.slice(0, 60).forEach(p => {
    const card = document.createElement("div"); card.className = "card";
    if (p.image) { const img = document.createElement("img"); img.src = p.image; img.alt = ""; img.loading = "lazy"; card.appendChild(img); }
    else { const pic = document.createElement("div"); pic.className = "pic"; pic.textContent = (p[FIELD] || "?")[0].toUpperCase(); card.appendChild(pic); }
    const body = document.createElement("div"); body.className = "body";
    const title = document.createElement("div"); re.lastIndex = 0;
    let last = 0, m; const text = p[FIELD];
    while ((m = re.exec(text)) !== null) {
      if (m[0] === "") { re.lastIndex++; continue; }
      title.append(text.slice(last, m.index));
      const mk = document.createElement("mark"); mk.textContent = m[0]; title.append(mk);
      last = m.index + m[0].length;
    }
    title.append(text.slice(last));
    body.appendChild(title);
    if (p.price != null) { const pr = document.createElement("div"); pr.className = "muted"; pr.textContent = "$" + Number(p.price).toFixed(2); body.appendChild(pr); }
    card.appendChild(body); out.appendChild(card);
  });
}
["input", "change"].forEach(ev => { $("q").addEventListener(ev, render); $("ci").addEventListener(ev, render); $("esc").addEventListener(ev, render); });
render();
</script></body></html>
"""


def build_html(products, field=FIELD):
    rows = [{field: p.get(field), "price": p.get("price"), "image": p.get("image")} for p in products]
    data = json.dumps(rows, ensure_ascii=False).replace("</", "<\\/")   # safe inside <script>
    return HTML.replace("__DATA__", data).replace("__FIELD__", field)


# ---------------------------------------------------------------------- main
def main():
    banner('Lab 4.1 Activity: $regex Search on "title"')
    db = get_db("chapter-04")
    col = db["catalog_products"]
    col.drop()
    products = load_products()
    for p in products:
        p["title_lower"] = p[FIELD].lower()          # used by the normalized-field approach
    col.insert_many([dict(p) for p in products])
    col.create_index(FIELD)
    print(f"[OK] Inserted {col.count_documents({})} products, index on '{FIELD}'\n")

    print('=== 1. The filter: {"title": {"$regex": term, "$options": "i"}} ===')
    for term in ["cotton", "COTTON", "Cotton"]:
        print(f"  '{term}': {len(search_titles(col, term))} match(es)")
    plain = col.count_documents({FIELD: {"$regex": "cotton"}})
    capital = col.count_documents({FIELD: {"$regex": "Cotton"}})
    print(f"  WITHOUT the 'i' option: 'cotton' -> {plain}, 'Cotton' -> {capital} (treated as different searches)")
    for p in search_titles(col, "cotton", limit=5):
        print(f"    - {p[FIELD]}  ${p['price']:.2f}")

    print("\n=== 2. Escape the term with re.escape() ===")
    print(f"  '(pack' escaped: {len(search_titles(col, '(pack'))} match(es)")
    try:
        col.count_documents({FIELD: {"$regex": "(pack", "$options": "i"}})
    except OperationFailure as e:
        print(f"  '(pack' NOT escaped: OperationFailure (invalid regex): {str(e)[:60]}...")

    print("\n=== 3. explain('executionStats'): read the bounds, not the stage name ===")
    cases = [
        ("/cotton/i", {FIELD: {"$regex": "cotton", "$options": "i"}}),
        ("/^Cotton/", {FIELD: {"$regex": "^Cotton"}}),
        ("/^Cotton/i", {FIELD: {"$regex": "^Cotton", "$options": "i"}}),
    ]
    table = Table(show_lines=True)
    for header, width in [("Pattern", 12), ("Stage", 8), ("Keys", 7), ("Docs", 6), ("Returned", 9), ("Index bounds", 48)]:
        table.add_column(header, width=width)
    for label, query in cases:
        table.add_row(*(escape(cell) for cell in explain_row(col, label, query)))
    console.print(table)
    print("  Every case says IXSCAN. /cotton/i walks the whole index; /^Cotton/ is a real range;")
    print("  /^Cotton/i still scans broadly because a case-insensitive regex cannot narrow the range.\n")

    print("=== 4. Real case-insensitive search ===")
    col.create_index([(FIELD, "text")])
    _, stage, keys, docs, ret, _ = explain_row(col, "$text", {"$text": {"$search": "cotton"}})
    print(f"  a) Text index: {{'$text': {{'$search': 'cotton'}}}} -> {ret} match(es), keys={keys}, docs={docs}")
    print("     (word-based and stemmed: finds whole words like 'cotton', not 'Cottonwood' substrings)")
    col.create_index("title_lower")
    q = {"title_lower": {"$regex": "^" + re.escape("Cotton".lower())}}
    _, stage, keys, docs, ret, bounds = explain_row(col, "title_lower", q)
    print(f"  b) Lower-cased copy + anchored regex: {ret} match(es), keys={keys}, docs={docs}")
    print(f"     bounds: {bounds}  (a real range, and case-insensitive prefix search)")

    print("\n=== 5. Optional: live HTML search page ===")
    with open(HTML_PATH, "w", encoding="utf-8") as f:
        f.write(build_html(products))
    print(f"  Wrote {HTML_PATH}")
    print("  Open it in a browser (works from file://, the product JSON is inlined).")

    banner("Lab 4.1 Activity Complete")


if __name__ == "__main__":
    main()
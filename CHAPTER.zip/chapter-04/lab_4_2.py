"""Lab 4.2 - Activity: Idempotent Bulk Import with Upserts

import_products() can be run any number of times with the same data and never
creates duplicates. Each record is written with an UpdateOne(..., upsert=True)
keyed on a natural identifier (sku), and all records are sent in batched bulk_write calls.

What makes it idempotent:
  1. A stable key (sku) in the filter, so a re-run matches the existing document.
  2. A UNIQUE index on sku, the safety net if two imports run at the same time.
  3. $set with the incoming field values (same data -> same result, nothing modified).
  4. $setOnInsert for values that must only be written once (created_at).
  5. No $inc and no "now()" in $set, because those change the document on every run.
"""

import sys, os
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pymongo import UpdateOne
from pymongo.errors import BulkWriteError
from config.connection import get_db, banner
from rich.console import Console
from rich.table import Table

console = Console()

DUPLICATE_KEY = 11000
IMPORT_FIELDS = ("name", "price", "stock", "category")


# ------------------------------------------------------------------- import
def validate(record):
    """Return an error message for a bad record, or None if it is valid."""
    sku = record.get("sku")
    if not isinstance(sku, str) or not sku.strip():
        return "missing sku"
    if not isinstance(record.get("name"), str) or not record["name"].strip():
        return "missing name"
    price = record.get("price")
    if isinstance(price, bool) or not isinstance(price, (int, float)) or price <= 0:
        return "price must be a positive number"
    stock = record.get("stock", 0)
    if isinstance(stock, bool) or not isinstance(stock, int) or stock < 0:
        return "stock must be a non-negative integer"
    return None


def build_operation(record):
    sku = record["sku"].strip()
    fields = {k: record[k] for k in IMPORT_FIELDS if k in record}
    fields.setdefault("stock", 0)
    return UpdateOne(
        {"sku": sku},
        {"$set": fields,                                   # same input -> same document
         "$setOnInsert": {"sku": sku, "is_active": True,   # written only when created
                          "created_at": datetime.now(timezone.utc)}},
        upsert=True,
    )


def run_batch(col, operations):
    """bulk_write one batch; retry once if a concurrent import won the insert race."""
    for attempt in (1, 2):
        try:
            return col.bulk_write(operations, ordered=False)
        except BulkWriteError as e:
            errors = e.details.get("writeErrors", [])
            only_dupes = errors and all(err.get("code") == DUPLICATE_KEY for err in errors)
            if attempt == 2 or not only_dupes:
                raise
            # Another import inserted the same new sku between our match and insert.
            # Retrying is safe because the operations are idempotent; now they match.


def import_products(col, records, batch_size=500):
    """Idempotent import. Returns a summary dict."""
    summary = {"received": len(records), "invalid": [], "duplicates_in_input": 0,
               "matched": 0, "modified": 0, "upserted": 0}

    latest = {}                                   # collapse repeated skus: the last one wins
    for i, record in enumerate(records):
        error = validate(record)
        if error:
            summary["invalid"].append((i, record.get("sku"), error))
            continue
        sku = record["sku"].strip()
        if sku in latest:
            summary["duplicates_in_input"] += 1
        latest[sku] = record

    operations = [build_operation(r) for r in latest.values()]
    for start in range(0, len(operations), batch_size):
        result = run_batch(col, operations[start:start + batch_size])
        summary["matched"] += result.matched_count
        summary["modified"] += result.modified_count
        summary["upserted"] += result.upserted_count
    summary["unchanged"] = summary["matched"] - summary["modified"]
    return summary


# ------------------------------------------------------------------ display
def print_summary(label, s):
    table = Table(title=label, show_lines=False)
    table.add_column("Metric", style="cyan", width=22)
    table.add_column("Value", justify="right", width=8)
    for key in ("received", "duplicates_in_input", "matched", "modified", "unchanged", "upserted"):
        table.add_row(key, str(s[key]))
    table.add_row("invalid (skipped)", str(len(s["invalid"])))
    console.print(table)
    for idx, sku, err in s["invalid"]:
        print(f"    skipped row {idx} (sku={sku!r}): {err}")
    print()


FEED = [
    {"sku": "SKU-100", "name": "Wireless Mouse", "price": 24.99, "stock": 140, "category": "electronics"},
    {"sku": "SKU-101", "name": "Mechanical Keyboard", "price": 89.00, "stock": 35, "category": "electronics"},
    {"sku": "SKU-102", "name": "USB-C Cable", "price": 9.99, "stock": 500, "category": "accessories"},
    {"sku": "SKU-103", "name": "Bluetooth Speaker", "price": 45.50, "stock": 12, "category": "electronics"},
    {"sku": "SKU-104", "name": "Desk Lamp", "price": 34.50, "stock": 58, "category": "home"},
    {"sku": "SKU-105", "name": "Yoga Mat", "price": 29.99, "stock": 80, "category": "sports"},
    {"sku": "SKU-106", "name": "Water Bottle", "price": 19.99, "stock": 210, "category": "kitchen"},
    {"sku": "SKU-107", "name": "Smart Watch", "price": 199.00, "stock": 7, "category": "electronics"},
]


def main():
    banner("Lab 4.2 Activity: Idempotent Bulk Import")
    db = get_db("chapter-04")

    if "import_products" in db.list_collection_names():
        db.drop_collection("import_products")
    col = db["import_products"]
    col.create_index("sku", unique=True)

    # ---- Run 1: empty collection
    print("=== Run 1: first import into an empty collection ===")
    print_summary("Run 1", import_products(col, FEED))
    print(f"  Documents in collection: {col.count_documents({})}\n")

    created_before = {d["sku"]: d["created_at"] for d in col.find({}, {"sku": 1, "created_at": 1, "_id": 0})}

    # ---- Run 2 and 3: identical data again
    for n in (2, 3):
        print(f"=== Run {n}: the exact same data again ===")
        s = import_products(col, FEED)
        print_summary(f"Run {n}", s)
        print(f"  Documents in collection: {col.count_documents({})}  (upserted={s['upserted']}, modified={s['modified']})\n")

    created_after = {d["sku"]: d["created_at"] for d in col.find({}, {"sku": 1, "created_at": 1, "_id": 0})}
    print(f"  created_at preserved on every document: {created_before == created_after}\n")

    # ---- Run 4: messy feed
    print("=== Run 4: updated feed (1 price change, 1 new product, 1 repeated sku, 2 bad rows) ===")
    feed = [dict(r) for r in FEED]
    feed[0]["price"] = 26.99                                                    # changed
    feed.append({"sku": "SKU-108", "name": "Laptop Stand", "price": 39.00, "stock": 25,
                 "category": "accessories"})                                    # new
    feed.append({"sku": "SKU-102", "name": "USB-C Cable", "price": 10.49, "stock": 480,
                 "category": "accessories"})                                    # repeated sku: last wins
    feed.append({"sku": "", "name": "No SKU", "price": 5.0})                    # invalid
    feed.append({"sku": "SKU-109", "name": "Bad Price", "price": -3})           # invalid
    s = import_products(col, feed)
    print_summary("Run 4", s)
    print(f"  Documents in collection: {col.count_documents({})}")
    for sku in ("SKU-100", "SKU-102"):
        d = col.find_one({"sku": sku}, {"_id": 0, "sku": 1, "price": 1, "stock": 1})
        print(f"  {d}")
    print()

    # ---- Contrast: a naive insert_many import
    print("=== Contrast: a naive insert_many import (no upsert, no unique index) ===")
    naive = db["import_products_naive"]
    naive.drop()
    naive.insert_many([dict(r) for r in FEED])
    naive.insert_many([dict(r) for r in FEED])
    print(f"  After running it twice: {naive.count_documents({})} documents "
          f"for {len(FEED)} products (duplicates!)")
    naive.drop()

    # ---- Concurrent imports
    print("\n=== Concurrent imports: 4 workers import the same 300 new products at once ===")
    big = [{"sku": f"BULK-{i:04d}", "name": f"Bulk Product {i}", "price": 10 + i % 50,
            "stock": i % 100, "category": "bulk"} for i in range(300)]
    with ThreadPoolExecutor(max_workers=4) as pool:
        summaries = list(pool.map(lambda _: import_products(col, big, batch_size=100), range(4)))
    created = sum(s["upserted"] for s in summaries)
    print(f"  Documents created across all workers: {created} (each SKU created exactly once)")
    print(f"  BULK-* documents in collection: {col.count_documents({'sku': {'$regex': '^BULK-'}})}")
    dupes = list(col.aggregate([{"$group": {"_id": "$sku", "n": {"$sum": 1}}}, {"$match": {"n": {"$gt": 1}}}]))
    print(f"  Duplicate skus found: {len(dupes)}")

    banner("Lab 4.2 Activity Complete")


if __name__ == "__main__":
    main()
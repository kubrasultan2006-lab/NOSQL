"""
Lab 13.2 - Kubernetes StatefulSet for MongoDB

What this script does
  1. Creates the shared keyfile Secret (same keyfile for every replica set member).
  2. kubectl apply: mongo-headless-svc.yaml + mongo-statefulset.yaml (3 pods, 3 PVCs).
  3. Waits for mongo-0, mongo-1, mongo-2 to be Running/Ready.
  4. Runs rs.initiate() from the first pod, creates an admin user (localhost exception).
  5. Prints the replica set members and stable DNS names.
  6. Inserts test data, then deletes pod mongo-2 and watches Kubernetes recreate it.
  7. Verifies the pod rejoins as SECONDARY with the same PersistentVolumeClaim and data.
  8. Prints a PASS/FAIL table and a Docker Compose vs Kubernetes comparison.

Requirements:
  - kubectl + a Kubernetes cluster. Easiest: Docker Desktop -> Settings -> Kubernetes
    -> "Enable Kubernetes" (it installs kubectl and a one-node cluster).
  - The two manifests (mongo-headless-svc.yaml, mongo-statefulset.yaml) in the same folder.
No Python packages are needed.

Run:       python "chapter-13\\Lab 13.2 - Kubernetes StatefulSet for MongoDB.py"
Clean up:  python "chapter-13\\Lab 13.2 - Kubernetes StatefulSet for MongoDB.py" --cleanup
Note: every run starts from a fresh StatefulSet (old pods, volumes and Secret are removed).
"""

import base64
import json
import secrets
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
SERVICE_YAML = HERE / "mongo-headless-svc.yaml"
STATEFULSET_YAML = HERE / "mongo-statefulset.yaml"
PODS = ["mongo-0", "mongo-1", "mongo-2"]
PVCS = [f"data-{p}" for p in PODS]
SECRET = "mongo-keyfile"
SVC = "mongo-headless-svc"
ADMIN_USER = "rsadmin"
ADMIN_PWD = "RsLabPass123"
TEST_DB = "chapter-13"


# ------------------------------------------------------------------ helpers
def run(cmd):
    return subprocess.run(cmd, capture_output=True, text=True,
                          encoding="utf-8", errors="replace")


def kubectl(*args):
    return run(["kubectl", *args])


def kexec(pod, *cmd):
    return kubectl("exec", pod, "--", *cmd)


def jsonpath(kind, name, path):
    return kubectl("get", kind, name, "-o", f"jsonpath={path}").stdout.strip()


def mongosh(pod, js, auth=True, uri=None):
    cmd = ["mongosh"]
    if uri:
        cmd.append(uri)
    cmd += ["--quiet"]
    if auth and not uri:
        cmd += ["-u", ADMIN_USER, "-p", ADMIN_PWD, "--authenticationDatabase", "admin"]
    cmd += ["--eval", js]
    return kexec(pod, *cmd)


def rs_uri():
    hosts = ",".join(f"{p}.{SVC}:27017" for p in PODS)
    return f"mongodb://{ADMIN_USER}:{ADMIN_PWD}@{hosts}/admin?replicaSet=rs0"


STATUS_JS = ("JSON.stringify(rs.status().members.map(m => "
             "({name: m.name, state: m.stateStr, health: m.health})))")


def rs_members(pod="mongo-0"):
    r = mongosh(pod, STATUS_JS)
    try:
        return json.loads(r.stdout.strip().splitlines()[-1])
    except Exception:  # noqa: BLE001
        return []


def teardown():
    if STATEFULSET_YAML.exists():
        kubectl("delete", "-f", str(STATEFULSET_YAML), "--ignore-not-found", "--wait=true")
    if SERVICE_YAML.exists():
        kubectl("delete", "-f", str(SERVICE_YAML), "--ignore-not-found")
    kubectl("delete", "pvc", *PVCS, "--ignore-not-found", "--wait=true")
    kubectl("delete", "secret", SECRET, "--ignore-not-found")


# --------------------------------------------------------------------- main
def main():
    if "--cleanup" in sys.argv:
        teardown()
        print("StatefulSet, Service, PVCs and Secret removed.")
        return

    if run(["kubectl", "version", "--client"]).returncode != 0:
        sys.exit("kubectl was not found. Install Docker Desktop and enable Kubernetes.")
    if kubectl("get", "nodes").returncode != 0:
        sys.exit("No Kubernetes cluster is reachable. In Docker Desktop open "
                 "Settings -> Kubernetes -> Enable Kubernetes, wait until it is running, "
                 "then try again.")
    for f in (SERVICE_YAML, STATEFULSET_YAML):
        if not f.exists():
            sys.exit(f"Missing manifest: {f.name} (keep it in the same folder as this script)")

    results = []

    def check(label, ok, detail=""):
        results.append((label, bool(ok), detail))

    context = kubectl("config", "current-context").stdout.strip()
    print(f"Using Kubernetes context: {context}")

    print("1) Removing any previous run ...")
    teardown()

    print("2) Creating the shared keyfile Secret and applying the manifests ...")
    keyfile = base64.b64encode(secrets.token_bytes(756)).decode()
    r = kubectl("create", "secret", "generic", SECRET, f"--from-literal=keyfile={keyfile}")
    if r.returncode != 0:
        sys.exit("Could not create the Secret:\n" + r.stderr)
    for f in (SERVICE_YAML, STATEFULSET_YAML):
        r = kubectl("apply", "-f", str(f))
        print("  ", r.stdout.strip() or r.stderr.strip())
        if r.returncode != 0:
            sys.exit("kubectl apply failed")

    print("3) Waiting for the 3 pods (the first image pull can take a few minutes) ...")
    r = kubectl("rollout", "status", "statefulset/mongo", "--timeout=420s")
    print("  ", r.stdout.strip().splitlines()[-1] if r.stdout.strip() else r.stderr.strip())
    pods = kubectl("get", "pods", "-l", "app=mongo", "-o",
                   "jsonpath={range .items[*]}{.metadata.name}={.status.phase}/"
                   "{.status.containerStatuses[0].ready} {end}").stdout.split()
    check("3 pods Running and Ready",
          len(pods) == 3 and all(p.endswith("=Running/true") for p in pods), " ".join(pods))
    phases = [jsonpath("pvc", c, "{.status.phase}") for c in PVCS]
    check("3 PersistentVolumeClaims Bound", phases == ["Bound"] * 3, ", ".join(phases))

    print("4) rs.initiate() from the first pod ...")
    members = ", ".join(f"{{_id: {i}, host: '{p}.{SVC}:27017'}}" for i, p in enumerate(PODS))
    r = mongosh("mongo-0", f"JSON.stringify(rs.initiate({{_id: 'rs0', members: [{members}]}}))",
                auth=False)
    if '"ok":1' not in r.stdout.replace(" ", ""):
        sys.exit("rs.initiate failed:\n" + r.stdout + r.stderr)

    primary = None
    end = time.time() + 90
    while time.time() < end and not primary:
        for p in PODS:
            if mongosh(p, "db.hello().isWritablePrimary", auth=False).stdout.strip() == "true":
                primary = p
                break
        time.sleep(2)
    if not primary:
        sys.exit("No primary elected within 90 seconds. Check: kubectl logs mongo-0")
    # localhost exception: the first user can be created without authenticating
    r = mongosh(primary, f"db.getSiblingDB('admin').createUser({{user: '{ADMIN_USER}', "
                         f"pwd: '{ADMIN_PWD}', roles: ['root']}}).ok", auth=False)
    if r.returncode != 0:
        sys.exit("Could not create the admin user:\n" + r.stdout + r.stderr)

    members_ok = False
    end = time.time() + 120
    while time.time() < end and not members_ok:
        m = rs_members()
        members_ok = (sorted(x["state"] for x in m) == ["PRIMARY", "SECONDARY", "SECONDARY"]
                      and all(x["health"] == 1 for x in m))
        if not members_ok:
            time.sleep(3)

    print("\n=== rs.status() members (stable network identities) ===")
    print(f"{'Member':<36} {'State':<11} Health")
    print("-" * 56)
    for x in rs_members():
        print(f"{x['name']:<36} {x['state']:<11} {x['health']}")
    names = sorted(x["name"] for x in rs_members())
    check("Members use stable DNS names (mongo-N.mongo-headless-svc)",
          names == sorted(f"{p}.{SVC}:27017" for p in PODS))
    check("1 PRIMARY + 2 SECONDARY, all healthy", members_ok)

    print("\n5) Inserting test data ...")
    r = mongosh("mongo-0", f"db.getSiblingDB('{TEST_DB}').items.insertMany("
                           "[{n: 1}, {n: 2}, {n: 3}], {writeConcern: {w: 'majority'}}).acknowledged",
                uri=rs_uri())
    check("Majority write through the replica set URI", r.stdout.strip().endswith("true"),
          r.stderr.strip()[:80])

    print("6) Resiliency test: deleting pod mongo-2 ...")
    uid_before = jsonpath("pod", "mongo-2", "{.metadata.uid}")
    pvc_before = jsonpath("pvc", "data-mongo-2", "{.metadata.uid}")
    t0 = time.monotonic()
    kubectl("delete", "pod", "mongo-2")
    uid_after = ""
    end = time.time() + 120
    while time.time() < end:
        uid_after = jsonpath("pod", "mongo-2", "{.metadata.uid}")
        if uid_after and uid_after != uid_before:
            break
        time.sleep(1)
    check("Kubernetes recreated pod mongo-2 (new pod UID)",
          bool(uid_after) and uid_after != uid_before,
          f"{uid_before[:8]} -> {uid_after[:8]}")
    kubectl("wait", "--for=condition=Ready", "pod/mongo-2", "--timeout=180s")
    ready_after = time.monotonic() - t0

    rejoined = False
    end = time.time() + 120
    while time.time() < end and not rejoined:
        rejoined = any(x["name"].startswith("mongo-2.") and x["state"] == "SECONDARY"
                       and x["health"] == 1 for x in rs_members())
        if not rejoined:
            time.sleep(3)
    check("mongo-2 rejoined the replica set as SECONDARY", rejoined,
          f"back in {time.monotonic() - t0:.0f}s (pod Ready after {ready_after:.0f}s)")

    pvc_after = jsonpath("pvc", "data-mongo-2", "{.metadata.uid}")
    check("Same PersistentVolumeClaim reattached (data-mongo-2)",
          pvc_before != "" and pvc_before == pvc_after)

    r = mongosh("mongo-2",
                "db.getMongo().setReadPref('secondaryPreferred'); "
                f"db.getSiblingDB('{TEST_DB}').items.countDocuments({{}})",
                uri=f"mongodb://{ADMIN_USER}:{ADMIN_PWD}@localhost:27017/admin?directConnection=true")
    check("Data still present on the recreated pod", r.stdout.strip().endswith("3"),
          f"documents seen on mongo-2: {r.stdout.strip().splitlines()[-1] if r.stdout.strip() else '?'}")

    print("\n=== Final members ===")
    for x in rs_members():
        print(f"{x['name']:<36} {x['state']:<11} {x['health']}")

    print("\n=== Test results ===")
    print(f"{'Check':<62} {'Result':<7} Detail")
    print("-" * 112)
    passed = 0
    for label, ok, detail in results:
        passed += ok
        print(f"{label:<62} {'PASS' if ok else 'FAIL':<7} {detail}")
    print("-" * 112)
    print(f"{passed}/{len(results)} checks passed")

    print("""
=== Docker Compose vs Kubernetes StatefulSet ===
Self-healing    Compose: restart policy restarts a crashed container on the same host.
                Kubernetes: recreates a deleted/failed pod, reschedules it on another
                node if needed, and probes decide when it receives traffic.
Identity        Compose: names/ports we chose by hand (mongo1:27017, mongo2:27027 ...).
                Kubernetes: stable DNS per pod (mongo-N.mongo-headless-svc) from the
                headless Service, with no port juggling.
Storage         Compose: named volumes we declared one by one.
                Kubernetes: volumeClaimTemplates create one PVC per pod, and the same
                PVC is reattached when the pod is recreated.
Scaling         Compose: edit the file and add services by hand.
                Kubernetes: kubectl scale statefulset mongo --replicas=5 (replica set
                membership still needs rs.add()).
Complexity      Compose: one small file, easy on one machine.
                Kubernetes: more objects (Service, StatefulSet, Secret, PVCs) and
                concepts, but far better for production and multiple nodes.
""")
    print("Remove everything with:  --cleanup")


if __name__ == "__main__":
    main()
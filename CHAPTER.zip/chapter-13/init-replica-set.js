// Lab 13.1 - initialize the 3-member replica set and create the admin user.
// Run from PowerShell (in the folder with docker-compose-production.yml),
// on a FRESH cluster, WITHOUT -u/-p (the admin user does not exist yet):
//   Get-Content init-replica-set.js | docker exec -i rs-mongo1 mongosh --port 27017

try {
  const init = rs.initiate({
    _id: "rs0",
    members: [
      { _id: 0, host: "mongo1:27047" },
      { _id: 1, host: "mongo2:27027" },
      { _id: 2, host: "mongo3:27037" },
    ],
  });
  
  print("rs.initiate ok:", init.ok);
} catch (e) {
  print("rs.initiate failed:", e.message);
  print("If this says 'already initialized', the data volumes still hold an old");
  print("replica set config (for example with different ports). Start clean with:");
  print("  docker compose -f docker-compose-production.yml down -v");
  print("  docker compose -f docker-compose-production.yml up -d");
  quit(1);
}

// wait for this node to be elected primary (hello() needs no authentication)
let tries = 0;
while (!db.hello().isWritablePrimary && tries < 60) {
  sleep(1000);
  tries++;
}
if (!db.hello().isWritablePrimary) {
  print("No primary after 60 s. Check: docker compose -f docker-compose-production.yml ps");
  quit(1);
}
print("primary elected after", tries, "s");

// localhost exception: the first user can be created without authenticating
const res = db.getSiblingDB("admin").createUser({
  user: "rsadmin",
  pwd: "RsLabPass123",
  roles: ["root"],
});
print("admin user created:", res.ok);
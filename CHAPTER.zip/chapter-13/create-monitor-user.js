// Activity 13.1 - create the least-privilege user used by the Prometheus exporter.
// Must run against the PRIMARY with admin rights, so connect with the replica set URI:
//
//   Get-Content create-monitor-user.js | docker exec -i rs-mongo1 mongosh "mongodb://rsadmin:RsLabPass123@mongo1:27017,mongo2:27027,mongo3:27037/admin?replicaSet=rs0"

const admin = db.getSiblingDB("admin");
try {
  admin.createUser({
    user: "exporter",
    pwd: "ExporterPass123",
    roles: [
      { role: "clusterMonitor", db: "admin" }, // serverStatus, replSetGetStatus, ...
      { role: "read", db: "local" },           // replication (oplog) metrics
    ],
  });
  print("monitoring user 'exporter' created");
} catch (e) {
  print("could not create user:", e.message);
}

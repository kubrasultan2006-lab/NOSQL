"""
Lab 13.1 step 4 - connect PyMongo to the replica set and verify failover.

The script reads (and writes with w="majority") continuously for 40 seconds.
After 5 seconds it runs replSetStepDown on the primary, like rs.stepDown() in
mongosh, then reports every primary change and how many operations failed.

Run:  python failover_test.py            (steps the primary down automatically)
      python failover_test.py --no-stepdown   (only watch; step down yourself)
Requires: pip install pymongo
"""

import socket
import sys
import time

from pymongo import MongoClient, WriteConcern

# Seed node only: PyMongo discovers the other members (and follows failovers)
# from the replica set itself. Credentials are passed separately because the
# cluster uses keyFile authentication.
URI = "mongodb://localhost:27047/"
CREDENTIALS = dict(username="rsadmin", password="RsLabPass123", authSource="admin")
DB_NAME = "chapter-13"
DURATION = 40
STEPDOWN_AT = 5


def current_primary(client):
    try:
        return client.admin.command("hello").get("primary")
    except Exception:  # noqa: BLE001
        return None


def check_hosts_file():
    """The replica set members are named mongo1/mongo2/mongo3; this PC must resolve them."""
    try:
        for name in ("mongo1", "mongo2", "mongo3"):
            socket.gethostbyname(name)
    except OSError:
        sys.exit("Your PC cannot resolve mongo1/mongo2/mongo3 (the replica set member names).\n"
                 "Run PowerShell as Administrator once and execute:\n"
                 '  Add-Content C:\\Windows\\System32\\drivers\\etc\\hosts "127.0.0.1 mongo1 mongo2 mongo3"')


def main():
    check_hosts_file()
    do_stepdown = "--no-stepdown" not in sys.argv
    client = MongoClient(URI, serverSelectionTimeoutMS=15000, **CREDENTIALS)
    coll = client[DB_NAME].get_collection("failover", write_concern=WriteConcern("majority"))
    coll.delete_many({})

    start = time.monotonic()
    primary = current_primary(client)
    print(f"[{0:5.1f}s] primary = {primary}")

    reads = writes = errors = 0
    last_ok = start
    max_gap = 0.0
    stepped = False
    changes = []

    while time.monotonic() - start < DURATION:
        now = time.monotonic() - start

        if do_stepdown and not stepped and now >= STEPDOWN_AT:
            stepped = True
            print(f"[{now:5.1f}s] running replSetStepDown on {primary} ...")
            try:
                client.admin.command("replSetStepDown", 20, secondaryCatchUpPeriodSecs=10)
            except Exception:  # noqa: BLE001
                pass  # the connection may close while the primary steps down

        try:
            coll.find_one({})
            reads += 1
            coll.insert_one({"t": time.time()})
            writes += 1
            t = time.monotonic()
            max_gap = max(max_gap, t - last_ok)
            last_ok = t
        except Exception as e:  # noqa: BLE001
            errors += 1
            print(f"[{now:5.1f}s] operation failed: {type(e).__name__}")
            time.sleep(0.3)

        p = current_primary(client)
        if p and p != primary:
            print(f"[{time.monotonic() - start:5.1f}s] PRIMARY CHANGED: {primary} -> {p}")
            changes.append((primary, p))
            primary = p
        time.sleep(0.1)

    total = coll.count_documents({})
    print("\n=== Summary ===")
    print(f"Reads ok: {reads}   Writes ok: {writes}   Errors: {errors}")
    print(f"Longest pause between successful operations: {max_gap:.1f}s")
    print(f"Documents stored (all majority-acknowledged): {total}")
    print(f"Primary changes seen: {len(changes)}")
    print("RESULT:", "PASS - failover worked, no data lost"
          if (changes or not do_stepdown) and total == writes
          else "FAIL - check the output above")


if __name__ == "__main__":
    main()
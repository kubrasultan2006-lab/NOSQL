"""
chatbot.py - RAG chatbot core for the CTI Digest project (Final Assessment, 23CSE528).

Drop this next to server.py. It needs only the Python standard library;
pymongo is used for memory/knowledge if installed and MONGO_URI is reachable,
otherwise it silently falls back to in-memory history.

Public API (what server.py calls):
    handle_chat(payload: dict) -> dict      # POST /api/chat
    health() -> dict                        # GET  /api/chat/health

LLM backend (first that works wins):
    LLM_BACKEND=ollama (default)  -> OLLAMA_BASE_URL, OLLAMA_MODEL
    LLM_BACKEND=openai            -> OPENAI_API_KEY, OPENAI_MODEL
    no LLM reachable              -> built-in answer from the records + live system snapshot

System detection is READ-ONLY: a fixed whitelist of probes (platform, CPU/thread
counts, memory, disk, whether local service ports are open). The chatbot never
executes shell commands or anything the user or the model writes.
"""
import json
import os
import platform
import re
import shutil
import socket
import sys
import threading
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone

try:
    from pymongo import MongoClient
except Exception:  # pymongo not installed
    MongoClient = None

try:
    import psutil  # optional, gives exact thread counts
except Exception:
    psutil = None

# --------------------------------------------------------------------------
# Config (all from environment variables - never hard-code keys, Exercise-12)
# --------------------------------------------------------------------------
MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
MONGO_DB = os.getenv("MONGO_DB", "chatbot")
LLM_BACKEND = os.getenv("LLM_BACKEND", "ollama").lower()
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.1:8b")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
VOYAGE_MODEL = os.getenv("VOYAGE_MODEL", "voyage-3")
RATE_LIMIT_PER_MIN = int(os.getenv("CHAT_RATE_LIMIT", "30"))

SYSTEM_PROMPT = (
    "You are the assistant inside the CTI Digest MongoDB project (course 23CSE528, chapters 7-18 plus this "
    "chat assistant). Answer questions about ANY part of the project using the PROJECT NOTES you are given, "
    "and the READ-ONLY SYSTEM SNAPSHOT when it is present. If the notes do not cover the question, say so "
    "instead of guessing. Name the chapter or lab you are drawing on. Be concise (under 150 words). "
    "When a READ-ONLY THREAT SCAN RESULT is present, report its verdict and each finding in plain words and say "
    "what the person should do; you only read the scan, you cannot delete, quarantine or fix anything. "
    "Never claim you ran commands; you can only read the snapshot you were given."
)

# --------------------------------------------------------------------------
# MongoDB (conversation memory + knowledge store), with in-memory fallback
# --------------------------------------------------------------------------
_mem_history = {}          # session_id -> list of messages (fallback)
_mongo = {"db": None, "tried": False, "error": None}
_lock = threading.Lock()


def _db():
    """Return the Mongo database or None. Tries once, then remembers."""
    # a failed attempt is retried after 30 s, so starting Docker later still works
    if _mongo["tried"] and (_mongo["db"] is not None or time.time() - _mongo.get("at", 0) < 30):
        return _mongo["db"]
    with _lock:
        if _mongo["tried"] and (_mongo["db"] is not None or time.time() - _mongo.get("at", 0) < 30):
            return _mongo["db"]
        _mongo["tried"], _mongo["at"], _mongo["error"] = True, time.time(), None
        if MongoClient is None:
            _mongo["error"] = "pymongo not installed"
            return None
        try:
            client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=2000)
            client.admin.command("ping")
            _mongo["db"] = client[MONGO_DB]
        except Exception as exc:
            _mongo["error"] = str(exc)[:200]
    return _mongo["db"]


def _now():
    return datetime.now(timezone.utc)


def save_message(session_id, role, content):
    msg = {"session_id": session_id, "role": role, "content": content, "timestamp": _now()}
    db = _db()
    if db is not None:
        try:
            db["sessions"].insert_one(dict(msg))
            return
        except Exception:
            pass
    _mem_history.setdefault(session_id, []).append(msg)


def get_history(session_id, n=5):
    db = _db()
    if db is not None:
        try:
            rows = list(db["sessions"].find({"session_id": session_id}).sort("timestamp", -1).limit(n * 2))[::-1]
            return [{"role": r["role"], "content": r["content"]} for r in rows]
        except Exception:
            pass
    return [{"role": m["role"], "content": m["content"]} for m in _mem_history.get(session_id, [])[-n * 2:]]


# --------------------------------------------------------------------------
# Retrieval (vector search if Voyage key + index exist, else skipped)
# --------------------------------------------------------------------------
def _post_json(url, body, headers=None, timeout=120):
    req = urllib.request.Request(
        url, data=json.dumps(body).encode(), method="POST",
        headers={"Content-Type": "application/json", **(headers or {})})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode())


def retrieve_context(query, n_results=3):
    key = os.getenv("VOYAGE_API_KEY")
    db = _db()
    if not key or db is None:
        return []
    try:
        emb = _post_json("https://api.voyageai.com/v1/embeddings",
                         {"input": [query], "model": VOYAGE_MODEL},
                         {"Authorization": f"Bearer {key}"}, timeout=20)["data"][0]["embedding"]
        pipeline = [{"$vectorSearch": {"index": "vector_index", "path": "embedding",
                                       "queryVector": emb, "numCandidates": 20, "limit": n_results}}]
        return [r["text"] for r in db["knowledge"].aggregate(pipeline)]
    except Exception:
        return []


# --------------------------------------------------------------------------
# Whole-project knowledge (project_knowledge.json, made by ingest_project.py)
# Keyword retrieval (TF-IDF), no API key or embeddings needed.
# --------------------------------------------------------------------------
KNOWLEDGE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "project_knowledge.json")
_kb = {"mtime": None, "chunks": [], "df": {}}
_STOP = set("the and for with that this what how does are was you your can from into about which when where "
            "who why tell me please explain show give use used using has have had not but all any its it's "
            "is of in on to a an as at be by do or if so we i my our their them then than".split())
OVERVIEW_WORDS = re.compile(r"\b(whole|entire|overall|overview|summar\w*|everything|all chapters|each chapter|"
                            r"about (the|this) project|what is this|what does this project|course|tour)\b", re.I)


def _tokens(text):
    words = [w.rstrip(".-") for w in re.findall(r"[a-z0-9][a-z0-9.\-]*", text.lower())]
    return [w for w in words if w and w not in _STOP and (len(w) > 1 or w.isdigit())]


def _load_kb():
    try:
        mtime = os.path.getmtime(KNOWLEDGE_FILE)
    except OSError:
        _kb.update(mtime=None, chunks=[], df={})
        return _kb["chunks"]
    if mtime != _kb["mtime"]:
        with open(KNOWLEDGE_FILE, encoding="utf-8") as fh:
            chunks = json.load(fh)
        df = {}
        for c in chunks:
            c["_tf"] = {}
            for w in _tokens(c["title"]) * 2 + _tokens(c["text"]):   # title words count double
                c["_tf"][w] = c["_tf"].get(w, 0) + 1
            for w in c["_tf"]:
                df[w] = df.get(w, 0) + 1
        _kb.update(mtime=mtime, chunks=chunks, df=df)
    return _kb["chunks"]


def retrieve_project(query, k=4, max_chars=3200):
    """Return the most relevant project chunks as [{'title','text'}]. [] if no knowledge file exists."""
    chunks = _load_kb()
    if not chunks:
        return []
    q = _tokens(query)
    # "chapter 11" / "lab 11.2" -> also match the tokens "11" / "11.2"
    for m in re.finditer(r"(?:chapter|ch\.?|lab|activity)\s*(\d{1,2}(?:\.\d)?)", query, re.I):
        q += [m.group(1)] * 3
    n = len(chunks)
    refs = [m.group(1) for m in re.finditer(r"(?:chapter|ch\.?|lab|activity)\s*(\d{1,2})", query, re.I)]
    scored = []
    for c in chunks:
        s = 0.0
        for num in refs:      # an explicit "chapter 8" / "lab 8.2" question: that chapter's chunks come first
            if re.match(rf"(Chapter {num}:|(Lab|Activity) {num}\.\d)", c["title"]):
                s += 8
        for w in set(q):
            tf = c["_tf"].get(w, 0)
            if not tf and w.endswith("s"):
                tf = c["_tf"].get(w[:-1], 0)
            if tf:
                s += (1 + tf ** 0.5) * (1 + (n / (1 + _kb["df"].get(w, 0))) ** 0.5)
        if s:
            scored.append((s, c))
    scored.sort(key=lambda x: -x[0])
    picked = [c for _, c in scored[:k]]
    if OVERVIEW_WORDS.search(query) or not picked:
        ov = [c for c in chunks if c["source"] == "overview"][:2]
        tour = [c for c in chunks if c["title"] in ("Course tour",)]
        picked = [c for c in ov + tour if c not in picked] + picked
    out, used = [], 0
    for c in picked:
        if used + len(c["text"]) > max_chars and out:
            break
        out.append({"title": c["title"], "text": c["text"]})
        used += len(c["text"])
    return out


# --------------------------------------------------------------------------
# READ-ONLY system detection (fixed whitelist, stdlib only)
# --------------------------------------------------------------------------
def _memory():
    try:
        if sys.platform.startswith("win"):
            import ctypes

            class MEMSTATUS(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("sullAvailExtendedVirtual", ctypes.c_ulonglong)]
            s = MEMSTATUS()
            s.dwLength = ctypes.sizeof(MEMSTATUS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(s))
            return round(s.ullTotalPhys / 2**30, 1), round(s.ullAvailPhys / 2**30, 1)
        if os.path.exists("/proc/meminfo"):
            info = {}
            with open("/proc/meminfo") as fh:
                for line in fh:
                    k, v = line.split(":", 1)
                    info[k] = int(v.split()[0])
            return round(info["MemTotal"] / 2**20, 1), round(info.get("MemAvailable", 0) / 2**20, 1)
    except Exception:
        pass
    if psutil:
        vm = psutil.virtual_memory()
        return round(vm.total / 2**30, 1), round(vm.available / 2**30, 1)
    return None, None


def _port_open(port, host="127.0.0.1"):
    try:
        with socket.create_connection((host, port), timeout=0.3):
            return True
    except OSError:
        return False


def detect_system():
    """Read-only snapshot of this computer. Nothing here changes any state."""
    total, avail = _memory()
    snap = {
        "os": platform.platform(),
        "machine": platform.machine(),
        "python": platform.python_version(),
        "logical_cpus": os.cpu_count(),
        "physical_cores": psutil.cpu_count(logical=False) if psutil else None,
        "server_threads_now": threading.active_count(),
        "server_thread_names": [t.name for t in threading.enumerate()][:12],
        "ram_total_gb": total,
        "ram_free_gb": avail,
        "disk_free_gb": round(shutil.disk_usage(os.path.abspath(os.sep)).free / 2**30, 1),
        "services": {
            "mongodb_27017": _port_open(27017),
            "mongodb_27047": _port_open(27047),
            "mongodb_27117": _port_open(27117),
            "mongodb_28017": _port_open(28017),
            "ollama_11434": _port_open(11434),
        },
        "read_only": True,
    }
    if psutil:
        try:
            snap["all_os_threads"] = sum(p.info["num_threads"] or 0
                                         for p in psutil.process_iter(["num_threads"]))
            snap["processes"] = len(psutil.pids())
        except Exception:
            pass
    return snap


def snapshot_text(s):
    lines = [
        f"OS: {s['os']} ({s['machine']}), Python {s['python']}",
        f"Logical CPUs (hardware threads): {s['logical_cpus']}"
        + (f", physical cores: {s['physical_cores']}" if s.get("physical_cores") else ""),
        f"Threads in this chat server: {s['server_threads_now']}",
    ]
    if "all_os_threads" in s:
        lines.append(f"Threads across all processes: {s['all_os_threads']} in {s['processes']} processes")
    if s["ram_total_gb"]:
        lines.append(f"RAM: {s['ram_free_gb']} GB free of {s['ram_total_gb']} GB")
    lines.append(f"Disk free: {s['disk_free_gb']} GB")
    svc = ", ".join(f"{k.split('_')[0]}:{k.split('_')[1]} {'up' if v else 'down'}"
                    for k, v in s["services"].items())
    lines.append(f"Local services: {svc}")
    return "\n".join(lines)


# --------------------------------------------------------------------------
# Intent routing
# --------------------------------------------------------------------------
SYSTEM_WORDS = re.compile(r"\b(threads?|cpus?|cores?|ram|my pc|my computer|my laptop|my machine|hardware|detect\w*|"
                          r"my system|system (info|check|specs?|resources)|free memory|how much memory)\b", re.I)
# "threats" (also typed as "threads"): first run the threat-check script, then show the final project
DEMO_WORDS = re.compile(r"(script|run).*(threats?|threads?)|(threats?|threads?).*(script|project|run)|"
                        r"final project|show (him|them|the) (final )?project", re.I)
THREAT_ASK = re.compile(
    r"(check|scan|detect|find|look for|any|present|show)\W.{0,40}\b(threats?|malware|viruses?|infect\w*)\b|"
    r"\b(threats?|malware|viruses?)\b.{0,30}\b(on|in|present on)\b.{0,12}\b(my|this|your|the)\b.{0,6}\b(pc|computer|machine|laptop|system)\b|"
    r"is (my|this) (pc|computer|laptop|machine) (safe|infected|secure|clean)|check_threats", re.I)

DEMO_STEPS = (
    "Before showing the final project, run the threat-check script, then start the app:\n"
    "1. In the project folder run:  python check_threats.py   "
    "(read-only: it looks for threats on your PC - suspicious files, start-up entries, open ports, attacker tools - "
    "and changes or deletes nothing).\n"
    "2. Start the server:  python server.py  (and the replica set with python lab8_1deployreplicaset.py if it is not up).\n"
    "3. Open index.html with Live Server and walk through the chapters, ending with the chatbot.\n"
)


def run_threat_scan():
    """Read-only threat scan for the chat (quick mode). Returns (result_dict, text) or (None, error_text)."""
    try:
        import check_threats
        res = check_threats.scan(quick=True)
        return res, check_threats.summary_text(res)
    except Exception as exc:
        return None, f"threat scan could not run: {type(exc).__name__}: {str(exc)[:100]}"


def _fallback_answer(message, snap_txt, project, context, threat_txt=""):
    """Used when no LLM answers: quote the scan, system snapshot and project notes directly."""
    if threat_txt:
        head = (DEMO_STEPS + "\n") if DEMO_WORDS.search(message) else ""
        tail = ("\n\nYour PC (read-only):\n" + snap_txt) if snap_txt else ""
        return head + "Threat check of this PC (read-only, quick scan):\n" + threat_txt + tail
    if snap_txt and DEMO_WORDS.search(message):
        return DEMO_STEPS + "\nYour PC right now (read-only):\n" + snap_txt
    if snap_txt:
        return "Here is what I can see on this machine (read-only, nothing was changed):\n" + snap_txt
    if project:
        body = "\n\n".join(f"{c['title']}\n{c['text'][:450]}" for c in project[:3])
        return ("(No language model is running, so this is quoted from the project notes. "
                "Start Ollama for full answers.)\n\n" + body)
    if context:
        return "From the knowledge base:\n- " + "\n- ".join(c[:300] for c in context)
    return ("No language model is reachable (start Ollama or set OPENAI_API_KEY) and I found nothing about that "
            "in the project notes. Try asking about a chapter, e.g. 'what does chapter 11 show?', "
            "or ask me to check your PC for threats.")


# --------------------------------------------------------------------------
# LLM call
# --------------------------------------------------------------------------
def call_llm(messages):
    """Returns (text, backend_name) or (None, reason)."""
    if LLM_BACKEND == "openai" or (LLM_BACKEND != "ollama" and os.getenv("OPENAI_API_KEY")):
        key = os.getenv("OPENAI_API_KEY")
        if not key:
            return None, "OPENAI_API_KEY not set"
        try:
            r = _post_json("https://api.openai.com/v1/chat/completions",
                           {"model": OPENAI_MODEL, "messages": messages, "temperature": 0.4, "max_tokens": 500},
                           {"Authorization": f"Bearer {key}"}, timeout=60)
            return r["choices"][0]["message"]["content"], f"openai:{OPENAI_MODEL}"
        except Exception as exc:
            return None, f"openai error: {str(exc)[:120]}"
    try:
        r = _post_json(f"{OLLAMA_BASE_URL}/api/chat",
                       {"model": OLLAMA_MODEL, "messages": messages, "stream": False}, timeout=120)
        return r["message"]["content"], f"ollama:{OLLAMA_MODEL}"
    except Exception as exc:
        return None, f"ollama unreachable: {str(exc)[:120]}"


# --------------------------------------------------------------------------
# Rate limit (per session, in memory)
# --------------------------------------------------------------------------
_hits = {}


def _rate_ok(session_id):
    now = time.time()
    hits = [t for t in _hits.get(session_id, []) if now - t < 60]
    if len(hits) >= RATE_LIMIT_PER_MIN:
        _hits[session_id] = hits
        return False
    hits.append(now)
    _hits[session_id] = hits
    return True


# --------------------------------------------------------------------------
# Public entry points
# --------------------------------------------------------------------------
def handle_chat(payload):
    message = str((payload or {}).get("message", "")).strip()[:2000]
    session_id = str((payload or {}).get("session_id", "default"))[:64]
    if not message:
        return {"error": "message is required"}
    if not _rate_ok(session_id):
        return {"error": "rate limit: slow down"}

    save_message(session_id, "user", message)
    wants_threats = bool(THREAT_ASK.search(message) or DEMO_WORDS.search(message))
    wants_system = bool(SYSTEM_WORDS.search(message) or wants_threats)
    snap = detect_system() if wants_system else None
    snap_txt = snapshot_text(snap) if snap else ""
    scan, threat_txt = run_threat_scan() if wants_threats else (None, "")
    project = retrieve_project(message)          # whole-project notes (project_knowledge.json)
    context = retrieve_context(message)          # optional Atlas/Voyage vector search
    history = get_history(session_id)[:-1]  # exclude the message we just stored

    user_block = message
    notes = [f"[{c['title']}] {c['text']}" for c in project] + context
    if notes:
        user_block = "PROJECT NOTES:\n" + "\n---\n".join(notes) + "\n\nQuestion: " + message
    if threat_txt:
        user_block += "\n\nREAD-ONLY THREAT SCAN RESULT (just ran on this PC):\n" + threat_txt
    if snap_txt:
        user_block += "\n\nREAD-ONLY SYSTEM SNAPSHOT:\n" + snap_txt
    if wants_threats and DEMO_WORDS.search(message):
        user_block += "\n\nSteps to give:\n" + DEMO_STEPS
    messages = [{"role": "system", "content": SYSTEM_PROMPT}, *history,
                {"role": "user", "content": user_block}]

    answer, backend = call_llm(messages)
    if answer is None:
        answer, note = _fallback_answer(message, snap_txt, project, context, threat_txt), backend
        backend = "built-in"
    else:
        note = None

    save_message(session_id, "assistant", answer)
    out = {"answer": answer, "backend": backend, "memory": "mongodb" if _db() is not None else "in-memory"}
    if note:
        out["llm_note"] = note
    if snap:
        out["system"] = snap
    if scan:
        out["threats"] = {"verdict": scan["verdict"], "counts": scan["counts"], "checked": scan["checked"]}
    return out


def health():
    return {"status": "ok", "mongo": _db() is not None, "mongo_error": _mongo["error"],
            "llm_backend": LLM_BACKEND, "threads": threading.active_count(),
            "project_chunks": len(_load_kb()), "knowledge_file": os.path.basename(KNOWLEDGE_FILE)}


if __name__ == "__main__":
    # Quick terminal test:  python chatbot.py "how many threads does my pc have?"
    q = " ".join(sys.argv[1:]) or "how many threads does my pc have?"
    print(json.dumps(handle_chat({"message": q, "session_id": "cli"}), indent=2, default=str))

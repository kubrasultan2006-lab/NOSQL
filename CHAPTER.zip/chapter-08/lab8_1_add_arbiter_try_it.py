r"""
Lab 8.1 - Try it yourself: add an arbiter node to the replica set.

Run AFTER lab8_1deployreplicaset.py has the 3-node set (rs0) running:

    python chapter-08\lab8_1_add_arbiter.py --base-port 28017
    python chapter-08\lab8_1_add_arbiter.py --base-port 28017 --remove   # undo
"""
import argparse
import subprocess
import sys
import time

from pymongo import MongoClient

try:
    from rich.console import Console
    from rich.table import Table
    console = Console()
except ImportError:          # plain-text fallback
    console = None

REPLSET = "rs0"
ARB_NAME = "chapter-08-arbiter"
HOST_ALIAS = "host.docker.internal"


# ----------------------------------------------------------------- helpers
def run(cmd, check=True):
    return subprocess.run(cmd, capture_output=True, text=True, check=check)


def show(title, headers, rows):
    if console:
        t = Table(title=title, show_lines=True)
        for h in headers:
            t.add_column(h)
        for r in rows:
            t.add_row(*[str(c) for c in r])
        console.print(t)
    else:
        print(f"\n{title}")
        print(" | ".join(headers))
        for r in rows:
            print(" | ".join(str(c) for c in r))


def direct(port):
    return MongoClient("localhost", port, directConnection=True,
                       serverSelectionTimeoutMS=3000)


def find_primary(ports):
    for p in ports:
        try:
            c = direct(p)
            if c.admin.command("hello").get("isWritablePrimary"):
                return c, p
        except Exception:
            pass
    raise RuntimeError("No primary found - is the 3-node set running?")


def wait_for(fn, timeout=60):
    end = time.time() + timeout
    while time.time() < end:
        try:
            if fn():
                return True
        except Exception:
            pass
        time.sleep(2)
    return False


# ------------------------------------------------------------------- main
def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--base-port", type=int, default=28017)
    ap.add_argument("--remove", action="store_true",
                    help="remove the arbiter from the set and delete its container")
    args = ap.parse_args(argv)

    data_ports = [args.base_port + i for i in range(3)]
    arb_port = args.base_port + 3
    arb_host = f"{HOST_ALIAS}:{arb_port}"

    primary, pport = find_primary(data_ports)
    cfg = primary.admin.command("replSetGetConfig")["config"]

    # ------------------------------------------------------------ remove
    if args.remove:
        cfg["members"] = [m for m in cfg["members"] if m["host"] != arb_host]
        cfg["version"] += 1
        primary.admin.command("replSetReconfig", cfg)
        run(["docker", "rm", "-f", ARB_NAME], check=False)
        print("Arbiter removed from the replica set and container deleted.")
        return 0

    # ------------------------------------------------- 1. start the arbiter
    image = run(["docker", "inspect", "chapter-08-mongo1",
                 "--format", "{{.Config.Image}}"]).stdout.strip()
    network = run(["docker", "inspect", "chapter-08-mongo1", "--format",
                   "{{range $k,$v := .NetworkSettings.Networks}}{{$k}} {{end}}"]
                  ).stdout.split()[0]

    run(["docker", "rm", "-f", ARB_NAME], check=False)
    run(["docker", "run", "-d", "--name", ARB_NAME, "--network", network,
         "-p", f"{arb_port}:{arb_port}", image,
         "mongod", "--replSet", REPLSET, "--port", str(arb_port),
         "--bind_ip_all"])

    arb_up = wait_for(lambda: direct(arb_port).admin.command("ping")["ok"] == 1)

    # ------------------------------------- 2. add it to the replica set
    # Arbiters hold no data, so they must be flagged arbiterOnly.
    # (Same effect as rs.addArb("host:port") in mongosh.)
    if not any(m["host"] == arb_host for m in cfg["members"]):
        new_id = max(m["_id"] for m in cfg["members"]) + 1
        cfg["members"].append({"_id": new_id, "host": arb_host,
                               "arbiterOnly": True, "priority": 0,
                               "votes": 1})
        cfg["version"] += 1
        primary.admin.command("setDefaultRWConcern", defaultWriteConcern={"w": 1})
        primary.admin.command("replSetReconfig", cfg)

    # ----------------------------------------------------- 3. verify
    def arbiter_state():
        st = primary.admin.command("replSetGetStatus")
        return any(m["name"] == arb_host and m["stateStr"] == "ARBITER"
                   for m in st["members"])

    in_state = wait_for(arbiter_state)

    cfg = primary.admin.command("replSetGetConfig")["config"]
    voting = [m for m in cfg["members"] if m.get("votes", 1) > 0]
    arbiters = [m for m in cfg["members"] if m.get("arbiterOnly")]
    data_bearing = len(cfg["members"]) - len(arbiters)
    majority = len(voting) // 2 + 1

    checks = [
        ("Arbiter container running and responding", arb_up),
        ("Arbiter present in replica set config", len(arbiters) == 1),
        ("Arbiter reports state ARBITER", in_state),
        ("Arbiter stores no user data (arbiterOnly)", len(arbiters) == 1),
    ]
    show("Lab 8.1 - Arbiter check", ["Check", "Result"],
         [(n, "PASS" if ok else "FAIL") for n, ok in checks])

    show("Voting summary", ["Item", "Value"], [
        ("Data-bearing members", data_bearing),
        ("Arbiters", len(arbiters)),
        ("Total voting members", len(voting)),
        ("Votes needed to elect a primary (majority)", majority),
    ])

    show("Next", ["Next", "Command / value"], [
        ("See arbiter state", "docker exec -it chapter-08-mongo1 mongosh --eval "
                              "\"rs.status().members.map(m=>[m.name,m.stateStr])\""),
        ("Remove the arbiter", f"python chapter-08\\lab8_1_add_arbiter.py "
                               f"--base-port {args.base_port} --remove"),
    ])

    if len(voting) % 2 == 0:
        print("\nNote: you now have an EVEN number of voters "
              f"({len(voting)}). With 3 data nodes already, the arbiter adds no "
              "extra fault tolerance. An arbiter is most useful in a "
              "2 data node + 1 arbiter set (see explanation).")

    return 0 if all(ok for _, ok in checks) else 1


if __name__ == "__main__":
    sys.exit(main())
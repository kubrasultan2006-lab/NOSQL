r"""
Lab 8.2: Observe Failover and Election
Prerequisite: Lab 8.1 (3-node replica set rs0 running on ports 28017-28019).

Usage (run from the repo root):

  # Steps 1 + 2: connect to the primary, rs.stepDown(), watch the election,
  #              then print rs.status() and the new primary
  python chapter-08\lab8_2_observe_failover.py stepdown --base-port 27017

  # Step 3a: continuous reader (leave running in terminal 1, Ctrl+C to stop)
  python chapter-08\lab8_2_observe_failover.py watch --base-port 27017

  # Step 3b: force another stepDown from terminal 2 while the reader runs
  python chapter-08\lab8_2_observe_failover.py stepdown --base-port 

  # Everything in one go (reader thread + two stepDowns)
  python chapter-08\lab8_2_observe_failover.py demo --base-port 27017"""
import argparse
import sys
import threading
import time
from datetime import datetime

from pymongo import MongoClient
from pymongo.errors import AutoReconnect, OperationFailure, PyMongoError

try:
    from rich.console import Console
    from rich.table import Table
    console = Console()
except ImportError:
    console = None

REPLSET = "rs0"
HOST = "host.docker.internal"   # the names the members advertise
TITLE = "Lab 8.2: Observe Failover and Election"


# ---------------------------------------------------------------- helpers
def log(msg):
    print(f"[{datetime.now().strftime('%H:%M:%S.%f')[:-3]}] {msg}", flush=True)


def show(title, headers, rows):
    if console:
        t = Table(title=title, show_lines=True)
        for h in headers:
            t.add_column(h)
        for r in rows:
            t.add_row(*[str(c) for c in r])
        console.print(t)
    else:
        print(f"\n{title}")
        print(" | ".join(headers))
        for r in rows:
            print(" | ".join(str(c) for c in r))


def data_ports(base):
    return [base, base + 1, base + 2]


def rs_uri(base):
    hosts = ",".join(f"{HOST}:{p}" for p in data_ports(base))
    return f"mongodb://{hosts}/?replicaSet={REPLSET}"


def direct(port):
    return MongoClient("localhost", port, directConnection=True,
                       serverSelectionTimeoutMS=1000)


def member_states(clients):
    """{port: PRIMARY | SECONDARY | OTHER | DOWN} for each data node."""
    out = {}
    for port, c in clients.items():
        try:
            h = c.admin.command("hello")
            out[port] = ("PRIMARY" if h.get("isWritablePrimary")
                         else "SECONDARY" if h.get("secondary") else "OTHER")
        except PyMongoError:
            out[port] = "DOWN"
    return out


def print_rs_status(client):
    st = client.admin.command("replSetGetStatus")
    rows = [(m["name"], m["stateStr"], m["health"],
             m.get("optimeDate", "-")) for m in st["members"]]
    show("rs.status()", ["Member", "State", "Health", "Last optime"], rows)
    return st


# ------------------------------------------- Steps 1 + 2: stepDown + status
def do_stepdown(base, step_down_secs=20):
    ports = data_ports(base)
    clients = {p: direct(p) for p in ports}
    before = member_states(clients)
    old = next((p for p, s in before.items() if s == "PRIMARY"), None)
    if old is None:
        log("No primary found - is the replica set running (Lab 8.1)?")
        return None

    term_before = clients[old].admin.command("replSetGetStatus")["term"]
    log(f"Connected to primary {HOST}:{old} (term {term_before}). "
        f"Running rs.stepDown({step_down_secs}) ...")
    t0 = time.time()
    try:
        clients[old].admin.command("replSetStepDown", step_down_secs,
                                   secondaryCatchUpPeriodSecs=10)
    except AutoReconnect:
        pass                       # older servers close the connection
    except OperationFailure as e:
        log(f"stepDown refused: {e}")
        return None
    log("stepDown accepted - the old primary is now a SECONDARY; "
        "the election starts.")

    prev, new, no_primary_seen = before, None, False
    while time.time() - t0 < 30:
        cur = member_states(clients)
        for p in ports:
            if cur[p] != prev[p]:
                log(f"  {HOST}:{p}: {prev[p]} -> {cur[p]}")
        prev = cur
        primaries = [p for p, s in cur.items() if s == "PRIMARY"]
        if not primaries:
            if not no_primary_seen:
                log("  ** no primary right now (election in progress) **")
            no_primary_seen = True
        elif primaries[0] != old:
            new = primaries[0]
            break
        time.sleep(0.2)

    if new is None:
        log("No new primary within 30s - check the cluster.")
        return None

    elapsed = time.time() - t0
    log(f"NEW PRIMARY elected: {HOST}:{new} "
        f"(about {elapsed:.2f}s after rs.stepDown())")
    st = print_rs_status(clients[new])
    show("Election result", ["Item", "Value"], [
        ("Old primary", f"{HOST}:{old}"),
        ("New primary", f"{HOST}:{new}"),
        ("Term before -> after", f"{term_before} -> {st['term']}"),
        ("Time to elect", f"{elapsed:.2f}s"),
        ("Old primary eligible again after", f"{step_down_secs}s"),
    ])
    return new


# ----------------------------------------------- Step 3: continuous reader
def watch(base, stop, interval=0.5):
    """Read in a loop and log which member answered each read."""
    client = MongoClient(rs_uri(base), readPreference="primary",
                         retryReads=False,          # make failures visible
                         serverSelectionTimeoutMS=3000)
    coll = client["chapter-08"].heartbeat
    try:
        coll.update_one({"_id": 1}, {"$set": {"note": "failover demo"}},
                        upsert=True)
    except PyMongoError as e:
        log(f"(seed write failed: {type(e).__name__})")

    log(f"WATCH started on {rs_uri(base)}")
    last, down_since = None, None
    while not stop.is_set():
        try:
            cur = coll.find({}).limit(1)
            list(cur)
            member = "%s:%s" % cur.address
            if down_since is not None:
                log(f"RECONNECTED -> now reading from {member} "
                    f"(no service for {time.time() - down_since:.2f}s)")
                down_since = None
            elif last is not None and member != last:
                log(f"SWITCHED  {last} -> {member}")
            else:
                log(f"read OK from {member}")
            last = member
        except PyMongoError as e:
            if down_since is None:
                down_since = time.time()
                log(f"READ FAILED ({type(e).__name__}) - "
                    f"primary lost, waiting for election ...")
            else:
                log("still no primary ...")
        stop.wait(interval)
    client.close()
    log("WATCH stopped")


# ------------------------------------------------------------------- main
def main(argv=None):
    ap = argparse.ArgumentParser(description=TITLE)
    ap.add_argument("mode", choices=["stepdown", "watch", "demo"])
    ap.add_argument("--base-port", type=int, default=28017)
    args = ap.parse_args(argv)
    print(f"\n=== {TITLE} ===\n")

    if args.mode == "stepdown":
        return 0 if do_stepdown(args.base_port) else 1

    if args.mode == "watch":
        stop = threading.Event()
        try:
            watch(args.base_port, stop)
        except KeyboardInterrupt:
            stop.set()
        return 0

    # demo: reader in the background + two forced stepDowns
    stop = threading.Event()
    t = threading.Thread(target=watch, args=(args.base_port, stop),
                         daemon=True)
    t.start()
    time.sleep(5)
    first = do_stepdown(args.base_port)
    time.sleep(8)
    log(">>> Forcing a SECOND stepDown to watch the reader reconnect again")
    second = do_stepdown(args.base_port)
    time.sleep(8)
    stop.set()
    t.join()

    ok = first is not None and second is not None and first != second
    show("Lab 8.2 - Failover check", ["Check", "Result"], [
        ("First stepDown elected a new primary", "PASS" if first else "FAIL"),
        ("Second stepDown elected another primary",
         "PASS" if second and second != first else "FAIL"),
        ("Reader kept running through both elections", "PASS" if ok else "FAIL"),
    ])
    show("Next", ["Next", "Command / value"], [
        ("Open a shell on a member", "docker exec -it chapter-08-mongo1 mongosh"),
        ("Run by hand", "rs.stepDown()  then  rs.status()"),
        ("Stop the cluster",
         "docker compose -f docker-compose-lab8_1.yml down"),
    ])
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
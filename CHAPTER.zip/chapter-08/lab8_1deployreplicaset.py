"""
Lab 8.1: Deploy a Local Replica Set (Docker Compose + mongosh, driven from Python)

This is the Python version of the lab_01 shell script. It does the same four steps and prints
each result as a table:

  1. Start the 3-node cluster from docker-compose-lab8_1.yml (docker compose up -d).
  2. Initialise replica set rs0 with mongosh and wait for an election.
  3. Insert a document into the PRIMARY and check it appears on both SECONDARIES.
  4. Run rs.status() and identify the primary, the secondaries and their health.

Needs only Docker Desktop (running) and Python. mongosh is run INSIDE the containers
(docker exec), so you do not have to install it on your computer, and the script works
the same in PowerShell, Command Prompt, macOS and Linux (no bash required).

Run:    python lab8_1deployreplicaset.py

Options
  --base-port 27017   host port of node 1; nodes 2 and 3 use +1 and +2 (use this if 27017 is
                      already taken by a local mongod or another container)
  --fresh             delete any earlier lab containers AND their data before starting
  --down              stop and remove the containers when the lab is finished (data is kept)

Differences from the original shell script (deliberate)
  * All three members hold data. The shell script made the third one an arbiter, but an
    arbiter stores no documents, so the lab step "appears on both secondaries" needs two
    real secondaries.
  * It waits until an election has finished instead of sleeping a fixed 10 s + 15 s.
  * 'use chapter-08;' does not work inside mongosh --eval, so db.getSiblingDB("chapter-08") is used.
"""

import argparse
import json
import os
import shutil
import socket
import subprocess
import sys
import textwrap
import time
import uuid
from pathlib import Path

HERE = Path(__file__).resolve().parent
COMPOSE_FILE = "docker-compose-lab8_1.yml"
REPL_SET = "rs0"
HOST_ALIAS = "host.docker.internal"
CONTAINERS = ["chapter-08-mongo1", "chapter-08-mongo2", "chapter-08-mongo3"]

# mongosh runs inside each container and talks to that container's own mongod.
DIRECT_URI = "mongodb://localhost:27017/?directConnection=true"
SECONDARY_URI = "mongodb://localhost:27017/?directConnection=true&readPreference=secondaryPreferred"


# ---------------------------------------------------------------------------
# Table printer (same grid style as the earlier labs)
# ---------------------------------------------------------------------------
def print_table(headers, rows, max_widths=None, align=None):
    n = len(headers)
    max_widths = max_widths or [40] * n
    align = align or ["<"] * n

    def wrap(cell, width):
        return textwrap.wrap(str(cell), width) or [""]

    head = [wrap(h, max_widths[i]) for i, h in enumerate(headers)]
    body = [[wrap(c, max_widths[i]) for i, c in enumerate(r)] for r in rows]
    widths = [
        max(len(line) for line in head[i] + [ln for r in body for ln in r[i]])
        for i in range(n)
    ]

    def border(left, mid, right):
        return left + mid.join("─" * (w + 2) for w in widths) + right

    def render(cells, aligns):
        height = max(len(c) for c in cells)
        lines = []
        for k in range(height):
            parts = []
            for i, c in enumerate(cells):
                text = c[k] if k < len(c) else ""
                parts.append(" " + format(text, f"{aligns[i]}{widths[i]}") + " ")
            lines.append("│" + "│".join(parts) + "│")
        return lines

    out = [border("┌", "┬", "┐")]
    out += render(head, ["<"] * n)
    for r in body:
        out.append(border("├", "┼", "┤"))
        out += render(r, align)
    out.append(border("└", "┴", "┘"))
    print("\n".join(out))


def heading(text):
    print(f"\n=== {text} ===")


# ---------------------------------------------------------------------------
# Running docker and mongosh
# ---------------------------------------------------------------------------
def run(cmd, check=True, timeout=300, env=None):
    try:
        res = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8",
                             errors="replace", timeout=timeout, env=env, cwd=HERE)
    except FileNotFoundError:
        sys.exit(f"'{cmd[0]}' was not found. Install Docker Desktop and make sure it is on your PATH.")
    except subprocess.TimeoutExpired:
        sys.exit(f"Timed out running: {' '.join(cmd[:5])} ...")
    if check and res.returncode != 0:
        raise RuntimeError((res.stderr or res.stdout).strip()[-600:])
    return res


def compose_command():
    if run(["docker", "compose", "version"], check=False).returncode == 0:
        return ["docker", "compose"]
    if shutil.which("docker-compose"):
        return ["docker-compose"]
    return None


def mongosh(container, js, uri=DIRECT_URI, timeout=90):
    return run(["docker", "exec", container, "mongosh", uri, "--quiet", "--eval", js],
               check=False, timeout=timeout)


def mongosh_json(container, js, uri=DIRECT_URI, timeout=90):
    """Run JavaScript that prints one JSON line and return it as a Python object."""
    res = mongosh(container, js, uri=uri, timeout=timeout)
    for line in reversed(res.stdout.strip().splitlines()):
        line = line.strip()
        if line.startswith("{") or line.startswith("["):
            try:
                return json.loads(line)
            except json.JSONDecodeError:
                continue
    detail = (res.stderr or res.stdout).strip().splitlines()
    return {"ok": 0, "error": detail[-1][:200] if detail else "no output"}


def port_in_use(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        return s.connect_ex(("127.0.0.1", port)) == 0


def container_rows():
    res = run(["docker", "ps", "--filter", "name=chapter-08-", "--format", "{{.Names}}|{{.Status}}|{{.Ports}}"],
              check=False)
    rows = []
    for line in sorted(res.stdout.strip().splitlines()):
        name, status, ports = (line.split("|") + ["", ""])[:3]
        first_port = ports.split(",")[0].replace("0.0.0.0:", "").strip()
        rows.append([name, status, first_port])
    return rows


# ---------------------------------------------------------------------------
# JavaScript sent to mongosh (each snippet prints a single JSON line)
# ---------------------------------------------------------------------------
PING_JS = "print(db.adminCommand({ping: 1}).ok)"

INITIATE_JS = """
try {
  const r = rs.initiate({
    _id: "%(set)s",
    members: [
      { _id: 0, host: "%(host)s:%(p1)d", priority: 2 },
      { _id: 1, host: "%(host)s:%(p2)d" },
      { _id: 2, host: "%(host)s:%(p3)d" }
    ]
  });
  print(JSON.stringify({ok: r.ok}));
} catch (e) {
  print(JSON.stringify({ok: 0, code: e.code, error: e.message}));
}
"""

ELECTION_JS = """
try {
  const s = rs.status();
  print(JSON.stringify({
    ok: s.ok,
    primary: s.members.filter(m => m.stateStr === "PRIMARY").map(m => m.name),
    states: s.members.map(m => m.stateStr)
  }));
} catch (e) {
  print(JSON.stringify({ok: 0, error: e.message}));
}
"""

STATUS_JS = """
const s = rs.status();
const conf = rs.conf();
const prim = s.members.find(m => m.stateStr === "PRIMARY");
const prio = {};
conf.members.forEach(m => { prio[m.host] = m.priority; });
print(JSON.stringify({
  set: s.set,
  members: s.members.map(m => ({
    name: m.name,
    state: m.stateStr,
    health: m.health,
    uptime: m.uptime,
    lag: (prim && m.optimeDate) ? (prim.optimeDate - m.optimeDate) / 1000 : null,
    syncFrom: m.syncSourceHost || "",
    priority: prio[m.name]
  }))
}));
"""

INSERT_JS = """
const r = db.getSiblingDB("chapter-08").testcollection.insertOne(
  { message: "Hello from replica set!", timestamp: new Date(), run_id: "__RUN__", lab: "8.1" },
  { writeConcern: { w: "majority", wtimeout: 10000 } }
);
print(JSON.stringify({ack: r.acknowledged, id: r.insertedId.toString()}));
"""

READ_JS = """
const col = db.getSiblingDB("chapter-08").testcollection;
const d = col.findOne({run_id: "__RUN__"});
print(JSON.stringify(d
  ? {found: true, id: d._id.toString(), message: d.message, timestamp: d.timestamp, total: col.countDocuments({})}
  : {found: false}));
"""


# ---------------------------------------------------------------------------
# Waiting helpers
# ---------------------------------------------------------------------------
def wait_for_mongod(container, timeout=120):
    start = time.time()
    while time.time() - start < timeout:
        res = mongosh(container, PING_JS, timeout=30)
        if res.stdout.strip().endswith("1"):
            return True, time.time() - start
        time.sleep(2)
    return False, time.time() - start


def wait_for_election(timeout=120):
    start = time.time()
    last = {}
    ok = False
    while time.time() - start < timeout:
        last = mongosh_json(CONTAINERS[0], ELECTION_JS)
        states = last.get("states", [])
        if (last.get("ok") and len(last.get("primary", [])) == 1 and len(states) == 3
                and set(states) <= {"PRIMARY", "SECONDARY"}):
            ok = True
            break
        print(f"\r  waiting for the election and initial sync... {time.time() - start:.0f} s",
              end="", flush=True)
        time.sleep(2)
    print("\r" + " " * 60 + "\r", end="")
    return ok, time.time() - start


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main(argv=None):
    ap = argparse.ArgumentParser(description="Lab 8.1: Deploy a Local Replica Set")
    ap.add_argument("--base-port", type=int, default=27017)
    ap.add_argument("--fresh", action="store_true")
    ap.add_argument("--down", action="store_true")
    args = ap.parse_args(argv)

    ports = [args.base_port + i for i in range(3)]
    container_for_port = dict(zip(ports, CONTAINERS))
    env = {**os.environ, "MONGO1_PORT": str(ports[0]), "MONGO2_PORT": str(ports[1]),
           "MONGO3_PORT": str(ports[2])}
    checks = []

    if not (HERE / COMPOSE_FILE).exists():
        print(f"{COMPOSE_FILE} must be in the same folder as this script ({HERE}).")
        return 1
    if run(["docker", "info"], check=False).returncode != 0:
        print("Docker is not running. Start Docker Desktop, wait until it says it is running, "
              "and try again.")
        return 1
    compose = compose_command()
    if not compose:
        print("Docker Compose was not found. Update Docker Desktop (it includes 'docker compose').")
        return 1
    up_cmd = compose + ["-f", COMPOSE_FILE]

    heading("Lab 8.1: Deploy a Local Replica Set")
    print_table(
        ["Setting", "Value"],
        [
            ["Replica set name", REPL_SET],
            ["Compose file", COMPOSE_FILE],
            ["Members (host ports)", ", ".join(f"{c} = {p}" for p, c in container_for_port.items())],
            ["Member addresses", ", ".join(f"{HOST_ALIAS}:{p}" for p in ports)],
        ],
        max_widths=[24, 80],
    )

    # ----- Step 1: start the containers -----
    heading("Step 1: Start the 3-node cluster (docker compose up -d)")
    if args.fresh:
        run(up_cmd + ["down", "-v"], env=env, check=False)
    existing = run(["docker", "ps", "-a", "--filter", "name=chapter-08-", "--format", "{{.Names}}"],
                   check=False).stdout.split()
    if not existing:
        busy = [p for p in ports if port_in_use(p)]
        if busy:
            print_table(
                ["Problem", "What to do"],
                [[f"Port(s) {', '.join(map(str, busy))} on this computer are already in use "
                  "(a local mongod or another container?)",
                  "Stop that program, or run this lab on other ports, for example: "
                  "python lab8_1deployreplicaset.py --base-port 28017"]],
                max_widths=[58, 62],
            )
            return 1
    print("Starting containers (the first run downloads the mongo image, which can take a minute)...")
    try:
        run(up_cmd + ["up", "-d"], env=env, timeout=900)
    except RuntimeError as exc:
        print(f"docker compose up failed:\n{exc}")
        return 1
    rows = container_rows()
    print_table(["Container", "Status", "Host port -> container port"], rows, max_widths=[22, 36, 40])
    checks.append(("3 containers running", len(rows) == 3 and all(r[1].startswith("Up") for r in rows)))

    # ----- Step 2: initialise the replica set -----
    heading("Step 2: Initialise the replica set with mongosh")
    rows = []
    all_up = True
    for c in CONTAINERS:
        ok, secs = wait_for_mongod(c)
        all_up &= ok
        rows.append([f"{c}: mongod answers ping", "yes" if ok else "NO", f"{secs:.0f} s"])
    print_table(["Check", "Result", "Time"], rows, max_widths=[44, 8, 8], align=["<", "<", ">"])
    if not all_up:
        print("A node did not start. Check the logs with: docker logs chapter-08-mongo1")
        return 1

    init_js = INITIATE_JS % {"set": REPL_SET, "host": HOST_ALIAS, "p1": ports[0], "p2": ports[1], "p3": ports[2]}
    init = mongosh_json(CONTAINERS[0], init_js)
    if init.get("ok") == 1:
        init_text = "rs.initiate() succeeded"
    elif init.get("code") == 23:
        init_text = "already initialised (reusing the existing replica set)"
    else:
        print(f"rs.initiate() failed: {init.get('error')}")
        return 1
    elected, secs = wait_for_election()
    print_table(
        ["Check", "Result"],
        [["Initialise replica set " + REPL_SET, init_text],
         ["Election finished and secondaries synced", f"{'yes' if elected else 'NO'} (after {secs:.0f} s)"]],
        max_widths=[44, 60],
    )
    checks.append(("Replica set initialised", True))
    checks.append(("Primary elected, secondaries synced", elected))
    if not elected:
        print("No stable primary yet. Look at: docker logs chapter-08-mongo1")
        return 1

    status = mongosh_json(CONTAINERS[0], STATUS_JS)
    members = status.get("members", [])
    primary = next((m for m in members if m["state"] == "PRIMARY"), None)
    secondaries = [m for m in members if m["state"] == "SECONDARY"]

    def container_of(member):
        return container_for_port[int(member["name"].rsplit(":", 1)[1])]

    # ----- Step 3: insert on the primary, read on the secondaries -----
    heading("Step 3: Insert on the PRIMARY and verify on both SECONDARIES")
    run_id = uuid.uuid4().hex[:12]
    ins = mongosh_json(container_of(primary), INSERT_JS.replace("__RUN__", run_id))
    print_table(
        ["Write to the primary", "Value"],
        [
            ["Primary", f"{primary['name']} ({container_of(primary)})"],
            ["Database / collection", "chapter-08.testcollection"],
            ["Document", 'message "Hello from replica set!", timestamp, run_id ' + run_id],
            ["Write concern", "majority (acknowledged by most members before returning)"],
            ["Acknowledged / _id", f"{ins.get('ack')} / {ins.get('id')}"],
        ],
        max_widths=[26, 70],
    )

    primary_doc = mongosh_json(container_of(primary), READ_JS.replace("__RUN__", run_id))
    rows = [[primary["name"], "PRIMARY", "yes" if primary_doc.get("found") else "NO", "-",
             primary_doc.get("total", "-"), "source of the write"]]
    replicated = bool(primary_doc.get("found"))
    for m in members:
        if m["state"] != "SECONDARY":
            continue
        doc, attempts = {}, 0
        for attempts in range(1, 11):
            doc = mongosh_json(container_of(m), READ_JS.replace("__RUN__", run_id), uri=SECONDARY_URI)
            if doc.get("found"):
                break
            time.sleep(1)
        same = (doc.get("found") and doc.get("id") == primary_doc.get("id")
                and doc.get("message") == primary_doc.get("message")
                and doc.get("timestamp") == primary_doc.get("timestamp"))
        replicated &= bool(same)
        rows.append([m["name"], "SECONDARY", "yes" if doc.get("found") else "NO",
                     "yes" if same else "NO", doc.get("total", "-"), f"found on attempt {attempts}"])
    print_table(
        ["Node", "Role", "Document visible", "Identical to primary", "Docs in collection", "Note"],
        rows,
        max_widths=[28, 10, 16, 20, 18, 24],
        align=["<", "<", "<", "<", ">", "<"],
    )
    checks.append(("Document replicated to every secondary", replicated and len(secondaries) == 2))

    # ----- Step 4: rs.status() -----
    heading("Step 4: rs.status() - primary, secondaries and health")
    status = mongosh_json(CONTAINERS[0], STATUS_JS)
    members = status.get("members", [])
    rows = []
    for m in members:
        lag = m.get("lag")
        rows.append([
            m["name"], m["state"], f"{m['health']} ({'up' if m['health'] == 1 else 'DOWN'})",
            f"{m.get('uptime', 0):,} s", "-" if lag is None else f"{lag:.0f} s",
            m.get("syncFrom") or "-", m.get("priority", "-"),
        ])
    print_table(
        ["Member", "State", "Health", "Uptime", "Lag behind primary", "Syncing from", "Priority"],
        rows,
        max_widths=[28, 10, 10, 10, 18, 28, 8],
        align=["<", "<", "<", ">", ">", "<", ">"],
    )
    primary = next((m for m in members if m["state"] == "PRIMARY"), None)
    secondaries = [m for m in members if m["state"] == "SECONDARY"]
    unhealthy = [m["name"] for m in members if m["health"] != 1]
    print()
    print_table(
        ["Question", "Answer"],
        [
            ["Which member is the PRIMARY?", primary["name"] if primary else "none"],
            ["Which members are SECONDARIES?", ", ".join(m["name"] for m in secondaries) or "none"],
            ["Health of each member",
             "All members report health 1 (up)" if not unhealthy else "Not healthy: " + ", ".join(unhealthy)],
            ["Why is that member the primary?",
             "It has priority 2 (the others have 1), so it wins the election when all members are up"],
        ],
        max_widths=[34, 80],
    )
    checks.append(("All members healthy", not unhealthy and len(members) == 3))

    print("\nWhat the states mean:")
    print_table(
        ["State", "Meaning"],
        [
            ["PRIMARY", "Accepts all writes and records them in the oplog"],
            ["SECONDARY", "Copies the oplog from another member and applies it; can serve reads"],
            ["STARTUP2 / RECOVERING", "Doing the initial sync or catching up; not ready to serve yet"],
            ["DOWN / UNKNOWN", "Not reachable from this member; health shows 0"],
            ["Health", "1 = the member answered its last heartbeat, 0 = it did not"],
        ],
        max_widths=[24, 80],
    )

    # ----- Result -----
    heading("Lab 8.1 result")
    print_table(
        ["Check", "Result"],
        [[name, "PASS" if ok else "FAIL"] for name, ok in checks],
        max_widths=[44, 8],
    )
    print()
    print_table(
        ["Next", "Command / value"],
        [
            ["Connection string for PyMongo",
             "mongodb://" + ",".join(f"{HOST_ALIAS}:{p}" for p in ports) + f"/?replicaSet={REPL_SET}"],
            ["Open a shell on the primary", f"docker exec -it {container_of(primary)} mongosh" if primary else "-"],
            ["Stop the cluster", f"docker compose -f {COMPOSE_FILE} down"],
            ["Stop and delete the data", f"docker compose -f {COMPOSE_FILE} down -v"],
        ],
        max_widths=[32, 90],
    )

    if args.down:
        run(up_cmd + ["down"], env=env, check=False)
        print("\nContainers stopped and removed (the data volumes were kept).")

    return 0 if all(ok for _, ok in checks) else 1


if __name__ == "__main__":
    sys.exit(main())
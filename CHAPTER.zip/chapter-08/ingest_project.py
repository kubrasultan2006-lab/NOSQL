"""
ingest_project.py - teach the chatbot about the WHOLE CTI Digest project.

Scans the project and writes project_knowledge.json (next to chatbot.py). chatbot.py loads that file
automatically, retrieves the most relevant chunks for each question and gives them to the LLM.
If MongoDB is reachable the chunks are also stored in chatbot.project_knowledge.

What it reads (read-only):
  * app.js            page titles + descriptions for every chapter, and what each lab / activity does
  * server.py         every API route with its docstring, ports and services
  * chapter-*/*.py    the docstring at the top of each lab and activity script
  * *.md, lab-*.txt, "Lab *" report .txt files (first part of each)

Run it again whenever you add chapters or edit scripts:

    cd chapter-08
    python ingest_project.py
"""
import ast
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
# chapter-08 sits inside the repo root (pymongo-quickstart); scan the root when it exists
ROOT = os.path.abspath(os.path.join(HERE, "..")) if os.path.isdir(os.path.join(HERE, "..", "chapter-07")) else HERE
OUT = os.path.join(HERE, "project_knowledge.json")
MAX_CHUNK = 900

chunks = []


def clean(s):
    s = re.sub(r"\$\{[^}]*\}", "", s)               # JS template holes
    s = re.sub(r"<[^>]+>", " ", s)                  # html tags
    s = s.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
    return re.sub(r"\s+", " ", s).strip()


def add(title, source, text):
    text = text.strip()
    if len(text) < 30:
        return
    # split long text into paragraphs of at most MAX_CHUNK characters
    parts, cur = [], ""
    for para in re.split(r"\n\s*\n|(?<=[.!?])\s+(?=[A-Z])", text):
        if len(cur) + len(para) + 1 > MAX_CHUNK and cur:
            parts.append(cur)
            cur = ""
        cur = (cur + " " + para).strip()
    if cur:
        parts.append(cur)
    for i, p in enumerate(parts[:6]):
        t = title if len(parts) == 1 else f"{title} (part {i + 1})"
        chunks.append({"id": len(chunks), "title": t, "source": source, "text": p})


# --------------------------------------------------------------------------
# 0. Hand-written overview (always present)
# --------------------------------------------------------------------------
OVERVIEW = """CTI Digest is a cyber-threat-intelligence platform used as the running example for the course 23CSE528 NoSQL Database using MongoDB. It starts in Chapter 7 with seeded threat articles, sources, threat actors and vulnerabilities (CVEs) in MongoDB, and each later chapter adds one production concern: replica sets (8), consistency and the CAP theorem (9), transactions (10), sharding (11), security (12), containers and cloud (13), monitoring and backup (14), multi-tenant cases (15), polyglot persistence with Cassandra and Neo4j (16), vector search and RAG (17) and a comparative capstone (18). The web front end is index.html + app.js served by Live Server on port 5500; the back end is server.py (Flask, port 5000) which runs the lab scripts and reads MongoDB. 'Demo data' mode shows simulated results when the server or MongoDB is not running. The final assessment adds this chat assistant: a RAG chatbot using MongoDB as conversation memory and knowledge store, an LLM (Ollama locally or OpenAI), and a read-only system check."""
add("Project overview", "overview", OVERVIEW)

PORTS = """Ports and services used by the project: Flask server.py 5000; Live Server front end 5500; replica set rs0 members on 27017-27019 (or 28017-28019 if the base port was shifted); Chapter 13 production replica set (user rsadmin) on 27047; sharded cluster mongos router on 27117 (shard1rs, shard2rs, config server cfgrs); auth-enabled mongo-auth container on 27028 (Chapter 12, admin user); TLS container mongo-tls (Chapter 12); MongoDB exporter metrics on 9216 and Prometheus (Chapter 13); Ollama on 11434 (models llama3.2 and nomic-embed-text for Chapter 17; the chatbot uses OLLAMA_MODEL); Chapter 7 data lives in the database chapter-07 (override with CTI_DB). Use MONGO_URI, CH15_URI, CH16_URI, CH17_ONLINE, CH18_LIVE, CASSANDRA_HOST and NEO4J_URI environment variables to change connections."""
add("Ports, services and environment variables", "overview", PORTS)

CHAT = """The chat assistant (final assessment) is chatbot.py + the floating chat button in app.js. POST /api/chat takes {message, session_id}. It stores every message in MongoDB (database chatbot, collection sessions) so conversations survive restarts, retrieves project knowledge from project_knowledge.json (made by ingest_project.py) and optional vector search on the knowledge collection, then asks the LLM (Ollama by default, OpenAI with LLM_BACKEND=openai). When a question asks about threats on the PC ("check my PC for threats", "run the script, then show the final project") it runs the READ-ONLY threat scan in check_threats.py and explains the findings. The scan checks files in Downloads, Desktop and Temp against known-bad hashes and the EICAR antivirus test file, disguised names like invoice.pdf.com, start-up entries, open ports and databases reachable from the network, MongoDB without a password, attacker tools such as mimikatz or xmrig, and Windows Defender being disabled. It never deletes, moves or fixes anything. Questions about threads, CPU, RAM or the system add a READ-ONLY system snapshot (OS, logical CPUs, thread counts, RAM, disk, which services are up). The chatbot never runs commands. Demo order: 1) python check_threats.py, 2) python server.py, 3) open index.html and show the final project and the chatbot. GET /api/chat/health, GET /api/system and GET /api/threats expose status."""
add("Chat assistant and read-only system check", "overview", CHAT)

# --------------------------------------------------------------------------
# 1. app.js
# --------------------------------------------------------------------------
js_path = os.path.join(HERE, "app.js")
if not os.path.exists(js_path):
    js_path = os.path.join(ROOT, "app.js")
if os.path.exists(js_path):
    js = open(js_path, encoding="utf-8", errors="replace").read()
    seen = set()
    for h1, lead in re.findall(r'<h1>([^<]*)</h1>\s*<p class="lead">(.*?)</p>', js, flags=re.S):
        h1, lead = clean(h1), clean(lead)
        if (h1, lead) in seen or not lead:
            continue
        seen.add((h1, lead))
        add(h1, "app.js page", f"{h1}: {lead}")
    lines = js.splitlines()
    for i, line in enumerate(lines):
        m = re.match(r"\s*async\s+([la])(\d{2,3})\(", line)
        if not m:
            continue
        kind = "Lab" if m.group(1) == "l" else "Activity"
        digits = m.group(2)
        ch, sub = digits[:-1], digits[-1]
        block = [line]
        for nxt in lines[i + 1:i + 4]:
            if re.match(r"\s*(async\s|pages\.)", nxt):
                break
            block.append(nxt)
        strings = re.findall(r'"((?:[^"\\]|\\.){25,})"|`((?:[^`\\]|\\.){25,})`', " ".join(block))
        steps = [clean(a or b) for a, b in strings]
        steps = [s for s in steps if " " in s and not s.startswith(("http", "docker compose"))][:12]
        if steps:
            add(f"{kind} {ch}.{sub} (what it does, simulated run)", "app.js lab",
                f"{kind} {ch}.{sub}: " + " | ".join(steps))

# --------------------------------------------------------------------------
# 2. server.py routes
# --------------------------------------------------------------------------
sv_path = os.path.join(HERE, "server.py")
if os.path.exists(sv_path):
    sv = open(sv_path, encoding="utf-8", errors="replace").read()
    routes = []
    for verb, path, fn, doc in re.findall(
            r'@app\.(get|post)\("([^"]+)"\)\s*\ndef (\w+)\([^)]*\):\s*\n\s+(?:"""(.*?)""")?', sv, flags=re.S):
        routes.append(f"{verb.upper()} {path} -> {fn}" + (f": {clean(doc)}" if doc else ""))
    if routes:
        add("Server API routes (server.py)", "server.py", "Flask routes in server.py. " + " ; ".join(routes))
    lab_map = re.findall(r'"(l\d+|a\d+)":\s*\[+"([^"]+)"', sv)
    if lab_map:
        add("Which script each lab button runs", "server.py",
            "The Run buttons call POST /api/replica/run/<lab>, which starts these scripts: " +
            "; ".join(f"{k} = {v}" for k, v in lab_map))

# --------------------------------------------------------------------------
# 3. lab scripts, docs and reports under the repo root
# --------------------------------------------------------------------------
SKIP_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv", "env", ".vscode"}
SKIP_FILES = {"server.py", "chatbot.py", "ingest_project.py", "check_threads.py", "metrics.log", ".env"}
for dirpath, dirnames, filenames in os.walk(ROOT):
    dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
    for fn in sorted(filenames):
        if fn in SKIP_FILES or fn.startswith(".env"):
            continue
        path = os.path.join(dirpath, fn)
        rel = os.path.relpath(path, ROOT)
        try:
            if fn.endswith(".py"):
                doc = ast.get_docstring(ast.parse(open(path, encoding="utf-8", errors="replace").read()))
                if doc:
                    add(os.path.splitext(fn)[0], rel, f"Script {rel}: {doc[:2500]}")
            elif fn.lower().endswith((".md", ".txt")) and os.path.getsize(path) < 400_000:
                body = open(path, encoding="utf-8", errors="replace").read()
                add(os.path.splitext(fn)[0], rel, f"File {rel}: {body[:2500]}")
        except Exception as exc:                      # unreadable or not valid Python: skip it
            print(f"  skipped {rel}: {str(exc)[:60]}")

# --------------------------------------------------------------------------
# write results
# --------------------------------------------------------------------------
with open(OUT, "w", encoding="utf-8") as fh:
    json.dump(chunks, fh, indent=1, ensure_ascii=False)
print(f"Wrote {len(chunks)} chunks to {OUT}")

try:   # optional: also keep them in MongoDB (knowledge store)
    from pymongo import MongoClient
    c = MongoClient(os.getenv("MONGO_URI", "mongodb://localhost:27017"), serverSelectionTimeoutMS=2000)
    c.admin.command("ping")
    col = c[os.getenv("MONGO_DB", "chatbot")]["project_knowledge"]
    col.delete_many({})
    col.insert_many([dict(x) for x in chunks])
    print(f"Also stored in MongoDB: {os.getenv('MONGO_DB', 'chatbot')}.project_knowledge")
except Exception as exc:
    print("MongoDB copy skipped:", str(exc)[:80])
sys.exit(0)

r"""
Activity for 8.2: Try it yourself
Configure the replica set with different priority values, PREDICT which
secondary will be elected, run stepDown(), then VERIFY the prediction.

Prerequisite: Lab 8.1 replica set rs0 running on ports 28017-28019.

Usage (from the repo root):
  python chapter-08\lab8_2_priority_election.py --base-port 27017
  python chapter-08\lab8_2_priority_election.py --priorities 3,1,2
  python chapter-08\lab8_2_priority_election.py --priorities 1,5,0 --observe-takeover
  python chapter-08\lab8_2_priority_election.py --reset        # all priorities back to 1

--priorities gives the priority for the members on base-port, base-port+1,
base-port+2 in that order (default 1,2,3).
"""
import argparse
import sys
import time
from datetime import datetime

from pymongo import MongoClient
from pymongo.errors import AutoReconnect, OperationFailure, PyMongoError

try:
    from rich.console import Console
    from rich.table import Table
    console = Console()
except ImportError:
    console = None

HOST = "host.docker.internal"
STEPDOWN_SECS = 30          # old primary cannot be re-elected for this long


# ---------------------------------------------------------------- helpers
def log(msg):
    print(f"[{datetime.now().strftime('%H:%M:%S.%f')[:-3]}] {msg}", flush=True)


def show(title, headers, rows):
    if console:
        t = Table(title=title, show_lines=True)
        for h in headers:
            t.add_column(h)
        for r in rows:
            t.add_row(*[str(c) for c in r])
        console.print(t)
    else:
        print(f"\n{title}")
        print(" | ".join(headers))
        for r in rows:
            print(" | ".join(str(c) for c in r))


def direct(port):
    return MongoClient("localhost", port, directConnection=True,
                       serverSelectionTimeoutMS=1000)


def port_of(host):
    return int(host.rsplit(":", 1)[1])


def member_states(clients):
    out = {}
    for port, c in clients.items():
        try:
            h = c.admin.command("hello")
            out[port] = ("PRIMARY" if h.get("isWritablePrimary")
                         else "SECONDARY" if h.get("secondary") else "OTHER")
        except PyMongoError:
            out[port] = "DOWN"
    return out


def find_primary(clients):
    for p, s in member_states(clients).items():
        if s == "PRIMARY":
            return p
    return None


def wait_for_primary(clients, port, timeout=45):
    end = time.time() + timeout
    while time.time() < end:
        if find_primary(clients) == port:
            return True
        time.sleep(0.5)
    return False


def apply_priorities(clients, prio_by_port):
    """Same as: cfg = rs.conf(); cfg.members[i].priority = n; rs.reconfig(cfg)"""
    pport = find_primary(clients)
    c = clients[pport]
    cfg = c.admin.command("replSetGetConfig")["config"]
    for m in cfg["members"]:
        p = port_of(m["host"])
        if p in prio_by_port and not m.get("arbiterOnly"):
            m["priority"] = prio_by_port[p]
    cfg["version"] += 1
    c.admin.command("replSetReconfig", cfg)
    return c.admin.command("replSetGetConfig")["config"]


# ------------------------------------------------------------------- main
def main(argv=None):
    ap = argparse.ArgumentParser(description="Activity 8.2: priorities")
    ap.add_argument("--base-port", type=int, default=28017)
    ap.add_argument("--priorities", default="1,2,3",
                    help="comma list for base, base+1, base+2")
    ap.add_argument("--reset", action="store_true",
                    help="set every data-bearing priority back to 1 and exit")
    ap.add_argument("--observe-takeover", action="store_true",
                    help="after the check, wait to watch the priority takeover")
    args = ap.parse_args(argv)

    ports = [args.base_port + i for i in range(3)]
    clients = {p: direct(p) for p in ports}
    if find_primary(clients) is None:
        log("No primary found - is the replica set running (Lab 8.1)?")
        return 1

    if args.reset:
        apply_priorities(clients, {p: 1 for p in ports})
        print("All priorities reset to 1.")
        return 0

    values = [int(x) for x in args.priorities.split(",")]
    if len(values) != 3 or max(values) == 0:
        print("--priorities needs 3 numbers, at least one above 0.")
        return 2
    prio = dict(zip(ports, values))

    # ---- 1. configure priorities
    log(f"Applying priorities {prio} ...")
    cfg = apply_priorities(clients, prio)
    show("Replica set config (priority per member)",
         ["Member", "Priority", "Votes", "Arbiter"],
         [(m["host"], m.get("priority", 1), m.get("votes", 1),
           m.get("arbiterOnly", False)) for m in cfg["members"]])

    # ---- 2. let the set settle: the highest priority member becomes primary
    top = max(prio, key=prio.get)
    log(f"Waiting for the highest-priority member ({HOST}:{top}) "
        "to take over as primary (priority takeover) ...")
    if not wait_for_primary(clients, top):
        log("Warning: it did not become primary in time; continuing anyway.")
    old = find_primary(clients)
    log(f"Current primary: {HOST}:{old}")

    # ---- 3. PREDICT
    candidates = {p: v for p, v in prio.items() if p != old and v > 0}
    if not candidates:
        log("No eligible secondary (all have priority 0). Nothing to predict.")
        return 1
    best = max(candidates.values())
    tied = [p for p, v in candidates.items() if v == best]
    predicted = tied[0]
    show("PREDICTION (made before stepDown)", ["Item", "Value"], [
        ("Current primary (will step down)", f"{HOST}:{old}"),
        ("Eligible secondaries (priority > 0)",
         ", ".join(f"{HOST}:{p} (prio {v})" for p, v in candidates.items())),
        ("Rule", "highest priority wins; old primary is barred "
                 f"for {STEPDOWN_SECS}s"),
        ("Predicted new primary",
         f"{HOST}:{predicted}" + ("  (tie - either may win)"
                                  if len(tied) > 1 else "")),
    ])

    # ---- 4. stepDown
    log(f"Running rs.stepDown({STEPDOWN_SECS}) on {HOST}:{old} ...")
    t0 = time.time()
    try:
        clients[old].admin.command("replSetStepDown", STEPDOWN_SECS,
                                  secondaryCatchUpPeriodSecs=10)
    except AutoReconnect:
        pass
    except OperationFailure as e:
        log(f"stepDown refused: {e}")
        return 1

    actual = None
    while time.time() - t0 < 30:
        p = find_primary(clients)
        if p is not None and p != old:
            actual = p
            break
        time.sleep(0.2)
    if actual is None:
        log("No new primary within 30s.")
        return 1
    elapsed = time.time() - t0
    log(f"New primary: {HOST}:{actual} (after {elapsed:.2f}s)")

    # ---- 5. VERIFY
    ok = actual in tied
    show("VERIFICATION", ["Item", "Value"], [
        ("Predicted", f"{HOST}:{predicted}"),
        ("Actual new primary", f"{HOST}:{actual}"),
        ("Prediction correct?", "PASS" if ok else "FAIL"),
        ("Time to elect", f"{elapsed:.2f}s"),
    ])
    show("Next", ["Next", "Command / value"], [
        ("Try another layout",
         "python chapter-08\\lab8_2_priority_election.py --priorities 3,1,2"),
        ("Priority 0 (can never be primary)",
         "python chapter-08\\lab8_2_priority_election.py --priorities 1,5,0"),
        ("Reset", "python chapter-08\\lab8_2_priority_election.py --reset"),
    ])

    # ---- 6. optional: watch the old (higher priority) primary take over again
    if args.observe_takeover:
        log(f"Watching for priority takeover (old primary barred "
            f"{STEPDOWN_SECS}s) ...")
        end = time.time() + STEPDOWN_SECS + 40
        while time.time() < end:
            p = find_primary(clients)
            if p is not None and p != actual:
                log(f"Primary moved to {HOST}:{p} - the higher-priority "
                    "member took the primary role back.")
                break
            time.sleep(1)
        else:
            log("No takeover seen (the new primary already has the "
                "highest priority).")

    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
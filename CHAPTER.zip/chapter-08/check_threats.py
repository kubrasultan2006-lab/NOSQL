"""
check_threats.py - run this FIRST, before showing the final project.

A READ-ONLY threat check of this computer. It looks, it reports, it never changes anything:
nothing is deleted, moved, quarantined, killed or installed, and no file contents leave the machine.

What it checks
  1. Files      hashes files in Downloads, Desktop and the temp folder against known-bad hashes,
                spots the harmless EICAR antivirus test file and "invoice.pdf.exe" style double extensions
  2. Start-up   programs that start with Windows / your login (Run keys, Startup folder, autostart)
                and flags ones that download things, hide windows or run from Temp / Downloads
  3. Ports      what is listening, and which risky services or databases (MongoDB, Ollama, RDP, Telnet...)
                are reachable from the network instead of only from this PC
  4. MongoDB    whether a local MongoDB answers WITHOUT a user name and password
  5. Processes  well-known attacker tools by name (mimikatz, xmrig, psexec...) and programs running from Temp
  6. Defender   whether Windows Defender real-time protection has been switched off by policy

Usage
    python check_threats.py                 # normal check, prints a report, saves threat_report.json
    python check_threats.py --quick         # faster, fewer files
    python check_threats.py --folders D:\\Downloads E:\\Projects
    python check_threats.py --json          # machine-readable output

Optional: pip install psutil  (adds the ports and processes checks)
Optional: put extra "sha256 name" lines in known_bad_hashes.txt next to this script.
"""
import argparse
import hashlib
import json
import os
import platform
import re
import socket
import sys
import tempfile
import time
from datetime import datetime, timezone

try:
    import psutil
except Exception:
    psutil = None

HERE = os.path.dirname(os.path.abspath(__file__))
REPORT_FILE = os.path.join(HERE, "threat_report.json")
IS_WIN = sys.platform.startswith("win")

# SHA-256 of the standard EICAR antivirus test file (harmless, used to test scanners) + any extra hashes you add
KNOWN_BAD_SHA256 = {
    "275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f": "EICAR antivirus test file",
}
EICAR_MARK = b"EICAR-STANDARD-ANTIVIRUS-TEST-FILE"
DOUBLE_EXT = re.compile(r"\.(pdf|docx?|xlsx?|pptx?|txt|jpe?g|png|zip|rar)\.(exe|com|scr|bat|cmd|js|vbs|ps1|pif|lnk)$", re.I)
SKIP_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv", "site-packages"}
SUSPICIOUS_CMD = re.compile(
    r"(-enc(odedcommand)?\b|\\temp\\|/tmp/|appdata\\local\\temp|\\downloads\\|/downloads/|https?://|\bcurl\b|\bwget\b"
    r"|mshta|regsvr32|certutil.*-urlcache|powershell.*-w(indowstyle)?\s+hidden)", re.I)
RISKY_PORTS = {23: "Telnet", 21: "FTP", 3389: "Remote Desktop", 5900: "VNC", 445: "SMB file sharing", 139: "NetBIOS"}
DB_PORTS = {27017: "MongoDB", 27018: "MongoDB", 27019: "MongoDB", 27028: "MongoDB (auth)", 27047: "MongoDB",
            27117: "MongoDB mongos", 28017: "MongoDB", 9042: "Cassandra", 7687: "Neo4j", 11434: "Ollama"}
MONGO_PORTS = [27017, 27018, 27019, 27047, 27117, 28017]
BAD_PROCESS_NAMES = {"mimikatz", "xmrig", "minerd", "nanominer", "cobaltstrike", "beacon", "psexec", "psexesvc",
                     "procdump", "lazagne", "ncat", "netcat", "meterpreter"}
SEV_ORDER = {"high": 0, "medium": 1, "low": 2, "info": 3}


def finding(sev, cat, title, detail="", fix="", evidence=None):
    return {"severity": sev, "category": cat, "title": title, "detail": detail, "fix": fix, "evidence": evidence or {}}


def _known_hashes():
    bad = dict(KNOWN_BAD_SHA256)
    extra = os.path.join(HERE, "known_bad_hashes.txt")
    try:
        with open(extra, encoding="utf-8") as fh:
            for line in fh:
                parts = line.split(None, 1)
                if parts and re.fullmatch(r"[0-9a-fA-F]{64}", parts[0]):
                    bad[parts[0].lower()] = parts[1].strip() if len(parts) > 1 else "listed in known_bad_hashes.txt"
    except OSError:
        pass
    return bad


# --------------------------------------------------------------------------
# 1. Files
# --------------------------------------------------------------------------
def default_folders():
    home = os.path.expanduser("~")
    return [os.path.join(home, "Downloads"), os.path.join(home, "Desktop"), tempfile.gettempdir()]


def check_files(folders, max_files, max_seconds, max_mb=25):
    out, scanned, t0, bad = [], 0, time.time(), _known_hashes()
    stop = False
    for root in folders:
        if stop or not os.path.isdir(root):
            continue
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS and not d.startswith(".")]
            for name in filenames:
                if scanned >= max_files or time.time() - t0 > max_seconds:
                    stop = True
                    break
                path = os.path.join(dirpath, name)
                scanned += 1
                if DOUBLE_EXT.search(name):
                    out.append(finding(
                        "medium", "files", f"Disguised file name: {name}",
                        "A document-looking name that really ends in a program extension, a common phishing trick.",
                        "Do not open it. If you do not recognise it, delete it or scan it with Windows Security.",
                        {"path": path}))
                try:
                    size = os.path.getsize(path)
                    if size > max_mb * 2**20:
                        continue
                    h, head = hashlib.sha256(), b""
                    with open(path, "rb") as fh:
                        head = fh.read(4096)
                        h.update(head)
                        for block in iter(lambda: fh.read(1 << 20), b""):
                            h.update(block)
                    digest = h.hexdigest()
                except OSError:
                    continue
                if digest in bad:
                    out.append(finding("high", "files", f"Known-bad file: {name}", f"SHA-256 matches: {bad[digest]}.",
                                       "Quarantine it from Windows Security (this script will not touch it).",
                                       {"path": path, "sha256": digest}))
                elif EICAR_MARK in head:
                    out.append(finding("high", "files", f"EICAR test signature in {name}",
                                       "Contains the standard antivirus test string (harmless, used to test scanners).",
                                       "Delete it if you did not create it for a test.", {"path": path, "sha256": digest}))
            if stop:
                break
    return out, scanned


# --------------------------------------------------------------------------
# 2. Start-up entries
# --------------------------------------------------------------------------
def startup_entries():
    entries = []   # (where, name, command)
    if IS_WIN:
        try:
            import winreg
            for hive, hn in ((winreg.HKEY_CURRENT_USER, "HKCU"), (winreg.HKEY_LOCAL_MACHINE, "HKLM")):
                for sub in (r"Software\Microsoft\Windows\CurrentVersion\Run",
                            r"Software\Microsoft\Windows\CurrentVersion\RunOnce"):
                    try:
                        key = winreg.OpenKey(hive, sub, 0, winreg.KEY_READ)
                    except OSError:
                        continue
                    i = 0
                    while True:
                        try:
                            n, v, _ = winreg.EnumValue(key, i)
                        except OSError:
                            break
                        entries.append((f"{hn}\\{sub.split(chr(92))[-1]}", n, str(v)))
                        i += 1
        except Exception:
            pass
        folder = os.path.join(os.environ.get("APPDATA", ""), r"Microsoft\Windows\Start Menu\Programs\Startup")
        if os.path.isdir(folder):
            entries += [("Startup folder", f, os.path.join(folder, f)) for f in os.listdir(folder) if f.lower() != "desktop.ini"]
    else:
        d = os.path.expanduser("~/.config/autostart")
        if os.path.isdir(d):
            for f in os.listdir(d):
                cmd = ""
                try:
                    with open(os.path.join(d, f), encoding="utf-8", errors="replace") as fh:
                        for line in fh:
                            if line.startswith("Exec="):
                                cmd = line[5:].strip()
                except OSError:
                    pass
                entries.append(("autostart", f, cmd))
        d = os.path.expanduser("~/Library/LaunchAgents")
        if os.path.isdir(d):
            entries += [("LaunchAgents", f, "") for f in os.listdir(d)]
    return entries


def check_startup():
    entries, out = startup_entries(), []
    for where, name, cmd in entries:
        if SUSPICIOUS_CMD.search(cmd) or SUSPICIOUS_CMD.search(name):
            out.append(finding("medium", "startup", f"Suspicious start-up entry: {name}",
                               "Starts automatically and looks like it downloads code, hides its window or runs from a temporary folder.",
                               "Check it in Task Manager > Startup apps. Disable it only if you do not recognise it.",
                               {"where": where, "command": cmd[:200]}))
    return out, len(entries)


# --------------------------------------------------------------------------
# 3. Listening ports, 4. MongoDB without a password
# --------------------------------------------------------------------------
def listening_ports():
    """[(port, address)] of listening TCP sockets, and a note when the list is incomplete."""
    if psutil:
        try:
            res = {(c.laddr.port, c.laddr.ip) for c in psutil.net_connections(kind="inet")
                   if c.status == "LISTEN" and c.laddr}
            return sorted(res), None
        except Exception as exc:
            note = f"port list incomplete ({type(exc).__name__}); run as administrator for all ports"
    else:
        note = "install psutil (pip install psutil) for the full port and process checks"
    found = []
    for p in list(RISKY_PORTS) + list(DB_PORTS):
        try:
            with socket.create_connection(("127.0.0.1", p), timeout=0.3):
                found.append((p, "127.0.0.1"))
        except OSError:
            pass
    return sorted(set(found)), note


def check_ports():
    ports, note = listening_ports()
    out, exposed_ip = [], {"0.0.0.0", "::", ""}
    risky = [(p, ip) for p, ip in ports if p in RISKY_PORTS and ip in exposed_ip]
    for p, ip in risky:
        out.append(finding("high" if p in (23, 21) else "medium", "ports", f"{RISKY_PORTS[p]} (port {p}) is open to the network",
                           f"Listening on {ip or 'all addresses'}, so other computers can try to connect.",
                           "Turn the service off if you do not use it, or block the port in the firewall.", {"port": p}))
    dbs = sorted({p for p, ip in ports if p in DB_PORTS and ip in exposed_ip})
    if dbs:
        names = ", ".join(f"{DB_PORTS[p]} {p}" for p in dbs)
        out.append(finding("medium", "ports", "Databases / services reachable from the network",
                           f"{names} listen on all network addresses (Docker publishes ports this way by default).",
                           "Publish them as 127.0.0.1:PORT:PORT in docker-compose, or enable authentication and the firewall.",
                           {"ports": dbs}))
    return out, len(ports), sum(1 for _, ip in ports if ip in exposed_ip), note


def check_mongo_auth():
    out = []
    try:
        from pymongo import MongoClient
        from pymongo.errors import OperationFailure
    except Exception:
        return out
    for p in MONGO_PORTS:
        try:
            with socket.create_connection(("127.0.0.1", p), timeout=0.3):
                pass
        except OSError:
            continue
        try:
            MongoClient("127.0.0.1", p, directConnection=True, serverSelectionTimeoutMS=800).list_database_names()
            out.append(finding("medium", "mongodb", f"MongoDB on port {p} answers without a password",
                               "Anyone who can reach this port can read and change the data. Normal for a lab, not for production.",
                               "Enable authentication (see Chapter 12) and keep the port on 127.0.0.1.", {"port": p}))
        except OperationFailure:
            pass            # authentication is required: good
        except Exception:
            pass
    return out


# --------------------------------------------------------------------------
# 5. Processes, 6. Defender
# --------------------------------------------------------------------------
def check_processes():
    if not psutil:
        return [], 0
    out, tmp_runs, n = [], [], 0
    tmp_marks = ("\\temp\\", "/tmp/", "\\appdata\\local\\temp")
    for p in psutil.process_iter(["name", "exe", "pid"]):
        n += 1
        name = (p.info.get("name") or "").lower()
        stem = name[:-4] if name.endswith(".exe") else name
        exe = (p.info.get("exe") or "")
        if stem in BAD_PROCESS_NAMES:
            out.append(finding("high", "processes", f"Attacker tool running: {name}",
                               "This program name is a well-known hacking or crypto-mining tool.",
                               "Investigate right away; if you did not start it, disconnect from the network and run a full scan.",
                               {"pid": p.info.get("pid"), "exe": exe}))
        elif exe and any(m in exe.lower() for m in tmp_marks):
            tmp_runs.append(f"{name} (pid {p.info.get('pid')})")
    if tmp_runs:
        out.append(finding("low", "processes", "Programs running from a temporary folder",
                           ", ".join(tmp_runs[:5]) + ("..." if len(tmp_runs) > 5 else ""),
                           "Installers do this too. Check the ones you do not recognise.", {"count": len(tmp_runs)}))
    return out, n


def check_defender():
    if not IS_WIN:
        return []
    out = []
    try:
        import winreg
        for sub, val in ((r"SOFTWARE\Policies\Microsoft\Windows Defender", "DisableAntiSpyware"),
                         (r"SOFTWARE\Policies\Microsoft\Windows Defender\Real-Time Protection", "DisableRealtimeMonitoring"),
                         (r"SOFTWARE\Microsoft\Windows Defender\Real-Time Protection", "DisableRealtimeMonitoring")):
            try:
                key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, sub, 0, winreg.KEY_READ)
                value, _ = winreg.QueryValueEx(key, val)
            except OSError:
                continue
            if value == 1:
                out.append(finding("high", "defender", "Windows Defender protection is switched off",
                                   f"The setting {val} is 1 in the registry.",
                                   "Turn real-time protection back on in Windows Security > Virus & threat protection.",
                                   {"key": sub, "value": val}))
                break
    except Exception:
        pass
    return out


# --------------------------------------------------------------------------
# Run everything
# --------------------------------------------------------------------------
def is_admin():
    try:
        if IS_WIN:
            import ctypes
            return bool(ctypes.windll.shell32.IsUserAnAdmin())
        return os.geteuid() == 0
    except Exception:
        return False


def scan(folders=None, quick=False):
    """Run all read-only checks and return a dict (also what the chatbot and /api/threats use)."""
    t0 = time.time()
    folders = folders or default_folders()
    max_files, max_seconds = (150, 5) if quick else (1500, 25)
    findings, notes = [], []

    f, scanned = check_files(folders, max_files, max_seconds)
    findings += f
    f, n_start = check_startup()
    findings += f
    f, n_ports, n_exposed, note = check_ports()
    findings += f
    if note:
        notes.append(note)
    findings += check_mongo_auth()
    f, n_proc = check_processes()
    findings += f
    findings += check_defender()

    findings.sort(key=lambda x: SEV_ORDER[x["severity"]])
    counts = {s: sum(1 for x in findings if x["severity"] == s) for s in SEV_ORDER}
    verdict = ("AT RISK: act on the high findings" if counts["high"] else
               "ATTENTION: review the medium findings" if counts["medium"] else
               "No threats found by these checks")
    return {
        "read_only": True,
        "time": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "host": platform.node(),
        "os": platform.platform(),
        "administrator": is_admin(),
        "folders": [f for f in folders if os.path.isdir(f)],
        "checked": {"files": scanned, "startup_entries": n_start, "listening_ports": n_ports,
                    "ports_open_to_network": n_exposed, "processes": n_proc},
        "counts": counts,
        "verdict": verdict,
        "findings": findings,
        "notes": notes,
        "seconds": round(time.time() - t0, 1),
    }


def summary_text(result, limit=8):
    c, k = result["counts"], result["checked"]
    lines = [f"Result: {result['verdict']}",
             f"Findings: {c['high']} high, {c['medium']} medium, {c['low']} low",
             f"Checked: {k['files']} files, {k['startup_entries']} start-up entries, {k['listening_ports']} listening ports "
             f"({k['ports_open_to_network']} open to the network), {k['processes']} processes",
             "Nothing was changed, moved or deleted (read-only)."]
    for f in [x for x in result["findings"] if x["severity"] != "info"][:limit]:
        lines.append(f"- [{f['severity'].upper()}] {f['title']}: {f['detail']}"
                     + (f" Evidence: {f['evidence'].get('path') or f['evidence'].get('command') or ''}"
                        if f["evidence"] and (f["evidence"].get("path") or f["evidence"].get("command")) else ""))
    for n in result["notes"]:
        lines.append(f"Note: {n}")
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser(description="Read-only threat check of this computer.")
    ap.add_argument("--folders", nargs="*", help="folders to hash-check (default: Downloads, Desktop, temp)")
    ap.add_argument("--quick", action="store_true", help="fewer files, finishes in a few seconds")
    ap.add_argument("--json", action="store_true", help="print the report as JSON")
    args = ap.parse_args()

    result = scan(args.folders, args.quick)
    try:
        with open(REPORT_FILE, "w", encoding="utf-8") as fh:
            json.dump(result, fh, indent=2)
    except OSError:
        pass
    if args.json:
        print(json.dumps(result, indent=2))
        return
    bar = "=" * 62
    print(bar + "\n Threat check (READ-ONLY: nothing is changed or deleted)\n" + bar)
    print(f"Computer : {result['host']}  ({result['os']})")
    print(f"Admin    : {'yes' if result['administrator'] else 'no (some checks see less)'}")
    print(f"Folders  : {', '.join(result['folders']) or 'none found'}")
    print("-" * 62)
    print(summary_text(result, limit=0))
    for f in [x for x in result["findings"] if x["severity"] != "info"]:
        print(f"\n[{f['severity'].upper()}] {f['title']}")
        print(f"    {f['detail']}")
        ev = f["evidence"].get("path") or f["evidence"].get("command")
        if ev:
            print(f"    where: {ev}")
        if f["fix"]:
            print(f"    what to do: {f['fix']}")
    print()
    print("-" * 62)
    print(f"Report saved to {REPORT_FILE} ({result['seconds']} s). Now start the project:  python server.py")


if __name__ == "__main__":
    main()

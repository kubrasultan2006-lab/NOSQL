# Run:  pip install flask flask-cors pymongo   then   python server.py
# Put this file in the same folder as your lab8_*.py scripts.
import os, subprocess, sys, threading, time
from collections import deque
from datetime import datetime, timedelta, timezone
from bson import ObjectId
from flask import Flask, jsonify, request
from flask_cors import CORS
from pymongo import MongoClient
import chatbot            # LLM chat assistant + read-only system detection (chatbot.py, same folder)


# Windows pipes default to cp1252, which cannot print the labs' box-drawing tables (UnicodeEncodeError).
# Run every lab script in UTF-8 and read its output as UTF-8.
_run = subprocess.run
def _utf8_run(*a, **kw):
    kw.setdefault("encoding", "utf-8")
    kw.setdefault("errors", "replace")
    kw["env"] = {**os.environ, "PYTHONIOENCODING": "utf-8", "PYTHONUTF8": "1", **(kw.get("env") or {})}
    return _run(*a, **kw)
subprocess.run = _utf8_run

app = Flask(__name__)
CORS(app)
DB_NAME = os.getenv("CTI_DB", "chapter-07")      # the database lab_7_1_Seed_ctidigest.py fills
db = MongoClient(os.getenv("MONGO_URI", "mongodb://localhost:27017"))[DB_NAME]
BASE = 27017
def detect_base():
    """Return the base port (27017 or 28017) of the running replica set. A plain standalone mongod that happens
    to answer first (for example the one holding the chapter-07 data) is only used when no replica-set member
    answers anywhere. None if nothing is up."""
    first = None
    for b in (27017, 28017):
        for p in (b, b + 1, b + 2):
            try:
                c = MongoClient("localhost", p, directConnection=True, serverSelectionTimeoutMS=800)
                h = c.admin.command("hello")
                if h.get("setName"):
                    return b                     # a replica-set member: this is the right base
                if first is None:
                    first = b
            except Exception:
                pass
    return first

def names(b):
    return {b: "mongo1", b + 1: "mongo2", b + 2: "mongo3"}

# ---------------- Chapter 7 ----------------
@app.get("/api/articles")
def articles():
    q = request.args.get("q", "")
    f = {"$or": [{"title": {"$regex": q, "$options": "i"}}, {"tags": q.lower()}]} if q else {}
    docs = db.articles.aggregate([
        {"$match": f}, {"$sort": {"published": -1}}, {"$limit": 15},
        {"$project": {"title": 1, "published": 1, "tags": 1, "actor_ids": 1, "cve_ids": 1,
                      "blocks": {"$size": "$content_blocks"}}}])
    return jsonify([{**d, "_id": str(d["_id"]), "actor_ids": [str(x) for x in d["actor_ids"]]} for d in docs])

@app.get("/api/articles/<id>")
def article(id):
    ref = request.args.get("mode") == "ref"
    a = db.articles.find_one({"_id": ObjectId(id)})
    src = db.sources.find_one({"_id": a["source_id"]})
    acts = list(db.threat_actors.find({"_id": {"$in": a["actor_ids"]}}))
    cves = list(db.vulnerabilities.find({"cve_id": {"$in": a["cve_ids"]}}))
    trips = 1 + 1 + bool(acts) + bool(cves) if ref else 1
    return jsonify({
        "a": {"_id": id, "title": a["title"], "tags": a["tags"], "blocks": len(a["content_blocks"])},
        "src": {"name": src["name"]},
        "act": [{"name": x["name"], "country": x["country"]} for x in acts],
        "cv": [{"cve_id": v["cve_id"], "cvss": v["cvss"], "exploited": v["exploited_in_wild"]} for v in cves],
        "trips": trips})

# ---------------- Chapter 7: data model, working set, cache metrics ----------------
RECENT_DAYS = 90                                   # window used by Activity 7.1 to judge "actual threat"
CH7 = {   # chapter 7 scripts run from the repo root (they all use the chapter-07 database)
    "seed7": ["chapter-07/lab_7_1_Seed_ctidigest.py"],                 # re-seeds articles, sources, actors, CVEs
    "a71": ["chapter-07/lab7_1tryityourself.py"],                      # Activity 7.1: embedded redesign
    "l72": ["chapter-07/lab7_2workingsetanalysis.py"],                 # Lab 7.2: working set (100,000 documents)
    "a72": ["chapter-07/lab7_2tryityourself.py", "--cycles", "3", "--interval", "5", "--simulate-new", "3"],
}


def cache_read():
    """WiredTiger cache counters from db.serverStatus() (raises if the server has no WiredTiger section)."""
    c = db.client.admin.command("serverStatus")["wiredTiger"]["cache"]
    return {"requested": c["pages requested from the cache"], "read_in": c["pages read into cache"],
            "in_cache": c["bytes currently in the cache"], "max": c["maximum bytes configured"], "t": time.time()}


def hit_ratio(prev, cur):
    """Hit ratio for the time between two samples: (pages requested - pages read in) / pages requested."""
    req, miss = cur["requested"] - prev["requested"], cur["read_in"] - prev["read_in"]
    if req <= 0:
        return None, 0, max(miss, 0)
    return max(0.0, min(1.0, 1 - miss / req)), req, max(miss, 0)


_m = {"prev": None, "last": {}, "hist": deque(maxlen=30), "started": False}
_m_lock = threading.Lock()


def _sample():
    cur = cache_read()
    with _m_lock:
        if _m["prev"]:
            r, req, miss = hit_ratio(_m["prev"], cur)
            _m["last"] = {"ratio": None if r is None else round(r * 100, 2), "requests": req, "disk_reads": miss}
            if r is not None:
                _m["hist"].append(round(r * 100, 2))
        _m["prev"] = cur


def _sampler():
    while True:                                   # one sample every 10 seconds, like Activity 7.2
        try:
            _sample()
        except Exception:
            pass
        time.sleep(10)


@app.get("/api/metrics")
def metrics():
    try:
        if not _m["started"]:
            _m["started"] = True
            _sample()
            threading.Thread(target=_sampler, daemon=True).start()
        cur = cache_read()
        with _m_lock:
            last, hist = dict(_m["last"]), list(_m["hist"])
            age = time.time() - (_m["prev"] or cur)["t"]
        since_start = None if cur["requested"] <= 0 else round(max(0.0, min(1.0, 1 - cur["read_in"] / cur["requested"])) * 100, 2)
        by_source = list(db.articles.aggregate([
            {"$group": {"_id": "$source_id", "n": {"$sum": 1}}},
            {"$lookup": {"from": "sources", "localField": "_id", "foreignField": "_id", "as": "s"}},
            {"$project": {"_id": 0, "n": 1, "name": {"$arrayElemAt": ["$s.name", 0]}}}, {"$sort": {"n": -1}}]))
        counts = {n: db[n].estimated_document_count() for n in ("articles", "sources", "threat_actors", "vulnerabilities")}
        return jsonify({"live": True, "hit": last.get("ratio"), "since_start": since_start,
                        "fill": round(cur["in_cache"] / cur["max"] * 100, 2), "in_cache": cur["in_cache"], "max": cur["max"],
                        "requests": last.get("requests", 0), "disk_reads": last.get("disk_reads", 0),
                        "history": hist, "counts": counts, "by_source": by_source, "next_in": max(1, 10 - int(age))})
    except Exception as e:
        return jsonify({"error": f"{type(e).__name__}: {e}"}), 503


@app.get("/api/workingset")
def workingset():
    """Real sizes for the Working set page: the articles collection, the cache, and Lab 7.2's docs_2kb if it exists."""
    try:
        s, c = db.command("collStats", "articles"), cache_read()
        out = {"count": s["count"], "avg_obj": s.get("avgObjSize", 0), "data": s["size"], "storage": s["storageSize"],
               "indexes": s["totalIndexSize"], "cache_max": c["max"], "in_cache": c["in_cache"],
               "coll_in_cache": s.get("wiredTiger", {}).get("cache", {}).get("bytes currently in the cache", 0)}
        if "docs_2kb" in db.list_collection_names():
            d = db.command("collStats", "docs_2kb")
            out["lab72"] = {"count": d["count"], "data": d["size"], "indexes": d["totalIndexSize"],
                            "coll_in_cache": d.get("wiredTiger", {}).get("cache", {}).get("bytes currently in the cache", 0)}
        return jsonify(out)
    except Exception as e:
        return jsonify({"error": f"{type(e).__name__}: {e}"}), 503


@app.get("/api/model/stats")
def model_stats():
    """One row per collection for the Data model page."""
    try:
        have, rows = set(db.list_collection_names()), []
        for n in ("articles", "articles_embedded", "sources", "threat_actors", "vulnerabilities"):
            if n not in have:
                continue
            s = db.command("collStats", n)
            idx = [",".join(k for k, _ in v["key"]) for k, v in db[n].index_information().items() if k != "_id_"]
            rows.append({"name": n, "count": s["count"], "avg_obj": s.get("avgObjSize", 0), "indexes": idx})
        return jsonify({"db": DB_NAME, "collections": rows})
    except Exception as e:
        return jsonify({"error": f"{type(e).__name__}: {e}"}), 503


@app.get("/api/model/actors")
def model_actors():
    """Activity 7.1 verdict, computed read-only: score = articles in the last 90 days + 3 x articles tied to an
    exploited-in-the-wild CVE. Top quarter = high, upper half = medium, the rest = low."""
    try:
        cutoff = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(days=RECENT_DAYS)
        exploited = {v["cve_id"] for v in db.vulnerabilities.find({"exploited_in_wild": True}, {"cve_id": 1})}
        recent, linked = {}, {}
        for art in db.articles.find({}, {"published": 1, "actor_ids": 1, "cve_ids": 1}):
            has = any(c in exploited for c in art.get("cve_ids", []))
            for aid in art.get("actor_ids", []):
                if art["published"].replace(tzinfo=None) >= cutoff:
                    recent[aid] = recent.get(aid, 0) + 1
                if has:
                    linked[aid] = linked.get(aid, 0) + 1
        actors = list(db.threat_actors.find({}, {"name": 1, "country": 1, "motivation": 1}))
        if not actors:
            return jsonify({"actors": [], "actual": 0})
        scores = {a["_id"]: recent.get(a["_id"], 0) + 3 * linked.get(a["_id"], 0) for a in actors}
        ordered = sorted(scores.values())
        median, p75 = ordered[len(ordered) // 2], ordered[(len(ordered) * 3) // 4]
        rows = []
        for a in actors:
            sc = scores[a["_id"]]
            lvl = "high" if sc >= p75 else "medium" if sc >= median else "low"
            rows.append({"name": a["name"], "country": a["country"], "motivation": a["motivation"],
                         "score": sc, "level": lvl, "actual": lvl != "low"})
        rows.sort(key=lambda r: -r["score"])
        return jsonify({"actors": rows, "actual": sum(r["actual"] for r in rows), "days": RECENT_DAYS})
    except Exception as e:
        return jsonify({"error": f"{type(e).__name__}: {e}"}), 503


# ---------------- Chapter 8 ----------------
@app.get("/api/replica/status")
def status():
    b = detect_base()
    if b is None:
        return jsonify({"members": []}), 503
    for p in names(b):
        try:
            c = MongoClient("localhost", p, directConnection=True, serverSelectionTimeoutMS=2000)
            st = c.admin.command("replSetGetStatus")
            out = []
            for m in st["members"]:
                port = int(m["name"].rsplit(":", 1)[1])
                out.append({"name": names(b).get(port, "mongo-arbiter"), "state": m["stateStr"]})
            return jsonify({"members": out})
        except Exception:
            continue
    return jsonify({"members": []}), 503

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.join(HERE, "..")          # repo root (pymongo-quickstart); scripts run from here
SCRIPTS = {
    "l81": ["chapter-08/lab8_1deployreplicaset.py"],
    "a81": ["chapter-08/lab8_1_add_arbiter_try_it.py", "--base-port", str(BASE)],
    "l82": ["chapter-08/lab8_2_observe_failover.py", "demo", "--base-port", str(BASE)],
    "a82": ["chapter-08/lab8_2_priority_election_TRY_IT_YOURSELF.py", "--base-port", str(BASE), "--priorities", "3,2,1"],
    "l91": ["chapter-09/lab9_1_write_concern_latency.py", "--base-port", str(BASE)],
    "a91": ["chapter-09/Activity for 9.1 - Try it yourself.py", "--base-port", str(BASE)],
    "l92": ["chapter-09/Lab 9.2 - Simulate a network partition.py", "--base-port", str(BASE)],
    "l101": ["chapter-10/Lab 10.1 - Bank transfer transaction.py", "--base-port", str(BASE)],
    "a101": ["chapter-10/Activity for 10.1 - Try it yourself.py", "--base-port", str(BASE)],
    "l102": ["chapter-10/Lab 10.2 - Inventory reservation with deadlock handling.py", "--base-port", str(BASE)],
}

CH14_URI = "mongodb://localhost:27047/"     # Chapter 13 replica set (rsadmin); change if your monitor connects elsewhere
CH14 = {   # chapter 14 scripts run from the chapter-14 folder
    "l141": ["Lab 14.1 - Build a Monitoring Dashboard.py", "--uri", CH14_URI, "--count", "1",
             "--cache-threshold", "100", "--lag-threshold", "0"],
    "a141": ["Activity for 14.1 - Try it yourself.py", "--uri", CH14_URI, "--test-receiver", "--simulate",
             "--interval", "3", "--count", "4"],
    "l142": ["Lab 14.2 - Automated Backup and Restore Verification.py", "--verify"],
    "b14": ["Lab 14.2 - Automated Backup and Restore Verification.py", "--backup-now"],   # Operations > Back up now
    "v14": ["Lab 14.2 - Automated Backup and Restore Verification.py", "--verify"],       # Operations > Verify restore
}

CH16 = {   # chapter 16: MongoDB is real, Cassandra and Neo4j are simulated in memory by the scripts
    "l161": ["chapter-16/Lab 16.1 - Model Data in Three Databases.py"],
    "a161": ["chapter-16/Activity for 16.1 - Try it yourself.py"],
    "l162": ["chapter-16/Lab 16.2 - Build a Hybrid Query Service.py"],
}
# Leave CH16_URI unset to use each script's own default (rsadmin on 27047). Or set it before starting the server:
#   PowerShell:  $env:CH16_URI = "mongodb://rsadmin:RsLabPass123@127.0.0.1:27017/?authSource=admin"
CH16_URI = os.getenv("CH16_URI")

CH15 = {   # chapter 15: self-tests of the multi-tenant API (they start no server unless you add --serve yourself)
    "l151": ["chapter-15/Lab 15.1 - Design a Multi-Tenant API.py"],
    "a151": ["chapter-15/Activity for 15.1 - Try it yourself.py"],
    "l152": ["chapter-15/Lab 15.2 - Data Migration Between Tenant Isolation Strategies.py"],
}
# Same idea as CH16_URI: unset = each script's default (rsadmin on 27047). Needs: pip install fastapi uvicorn pymongo pyjwt httpx python-dotenv
CH15_URI = os.getenv("CH15_URI")

CH17 = {   # chapter 17: vector search and RAG. By default the scripts run with --offline (no Atlas, no Ollama needed)
    "l171": ["chapter-17/Lab 17.1 - Build a Simple RAG Pipeline.py"],
    "a171": ["chapter-17/Activity for 17.1 - Try it yourself.py"],
    "l172": ["chapter-17/Lab 17.2 - Compare HNSW and IVF Vector Indexes.py"],
}
# To run them online instead (Atlas $vectorSearch + Ollama), set before starting server.py:
#   PowerShell:  $env:CH17_ONLINE = "1"; $env:MONGO_URI = "mongodb+srv://<user>:<password>@<cluster>.mongodb.net/"
# The scripts read MONGO_URI (not MONGO_URI_ATLAS), so use that name in .env or the environment.
CH17_ONLINE = os.getenv("CH17_ONLINE") == "1"
OLLAMA = os.getenv("OLLAMA_HOST", "http://localhost:11434")


@app.get("/api/rag/status")
def rag_status():
    """Is Ollama up, which models are pulled, and is an Atlas URI configured? (never returns the URI itself)"""
    import json, urllib.request
    out = {"ollama": False, "models": [], "atlas_configured": False}
    try:
        body = urllib.request.urlopen(OLLAMA + "/api/tags", timeout=3).read().decode()
        out["models"] = [m["name"] for m in json.loads(body).get("models", [])]
        out["ollama"] = True
    except Exception:
        pass
    env_file = os.path.join(ROOT, ".env")
    out["online_mode"] = CH17_ONLINE
    if os.getenv("MONGO_URI"):
        out["atlas_configured"] = True
    elif os.path.exists(env_file):
        with open(env_file, encoding="utf-8") as fh:
            out["atlas_configured"] = any(l.strip().startswith("MONGO_URI=") for l in fh)
    out["embed_model"] = any(m.startswith("nomic-embed-text") for m in out["models"])
    out["chat_model"] = any(m.startswith("llama3.2") for m in out["models"])
    return jsonify(out)


CH18 = {   # chapter 18: comparative capstone. Lab 18.2 reads the report Lab 18.1 writes, so run 18.1 first
    "l181": ["chapter-18/Lab 18.1 - Build the Comparative System.py"],
    "a181": ["chapter-18/Activity for 18.1 - Try it yourself.py"],
    "l182": ["chapter-18/Lab 18.2 - Write a Comparative Analysis Report.py"],
}
# Lab 18.1 and Activity 18.1 run with --offline unless CH18_LIVE=1 (then MONGO_URI, CASSANDRA_HOST, NEO4J_URI,
# NEO4J_USER and NEO4J_PASSWORD must be set before starting server.py). Lab 18.2 has no options.
CH18_LIVE = os.getenv("CH18_LIVE") == "1"


CLOUD = {   # chapter 13 scripts run from the chapter-13 folder (compose files and manifests live there)
    "l131": ["lab3.1.py"],
    "f13": ["lab3.1.py"],          # Operations > Test failover
    "l132": ["Lab 13.2 - Kubernetes StatefulSet for MongoDB.py"],
}

def run_a131():
    """Start the exporter and Prometheus next to the replica set, then read the exporter."""
    import urllib.request
    d = os.path.join(ROOT, "chapter-13")
    r = subprocess.run(["docker", "compose", "-f", "docker-compose-production.yml", "-f", "docker-compose-monitoring.yml",
                        "up", "-d"], capture_output=True, text=True, cwd=d, timeout=300)
    log = r.stdout + r.stderr
    time.sleep(10)
    try:
        body = urllib.request.urlopen("http://localhost:9216/metrics", timeout=10).read().decode()
        n = sum(1 for x in body.splitlines() if x.startswith("mongodb_"))
        log += f"\nExporter answering on :9216 with {n} mongodb series"
        return r.returncode == 0 and n > 0, log
    except Exception as e:
        return False, log + f"\nExporter not reachable: {e}"

SECURE = {   # chapter 12: auth-enabled server (mongo-auth on 27028) and a TLS container
    "l121": [["chapter-12/Lab 12.1 - Authentication and RBAC.py"]],
    "a121": [["chapter-12/Activity for 12.1 - Try it yourself.py"]],
    "a122": [["chapter-12/Activity for 12.2 - Try it yourself.py"]],
}

def ensure_auth_container():
    """Start (or create) the mongo-auth container the chapter-12 labs need."""
    ps = subprocess.run(["docker", "ps", "-a", "--filter", "name=^mongo-auth$", "--format", "{{.Status}}"],
                        capture_output=True, text=True).stdout.strip()
    if ps.startswith("Up"):
        return
    if ps:
        subprocess.run(["docker", "start", "mongo-auth"], capture_output=True, text=True)
    else:
        subprocess.run(["docker", "run", "-d", "--name", "mongo-auth", "-p", "27028:27017",
                        "-e", "MONGO_INITDB_ROOT_USERNAME=admin", "-e", "MONGO_INITDB_ROOT_PASSWORD=AdminPass123!",
                        "mongo:8.0", "--auth"], capture_output=True, text=True)
    time.sleep(8)

MONGOS = "mongodb://localhost:27117"      # mongos of docker-compose-sharded.yml
A111 = "chapter-11/Activity for 11.1 - Try it yourself.py"
SHARDED = {   # chapter 11 runs against the sharded cluster, not the replica set
    "l111": [["chapter-11/Lab 11.1 - Evaluate shard key choices.py"]],
    "a111": [[A111, "--uri", MONGOS, "--create-demo"], [A111, "--uri", MONGOS]],
    "l112": [["chapter-11/Lab 11.2 - Shard key hotspot detection.py", "--uri", MONGOS]],
}


# ---------------- Chapter 16: real Cassandra / Neo4j (optional) and the live fraud review ----------------
# Leave these unset and the labs and the Fraud review simulate the two databases in memory.
# PowerShell, before starting server.py:
#   $env:CASSANDRA_HOST = "127.0.0.1"
#   $env:NEO4J_URI = "bolt://127.0.0.1:7687"; $env:NEO4J_USER = "neo4j"; $env:NEO4J_PASSWORD = "YourPassword123"
# Needs: pip install cassandra-driver neo4j   (each is only needed for the database you switch on)
CASSANDRA_HOST = os.getenv("CASSANDRA_HOST")
NEO4J_URI = os.getenv("NEO4J_URI")
NEO4J_USER = os.getenv("NEO4J_USER", "neo4j")
NEO4J_PASSWORD = os.getenv("NEO4J_PASSWORD", "")
FRAUD_URI = CH16_URI or os.getenv("MONGO_URI", "mongodb://rsadmin:RsLabPass123@127.0.0.1:27047/?authSource=admin")


def real_flags():
    """Extra arguments that make Lab 16.1 / Lab 16.2 use real servers instead of the in-memory ones."""
    f = []
    if CASSANDRA_HOST:
        f += ["--cassandra", CASSANDRA_HOST]
    if NEO4J_URI:
        f += ["--neo4j-uri", NEO4J_URI, "--neo4j-user", NEO4J_USER, "--neo4j-password", NEO4J_PASSWORD]
    return f


_fraud = {}


def fraud_service():
    """Build Lab 16.2's FraudQueryService once. Its circuit breakers live as long as this server runs."""
    if _fraud:
        return _fraud
    import importlib.util
    path = os.path.join(ROOT, "chapter-16", "Lab 16.2 - Build a Hybrid Query Service.py")
    spec = importlib.util.spec_from_file_location("lab162", path)
    lab = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(lab)
    client = MongoClient(FRAUD_URI, maxPoolSize=10, serverSelectionTimeoutMS=4000)
    client.admin.command("ping")
    db = client["chapter-16-web"]            # its own database: the lab runs drop theirs
    db.transactions.drop()
    lab.seed_mongo(db)
    cassandra = lab.real_cassandra_session(CASSANDRA_HOST)[1] if CASSANDRA_HOST else lab.FakeCassandraSession(lab.EVENTS)
    neo4j = lab.real_neo4j_driver(NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD) if NEO4J_URI else lab.FakeNeo4jDriver(lab.TRANSFERS)
    _fraud.update(lab=lab, real_neo4j=neo4j, broken=lab.BrokenNeo4jDriver(),
                  svc=lab.FraudQueryService(db, cassandra, neo4j),
                  mode={"mongodb": "real", "cassandra": "real" if CASSANDRA_HOST else "simulated",
                        "neo4j": "real" if NEO4J_URI else "simulated"})
    return _fraud


def breakers_state(f):
    return {n: {"open": b.is_open, "failures": b.failures} for n, b in f["svc"].breakers.items()}


def fraud_or_503():
    try:
        return fraud_service(), None
    except Exception as e:                   # MongoDB, Cassandra or Neo4j could not be reached
        _fraud.clear()
        return None, (jsonify({"error": f"{type(e).__name__}: {e}"}), 503)


@app.get("/api/fraud/status")
def fraud_status():
    f, err = fraud_or_503()
    return err or jsonify({"mode": f["mode"], "breakers": breakers_state(f)})


@app.post("/api/fraud/analyze/<txn_id>")
def fraud_analyze(txn_id):
    f, err = fraud_or_503()
    if err:
        return err
    down = bool((request.get_json(silent=True) or {}).get("neo4j_down"))
    f["svc"].neo4j = f["broken"] if down else f["real_neo4j"]      # "Simulate Neo4j down" swaps in a driver that always fails
    result = f["svc"].analyze_transaction(txn_id)
    return jsonify({"result": result, "breakers": breakers_state(f), "mode": f["mode"]})


@app.post("/api/fraud/reset")
def fraud_reset():
    f, err = fraud_or_503()
    if err:
        return err
    lab = f["lab"]
    f["svc"].breakers = {n: lab.CircuitBreaker(n) for n in ("mongodb", "cassandra", "neo4j")}
    f["svc"].neo4j = f["real_neo4j"]
    return jsonify({"mode": f["mode"], "breakers": breakers_state(f)})

# ---------------- Final assessment: LLM chat assistant ----------------
@app.post("/api/chat")
def chat():
    """RAG chat. Answers from MongoDB knowledge + history; for questions about threads/CPU/RAM it adds a
    READ-ONLY snapshot of this computer (nothing is executed or changed)."""
    out = chatbot.handle_chat(request.get_json(silent=True) or {})
    return jsonify(out), (400 if "error" in out else 200)


@app.get("/api/chat/health")
def chat_health():
    return jsonify(chatbot.health())


@app.get("/api/threats")
def threats():
    """Read-only threat check of this computer (same scan as check_threats.py). Changes nothing."""
    import check_threats
    return jsonify(check_threats.scan(quick=request.args.get("quick") == "1"))


@app.get("/api/system")
def system_info():
    """Read-only system detection (same data check_threads.py prints)."""
    snap = chatbot.detect_system()
    return jsonify({"system": snap, "text": chatbot.snapshot_text(snap)})


@app.post("/api/replica/run/<lab>")
def run_lab(lab):
    if lab in CH7:
        env = {**os.environ, "PYTHONIOENCODING": "utf-8"}        # the labs print box-drawing characters
        r = subprocess.run([sys.executable, *CH7[lab]], capture_output=True, text=True, encoding="utf-8",
                           errors="replace", timeout=1800, cwd=ROOT, env=env)
        return jsonify({"ok": r.returncode == 0, "log": r.stdout + r.stderr})
    if lab in CH18:
        cmd = CH18[lab] + (["--offline"] if lab != "l182" and not CH18_LIVE else [])
        r = subprocess.run([sys.executable, *cmd], capture_output=True, text=True, timeout=1800, cwd=ROOT)
        return jsonify({"ok": r.returncode == 0, "log": r.stdout + r.stderr})
    if lab in CH17:
        cmd = CH17[lab] + ([] if CH17_ONLINE else ["--offline"])
        r = subprocess.run([sys.executable, *cmd], capture_output=True, text=True, timeout=1500, cwd=ROOT)
        return jsonify({"ok": r.returncode == 0, "log": r.stdout + r.stderr})
    if lab in CH15:
        cmd = CH15[lab] + (["--uri", CH15_URI] if CH15_URI else [])
        r = subprocess.run([sys.executable, *cmd], capture_output=True, text=True, timeout=300, cwd=ROOT)
        return jsonify({"ok": r.returncode == 0, "log": r.stdout + r.stderr})
    if lab in CH16:
        cmd = CH16[lab] + (["--uri", CH16_URI] if CH16_URI else [])
        if lab in ("l161", "l162"):          # Activity 16.1 has no real-server options
            cmd += real_flags()
        r = subprocess.run([sys.executable, *cmd], capture_output=True, text=True, timeout=900, cwd=ROOT)
        return jsonify({"ok": r.returncode == 0, "log": r.stdout + r.stderr})
    if lab in CH14:
        r = subprocess.run([sys.executable, *CH14[lab]], capture_output=True, text=True, timeout=600,
                           cwd=os.path.join(ROOT, "chapter-14"))
        return jsonify({"ok": r.returncode == 0, "log": r.stdout + r.stderr})
    if lab == "a131":
        ok, log = run_a131()
        return jsonify({"ok": ok, "log": log})
    if lab in CLOUD:
        r = subprocess.run([sys.executable, *CLOUD[lab]], capture_output=True, text=True, timeout=900,
                           cwd=os.path.join(ROOT, "chapter-13"))
        return jsonify({"ok": r.returncode == 0, "log": r.stdout + r.stderr})
    if lab in SECURE:
        if lab != "a122":
            ensure_auth_container()
        r = subprocess.run([sys.executable, *SECURE[lab][0]], capture_output=True, text=True, timeout=300, cwd=ROOT)
        return jsonify({"ok": r.returncode == 0, "log": r.stdout + r.stderr})
    if lab in SHARDED:
        logs, ok = [], True
        for cmd in SHARDED[lab]:
            r = subprocess.run([sys.executable, *cmd], capture_output=True, text=True, timeout=1500, cwd=ROOT)
            logs.append(r.stdout + r.stderr)
            if r.returncode != 0:
                ok = False
                break
        return jsonify({"ok": ok, "log": "\n".join(logs)})
    b = detect_base()
    if b is None:
        return jsonify({"ok": False, "log": "No MongoDB member answers on ports 27017-27019 or 28017-28019.\n"
                        "Start Docker Desktop and the replica set containers, then try again."})
    cmd = [str(b) if x == str(BASE) else x for x in SCRIPTS[lab]]   # swap in the detected port
    r = subprocess.run([sys.executable, *cmd], capture_output=True, text=True, timeout=240, cwd=ROOT)
    return jsonify({"ok": r.returncode == 0, "log": f"(using base port {b})\n" + r.stdout + r.stderr})

if __name__ == "__main__":
    app.run(port=5000)
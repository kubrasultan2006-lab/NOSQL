
"""
Activity for 11.1: Try it yourself
Research MongoDB 5.0+ resharding: what are the steps and limitations?

This script walks through the documented resharding steps against a SHARDED cluster.
Connect it to a mongos router, not to a replica set member.

Usage (from the pymongo-quickstart folder):

    # 1. Optional: create a sharded demo collection chapter-11.orders (shard key order_id)
    python "chapter-11\\Activity for 11.1 - Try it yourself.py" --uri mongodb://localhost:27117 --create-demo

    # 2. Check the preconditions only (nothing is changed)
    python "chapter-11\\Activity for 11.1 - Try it yourself.py" --uri mongodb://localhost:27117 --check-only

    # 3. Reshard to hashed customer_id (the recommendation from Lab 11.1)
    python "chapter-11\\Activity for 11.1 - Try it yourself.py" --uri mongodb://localhost:27117

Steps the script follows:
  1. Preflight checks: mongos router, server version >= 5.0, collection is sharded,
     no index builds running, no other resharding operation, balancer state,
     rough storage requirement per shard.
  2. Turn the balancer off (it is turned back on at the end, even on errors).
  3. Run the reshardCollection admin command.
  4. Monitor it with $currentOp (coordinator / donor / recipient state, documents copied,
     estimated seconds remaining).
  5. Optional: --commit-after N forces the commit (commitReshardCollection) after N seconds,
     --abort-after N aborts the operation (abortReshardCollection) after N seconds.
  6. Print the old and the new shard key and the chunk distribution.

Requires: pip install pymongo
"""

import argparse
import json
import random
import threading
import time
from datetime import datetime, timedelta, timezone

from pymongo import MongoClient
from pymongo.errors import PyMongoError

DEFAULT_DB = "chapter-11"
DEFAULT_COLL = "orders"


def log(msg):
    print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


# --------------------------------------------------------------------------- demo data
def create_demo(client, db_name, coll_name, n_docs=50_000):
    ns = f"{db_name}.{coll_name}"
    client.drop_database(db_name)
    client.admin.command("enableSharding", db_name)
    client.admin.command("shardCollection", ns, key={"order_id": 1})
    log(f"Sharded {ns} on {{order_id: 1}}")

    rng = random.Random(42)
    start = datetime(2025, 1, 1, tzinfo=timezone.utc)
    coll = client[db_name][coll_name]
    batch = []
    for i in range(n_docs):
        batch.append({
            "order_id": i + 1,
            "customer_id": f"CUST-{rng.randint(1, 5000):05d}",
            "order_date": start + timedelta(minutes=i * 10),
            "total": round(rng.uniform(5, 500), 2),
        })
        if len(batch) == 5000:
            coll.insert_many(batch)
            batch = []
    if batch:
        coll.insert_many(batch)
    log(f"Inserted {n_docs:,} demo orders")


# --------------------------------------------------------------------------- inspection helpers
def chunk_distribution(client, ns):
    cfg = client.config
    meta = cfg.collections.find_one({"_id": ns})
    if meta is None:
        return None, {}
    rows = cfg.chunks.aggregate([
        {"$match": {"uuid": meta["uuid"]}},
        {"$group": {"_id": "$shard", "chunks": {"$sum": 1}}},
        {"$sort": {"_id": 1}},
    ])
    return meta, {r["_id"]: r["chunks"] for r in rows}


def print_layout(client, ns, title):
    meta, dist = chunk_distribution(client, ns)
    if meta is None:
        log(f"{title}: {ns} is not sharded")
        return
    log(f"{title}: shard key {meta['key']}, chunks per shard {dist}")


def current_reshard_ops(client, ns=None):
    match = {"type": "op", "originatingCommand.reshardCollection": {"$exists": True}}
    if ns:
        match["originatingCommand.reshardCollection"] = ns
    return list(client.admin.aggregate([
        {"$currentOp": {"allUsers": True, "localOps": False}},
        {"$match": match},
    ]))


def running_index_builds(client):
    return list(client.admin.aggregate([
        {"$currentOp": {"allUsers": True, "localOps": False}},
        {"$match": {"$or": [
            {"op": "command", "command.createIndexes": {"$exists": True}},
            {"op": "none", "msg": {"$regex": "^Index Build"}},
        ]}},
    ]))


def preflight(client, db_name, coll_name):
    """Check the documented preconditions. Returns True when it is reasonable to continue."""
    ns = f"{db_name}.{coll_name}"
    ok = True

    hello = client.admin.command("hello")
    if hello.get("msg") != "isdbgrid":
        log("FAIL: not connected to a mongos. Resharding must be started through a mongos router.")
        return False
    log("OK: connected to a mongos router")

    version = client.admin.command("buildInfo")["version"]
    major = int(version.split(".")[0])
    if major < 5:
        log(f"FAIL: server version {version}; resharding needs MongoDB 5.0 or later")
        ok = False
    else:
        log(f"OK: server version {version}")

    meta, dist = chunk_distribution(client, ns)
    if meta is None:
        log(f"FAIL: {ns} is not a sharded collection (use --create-demo or shard it first)")
        return False
    log(f"OK: {ns} is sharded on {meta['key']} ({sum(dist.values())} chunks)")

    if running_index_builds(client):
        log("FAIL: index builds are in progress. Wait for them to finish before resharding.")
        ok = False
    else:
        log("OK: no index builds in progress")

    if current_reshard_ops(client):
        log("FAIL: a resharding operation is already running. Only one collection can be resharded at a time.")
        ok = False
    else:
        log("OK: no other resharding operation running")

    status = client.admin.command("balancerStatus")
    log(f"INFO: balancer mode = {status.get('mode')}, running now = {status.get('inBalancerRound')}")

    # Rough storage requirement: ((data + indexes) * 2) / number of shards
    try:
        stats = client[db_name].command("collStats", coll_name)
        shard_count = client.config.shards.count_documents({})
        need = ((stats["storageSize"] + stats["totalIndexSize"]) * 2) / shard_count
        log(f"INFO: collection {stats['storageSize'] / 1e6:.1f} MB + indexes "
            f"{stats['totalIndexSize'] / 1e6:.1f} MB, {shard_count} shards "
            f"-> each shard needs about {need / 1e6:.1f} MB of FREE space (check this on every shard)")
    except PyMongoError as exc:
        log(f"WARN: could not read collStats: {exc}")

    log("REMINDER: also keep I/O capacity below 50%, CPU below 80%, and make sure the app can "
        "tolerate a brief write block (about 2 seconds) near the end.")
    return ok


# --------------------------------------------------------------------------- monitoring
def show_progress(client, ns):
    ops = current_reshard_ops(client, ns)
    if not ops:
        return
    parts = []
    for op in ops:
        service = str(op.get("desc", "")).split(" ")[0].replace("Resharding", "").replace("Service", "")
        state = (op.get("coordinatorState") or op.get("donorState") or op.get("recipientState") or "")
        bit = f"{service}:{state}"
        if "documentsCopied" in op and "approxDocumentsToCopy" in op:
            bit += f" copied {op['documentsCopied']}/{op['approxDocumentsToCopy']}"
        if "remainingOperationTimeEstimatedSecs" in op:
            bit += f" ~{op['remainingOperationTimeEstimatedSecs']}s left"
        parts.append(bit)
    log("PROGRESS: " + " | ".join(parts))


def main():
    parser = argparse.ArgumentParser(description="Activity 11.1: reshard a collection")
    parser.add_argument("--uri", default="mongodb://localhost:27117", help="mongos connection string")
    parser.add_argument("--db", default=DEFAULT_DB)
    parser.add_argument("--collection", default=DEFAULT_COLL)
    parser.add_argument("--key", default='{"customer_id": "hashed"}',
                        help='new shard key as JSON, e.g. {"customer_id": "hashed"}')
    parser.add_argument("--force-redistribution", action="store_true",
                        help="needed to reshard to the SAME shard key (MongoDB 8.0+)")
    parser.add_argument("--num-initial-chunks", type=int, default=None)
    parser.add_argument("--create-demo", action="store_true", help="create a sharded demo collection and exit")
    parser.add_argument("--check-only", action="store_true", help="run the preflight checks and exit")
    parser.add_argument("--commit-after", type=int, default=None, help="force the commit after N seconds")
    parser.add_argument("--abort-after", type=int, default=None, help="abort the operation after N seconds")
    args = parser.parse_args()

    client = MongoClient(args.uri, serverSelectionTimeoutMS=5000)
    ns = f"{args.db}.{args.collection}"

    if args.create_demo:
        create_demo(client, args.db, args.collection)
        print_layout(client, ns, "Demo collection")
        return

    if not preflight(client, args.db, args.collection):
        raise SystemExit("Preflight checks failed; nothing was changed.")
    if args.check_only:
        log("Check-only mode: stopping here.")
        return

    new_key = json.loads(args.key)
    print_layout(client, ns, "BEFORE")

    balancer_was_on = client.admin.command("balancerStatus").get("mode") == "full"
    result = {}

    def run_reshard():
        cmd = {"reshardCollection": ns, "key": new_key}
        if args.force_redistribution:
            cmd["forceRedistribution"] = True
        if args.num_initial_chunks:
            cmd["numInitialChunks"] = args.num_initial_chunks
        try:
            result["reply"] = client.admin.command(cmd)
        except PyMongoError as exc:
            result["error"] = exc

    try:
        # Step 1: the balancer must be off during resharding
        client.admin.command("balancerStop")
        log("Balancer stopped")

        # Step 2: start resharding (the command returns when the operation finishes)
        log(f"Starting reshardCollection {ns} -> {new_key}")
        started = time.time()
        worker = threading.Thread(target=run_reshard, daemon=True)
        worker.start()

        # Step 3: monitor with $currentOp
        committed = aborted = False
        while worker.is_alive():
            time.sleep(2)
            show_progress(client, ns)
            elapsed = time.time() - started
            if args.commit_after and elapsed >= args.commit_after and not committed:
                committed = True
                try:
                    client.admin.command("commitReshardCollection", ns)
                    log("commitReshardCollection sent: writes will block briefly until the commit completes")
                except PyMongoError as exc:
                    log(f"commitReshardCollection failed: {exc}")
            if args.abort_after and elapsed >= args.abort_after and not aborted:
                aborted = True
                try:
                    client.admin.command("abortReshardCollection", ns)
                    log("abortReshardCollection sent (only possible before the commit phase)")
                except PyMongoError as exc:
                    log(f"abortReshardCollection failed: {exc}")
        worker.join()

        if "error" in result:
            log(f"Resharding ended with an error: {type(result['error']).__name__}: {result['error']}")
        else:
            log(f"Resharding finished in {time.time() - started:.0f} s (minimum is about 5 minutes)")
    finally:
        # Step 4: always put the balancer back as it was
        if balancer_was_on:
            client.admin.command("balancerStart")
            log("Balancer started again")
        else:
            log("Balancer was not enabled before; left as it was")

    print_layout(client, ns, "AFTER")
    client.close()


if __name__ == "__main__":
    main()
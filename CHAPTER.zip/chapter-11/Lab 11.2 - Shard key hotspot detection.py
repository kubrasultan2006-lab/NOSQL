"""
Lab 11.2: Shard Key Hotspot Detection

Connect this script to the mongos of the sharded cluster from docker-compose-sharded.yml
(port 27117). It will NOT work against a standalone mongod or a replica set.

Usage (from the pymongo-quickstart folder):

    python "chapter-11\\Lab 11.2 - Shard key hotspot detection.py" --uri mongodb://localhost:27117

What it does:
  1. Creates database chapter-11 with two sharded collections:
       hotspot_data  shard key {ts: 1}            (monotonically increasing timestamp)
       even_data     shard key {user_id: "hashed"} (random ObjectId)
  2. Inserts 10,000 documents into each.
  3. Compares per-shard document counts and data size with the collStats command,
     right after the inserts and again after the balancer has had time to move chunks.
  4. Runs range queries on both collections and reads explain() to see how many shards
     each query touches (targeted vs scatter-gather).
  5. Prints and saves a short report (lab-11.2-report.txt).

To make the balancer react to such a small data set, the script temporarily lowers the
chunk size (default 1 MB) and removes that setting at the end. Exact numbers can vary
between runs, because chunk migration is asynchronous.

Requires: pip install pymongo
"""

import argparse
import random
import time
from datetime import datetime, timedelta, timezone

from bson import ObjectId
from pymongo import MongoClient
from pymongo.errors import PyMongoError

DB_NAME = "chapter-11"
N_DOCS = 10_000
OUT = []


def p(line=""):
    OUT.append(line)
    print(line, flush=True)


# --------------------------------------------------------------------------- setup
def require_mongos(client):
    if client.admin.command("hello").get("msg") != "isdbgrid":
        raise SystemExit(
            "This server is not a mongos router. Start the sharded cluster with\n"
            "  docker compose -f docker-compose-sharded.yml up -d\n"
            "and pass --uri mongodb://localhost:27117"
        )


def setup_collections(client):
    client.drop_database(DB_NAME)
    client.admin.command("enableSharding", DB_NAME)
    client.admin.command("shardCollection", f"{DB_NAME}.hotspot_data", key={"ts": 1})
    client.admin.command("shardCollection", f"{DB_NAME}.even_data", key={"user_id": "hashed"})
    p(f"Sharded {DB_NAME}.hotspot_data on {{ts: 1}} and {DB_NAME}.even_data on {{user_id: 'hashed'}}")


def insert_data(client, payload_bytes):
    db = client[DB_NAME]
    padding = "x" * payload_bytes
    start = datetime(2025, 1, 1, tzinfo=timezone.utc)
    step = timedelta(minutes=50)  # 10,000 docs span about 347 days of 2025

    for name in ("hotspot_data", "even_data"):
        batch = []
        t0 = time.time()
        for i in range(N_DOCS):
            if name == "hotspot_data":
                doc = {"ts": start + i * step, "seq": i, "payload": padding}  # always increasing
            else:
                doc = {"user_id": ObjectId(), "seq": i, "payload": padding}   # random-looking id
            batch.append(doc)
            if len(batch) == 500:
                db[name].insert_many(batch)
                batch = []
        if batch:
            db[name].insert_many(batch)
        p(f"Inserted {N_DOCS:,} documents into {name} in {time.time() - t0:.1f} s")


# --------------------------------------------------------------------------- measurements
def shard_names(client):
    return sorted(s["_id"] for s in client.config.shards.find())


def collstats_table(client, name):
    """Return {shard: (docs, megabytes)} using the collStats command through the mongos."""
    stats = client[DB_NAME].command("collStats", name)
    out = {}
    for sh in shard_names(client):
        s = stats.get("shards", {}).get(sh, {})
        out[sh] = (s.get("count", 0), s.get("size", 0) / 1e6)
    return out


def chunk_counts(client, name):
    meta = client.config.collections.find_one({"_id": f"{DB_NAME}.{name}"})
    rows = client.config.chunks.aggregate([
        {"$match": {"uuid": meta["uuid"]}},
        {"$group": {"_id": "$shard", "chunks": {"$sum": 1}}},
    ])
    counts = {r["_id"]: r["chunks"] for r in rows}
    return {sh: counts.get(sh, 0) for sh in shard_names(client)}


def print_distribution(client, label):
    p(f"\n--- {label} ---")
    results = {}
    for name in ("hotspot_data", "even_data"):
        table = collstats_table(client, name)
        chunks = chunk_counts(client, name)
        total = sum(c for c, _ in table.values()) or 1
        p(f"{name}:")
        p(f"  {'shard':<12}{'documents':>10}{'% of docs':>11}{'size (MB)':>11}{'chunks':>8}")
        for sh, (count, mb) in table.items():
            p(f"  {sh:<12}{count:>10,}{count / total:>10.1%}{mb:>11.2f}{chunks[sh]:>8}")
        results[name] = {sh: c for sh, (c, _) in table.items()}
    return results


def explain_shards(coll, flt):
    """Run explain() through the mongos and return (stage, [shard names touched])."""
    plan = coll.find(flt).explain()["queryPlanner"]["winningPlan"]
    shards = [s.get("shardName") for s in plan.get("shards", [])]
    return plan.get("stage"), shards


def run_queries(client):
    db = client[DB_NAME]
    p("\n--- Range queries and explain() ---")
    start = datetime(2025, 1, 1, tzinfo=timezone.utc)
    last_day = start + timedelta(minutes=50 * (N_DOCS - 1))
    # An ObjectId range (what "a range on user_id" means for the hashed collection)
    lo, hi = ObjectId.from_datetime(start), ObjectId.from_datetime(last_day)
    # A narrow slice of recent data
    recent_lo = last_day - timedelta(days=5)

    queries = [
        ("hotspot_data", "ts range, full year",
         {"ts": {"$gte": start, "$lt": datetime(2025, 12, 31, tzinfo=timezone.utc)}}),
        ("hotspot_data", "ts range, last 5 days only", {"ts": {"$gte": recent_lo, "$lte": last_day}}),
        ("even_data", "user_id range (hashed key)", {"user_id": {"$gte": lo, "$lt": hi}}),
        ("even_data", "user_id equality (hashed key)", {"user_id": ObjectId()}),
    ]
    summary = []
    p(f"  {'collection':<14}{'query':<32}{'stage':<14}shards touched")
    for coll, label, flt in queries:
        if "equality" in label:
            sample = db[coll].find_one()
            flt = {"user_id": sample["user_id"]}
        stage, shards = explain_shards(db[coll], flt)
        p(f"  {coll:<14}{label:<32}{str(stage):<14}{len(shards)} {shards}")
        summary.append((coll, label, stage, shards))
    return summary


# --------------------------------------------------------------------------- report
def write_report(first, settled, queries, total_shards):
    hot = settled["hotspot_data"]
    even = settled["even_data"]
    hot_max = max(hot.values()) / max(sum(hot.values()), 1)
    even_max = max(even.values()) / max(sum(even.values()), 1)

    p("\n" + "=" * 70)
    p("REPORT")
    p("=" * 70)
    p(f"Distribution: hotspot_data (ts: 1) puts {hot_max:.0%} of its documents on its busiest shard; "
      f"even_data (user_id: hashed) puts {even_max:.0%} on its busiest shard "
      f"(ideal is {1 / total_shards:.0%}).")
    p("Queries:")
    for coll, label, stage, shards in queries:
        kind = "targeted" if len(shards) == 1 else f"touches {len(shards)} of {total_shards} shards"
        p(f"  - {coll}, {label}: {stage}, {kind}")
    p("")
    p("Why monotonically increasing keys cause hotspots:")
    p("  Every new document has a key larger than all existing ones, so every insert falls into")
    p("  the chunk with the highest range (maxKey). That chunk lives on one shard, so one shard")
    p("  takes all the writes while the others sit idle. Splitting that chunk does not help,")
    p("  because the next insert again lands in the newest chunk. The balancer can only move")
    p("  OLD chunks to other shards afterwards, so the write throughput of the cluster stays")
    p("  limited to a single shard.")
    p("A hashed key spreads consecutive values across the whole hash space, so inserts are")
    p("  distributed evenly, but a range query on that field must ask every shard.")
    p("")
    p("When a ranged key can still be appropriate:")
    p("  - Write volume is low enough for one shard (the hotspot does not matter).")
    p("  - Range queries on the key dominate the workload (time-window reports, scans).")
    p("  - The key is not monotonic: a compound key such as {tenant_id: 1, ts: 1} spreads writes")
    p("    across tenants and still supports a time range per tenant.")
    p("  - Zones or archiving rely on data ranges, for example the newest data on fast hardware.")


def main():
    parser = argparse.ArgumentParser(description="Lab 11.2: shard key hotspot detection")
    parser.add_argument("--uri", default="mongodb://localhost:27117", help="mongos connection string")
    parser.add_argument("--chunk-size-mb", type=int, default=1,
                        help="temporary chunk size so a small data set can split and migrate")
    parser.add_argument("--payload-bytes", type=int, default=512, help="extra bytes per document")
    parser.add_argument("--settle-seconds", type=int, default=60, help="wait for the balancer")
    args = parser.parse_args()

    client = MongoClient(args.uri, serverSelectionTimeoutMS=5000)
    require_mongos(client)
    shards = shard_names(client)
    p(f"Connected to mongos, shards: {shards}")

    chunk_setting_changed = False
    try:
        client.config.settings.update_one({"_id": "chunksize"}, {"$set": {"value": args.chunk_size_mb}}, upsert=True)
        chunk_setting_changed = True
        p(f"Temporary chunk size: {args.chunk_size_mb} MB")

        setup_collections(client)
        insert_data(client, args.payload_bytes)
        first = print_distribution(client, "Right after the inserts")

        p(f"\nWaiting {args.settle_seconds} s for the balancer to move chunks ...")
        time.sleep(args.settle_seconds)
        settled = print_distribution(client, f"After {args.settle_seconds} s")

        queries = run_queries(client)
        write_report(first, settled, queries, len(shards))
    except PyMongoError as exc:
        p(f"MongoDB error: {type(exc).__name__}: {exc}")
    finally:
        if chunk_setting_changed:
            client.config.settings.delete_one({"_id": "chunksize"})
            p("\nChunk size setting removed (back to the default).")

    with open("lab-11.2-report.txt", "w", encoding="utf-8") as f:
        f.write("\n".join(OUT) + "\n")
    print("Saved lab-11.2-report.txt")
    client.close()


if __name__ == "__main__":
    main()
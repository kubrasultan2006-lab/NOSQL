"""
Lab 15.1: Design a Multi-Tenant API (FastAPI + MongoDB)

A task-management SaaS API with tenant isolation:
  1. Schema      : users, tasks and rate_limits collections. Every user and task document
                   carries a tenant_id. Compound index on tasks: (tenant_id, created_at).
  2. CRUD        : POST/GET/PUT/DELETE /tasks/. tenant_id is NEVER taken from the request; it is
                   read from the JWT token in a FastAPI dependency and added to every query.
  3. Rate limit  : MongoDB is the counter store. One document per tenant and time window in the
                   rate_limits collection, incremented atomically with find_one_and_update
                   (the pymongo name of findAndModify). A TTL index on "ts" removes old counters.
  4. Roles       : each user has a role (admin / user) stored in the user document and in the
                   token. GET /users/ is admin-only. (Ownership rules: Activity for 15.1.)

Modes:
  --selftest   run an automated test of isolation, CRUD, roles, rate limiting (default)
  --serve      start the API with uvicorn (Swagger UI at http://127.0.0.1:8000/docs)
  --seed       insert the demo tenants and users (used with --serve)

Demo users (password for all: Passw0rd!):
  tenant acme  : alice (admin), bob (user), carol (user)
  tenant globex: dave  (admin)

Requires: pip install fastapi uvicorn pymongo pyjwt httpx python-dotenv
"""

import argparse
import hashlib
import os
import secrets
import sys
import time
from datetime import datetime, timedelta, timezone
from typing import Optional

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

import jwt
from bson import ObjectId
from bson.errors import InvalidId
from fastapi import Depends, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from pydantic import BaseModel
from pymongo import MongoClient, ReturnDocument

JWT_SECRET = os.getenv("JWT_SECRET", "lab-15-1-dev-secret-change-me-0123456789")
JWT_ALGORITHM = "HS256"
TOKEN_MINUTES = 60
RATE_TTL_SECONDS = 120          # counters older than this are removed by the TTL index
DEFAULT_DB = "chapter-15"
TEST_DB = "chapter-15_selftest"
DEMO_PASSWORD = "Passw0rd!"
DEMO_USERS = [                  # (tenant_id, username, role)
    ("acme", "alice", "admin"),
    ("acme", "bob", "user"),
    ("acme", "carol", "user"),
    ("globex", "dave", "admin"),
]

settings = {"rate_limit": 100, "window": 60}     # requests per tenant per window (seconds)
client = None
db = None

app = FastAPI(title="TaskTracker Multi-Tenant API")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
bearer = HTTPBearer()


# --------------------------------------------------------------------------
# Database setup
# --------------------------------------------------------------------------
def init_db(uri, name):
    global client, db
    client = MongoClient(uri, serverSelectionTimeoutMS=8000)
    try:
        client.admin.command("ping")
    except Exception as exc:  # noqa: BLE001
        sys.exit(f"Could not connect to MongoDB: {exc}\nCheck --uri (or MONGO_URI in .env).")
    db = client[name]
    ensure_indexes()


def ensure_indexes():
    # Tenant isolation + sorting: every task query starts with tenant_id
    db.tasks.create_index([("tenant_id", 1), ("created_at", 1)], name="tenant_created_at")
    db.tasks.create_index([("tenant_id", 1), ("owner_id", 1)], name="tenant_owner")
    db.users.create_index([("tenant_id", 1), ("username", 1)], unique=True, name="tenant_username")
    # Rate limit counters expire automatically
    db.rate_limits.create_index("ts", expireAfterSeconds=RATE_TTL_SECONDS, name="ttl_ts")


def hash_password(password):
    salt = secrets.token_hex(8)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 100_000).hex()
    return f"{salt}${digest}"


def verify_password(password, stored):
    salt, digest = stored.split("$")
    check = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 100_000).hex()
    return secrets.compare_digest(check, digest)


def seed_demo():
    for tenant, username, role in DEMO_USERS:
        db.users.update_one(
            {"tenant_id": tenant, "username": username},
            {"$setOnInsert": {"password": hash_password(DEMO_PASSWORD), "role": role}},
            upsert=True,
        )


# --------------------------------------------------------------------------
# Models
# --------------------------------------------------------------------------
class LoginRequest(BaseModel):
    tenant_id: str
    username: str
    password: str


class TaskCreate(BaseModel):
    title: str
    description: str
    priority: str = "medium"


class TaskUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    priority: Optional[str] = None
    status: Optional[str] = None


class TaskResponse(TaskCreate):
    id: str
    tenant_id: str
    owner_id: str
    status: str
    created_at: str


class UserResponse(BaseModel):
    id: str
    tenant_id: str
    username: str
    role: str


# --------------------------------------------------------------------------
# Authentication, rate limiting, roles (FastAPI dependencies)
# --------------------------------------------------------------------------
def create_token(user):
    payload = {
        "sub": str(user["_id"]),
        "username": user["username"],
        "tenant_id": user["tenant_id"],
        "role": user["role"],
        "exp": datetime.now(timezone.utc) + timedelta(minutes=TOKEN_MINUTES),
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


def enforce_rate_limit(tenant_id):
    """Fixed-window counter per tenant, stored in MongoDB and incremented atomically."""
    window, limit = settings["window"], settings["rate_limit"]
    now = time.time()
    bucket = int(now // window)
    doc = db.rate_limits.find_one_and_update(
        {"_id": f"{tenant_id}:{bucket}"},
        {"$inc": {"count": 1},
         "$setOnInsert": {"tenant_id": tenant_id, "ts": datetime.now(timezone.utc)}},
        upsert=True,
        return_document=ReturnDocument.AFTER,
    )
    if doc["count"] > limit:
        retry_after = int((bucket + 1) * window - now) + 1
        raise HTTPException(status_code=429, detail=f"Rate limit exceeded ({limit} per {window}s)",
                            headers={"Retry-After": str(retry_after)})


def current_user(creds: HTTPAuthorizationCredentials = Depends(bearer)):
    """tenant_id and role come from the signed token, never from the request body or URL."""
    try:
        claims = jwt.decode(creds.credentials, JWT_SECRET, algorithms=[JWT_ALGORITHM])
    except jwt.PyJWTError:
        raise HTTPException(status_code=401, detail="Invalid or expired token")
    user = {"id": claims["sub"], "username": claims["username"],
            "tenant_id": claims["tenant_id"], "role": claims["role"]}
    enforce_rate_limit(user["tenant_id"])
    return user


def require_admin(user: dict = Depends(current_user)):
    if user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Admin role required")
    return user


# --------------------------------------------------------------------------
# Access rules for tasks (hooks). In this lab every user may see and change every
# task of THEIR OWN tenant. Activity for 15.1 replaces these two functions with RBAC rules.
# --------------------------------------------------------------------------
def task_scope(user):
    """Base filter for listing tasks."""
    return {"tenant_id": user["tenant_id"]}


def can_access(user, task):
    """May this user read/change this task (which already belongs to their tenant)?"""
    return True


# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------
def task_to_json(task):
    task = dict(task)
    task["id"] = str(task.pop("_id"))
    return task


def load_task(task_id, user):
    """Find a task inside the caller's tenant. Other tenants' tasks look like they do not exist."""
    try:
        oid = ObjectId(task_id)
    except (InvalidId, TypeError):
        raise HTTPException(status_code=404, detail="Task not found")
    task = db.tasks.find_one({"_id": oid, "tenant_id": user["tenant_id"]})
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    if not can_access(user, task):
        raise HTTPException(status_code=403, detail="You do not have access to this task")
    return task


# --------------------------------------------------------------------------
# Endpoints (plain "def": FastAPI runs them in a thread pool, which suits blocking pymongo)
# --------------------------------------------------------------------------
@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/auth/login")
def login(body: LoginRequest):
    user = db.users.find_one({"tenant_id": body.tenant_id, "username": body.username})
    if user is None or not verify_password(body.password, user["password"]):
        raise HTTPException(status_code=401, detail="Invalid credentials")
    return {"access_token": create_token(user), "token_type": "bearer"}


@app.post("/tasks/", response_model=TaskResponse)
def create_task(task: TaskCreate, user: dict = Depends(current_user)):
    doc = {
        "tenant_id": user["tenant_id"],
        "owner_id": user["id"],
        "title": task.title,
        "description": task.description,
        "priority": task.priority,
        "status": "open",
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    db.tasks.insert_one(doc)          # adds doc["_id"]
    return task_to_json(doc)


@app.get("/tasks/", response_model=list[TaskResponse])
def list_tasks(user: dict = Depends(current_user)):
    cursor = db.tasks.find(task_scope(user)).sort([("created_at", 1), ("_id", 1)])
    return [task_to_json(t) for t in cursor]


@app.get("/tasks/{task_id}", response_model=TaskResponse)
def get_task(task_id: str, user: dict = Depends(current_user)):
    return task_to_json(load_task(task_id, user))


@app.put("/tasks/{task_id}", response_model=TaskResponse)
def update_task(task_id: str, body: TaskUpdate, user: dict = Depends(current_user)):
    task = load_task(task_id, user)
    updates = body.model_dump(exclude_none=True)
    if not updates:
        raise HTTPException(status_code=400, detail="Nothing to update")
    flt = {"_id": task["_id"], "tenant_id": user["tenant_id"]}
    db.tasks.update_one(flt, {"$set": updates})
    return task_to_json(db.tasks.find_one(flt))


@app.delete("/tasks/{task_id}")
def delete_task(task_id: str, user: dict = Depends(current_user)):
    task = load_task(task_id, user)
    db.tasks.delete_one({"_id": task["_id"], "tenant_id": user["tenant_id"]})
    return {"deleted": task_id}


@app.get("/users/", response_model=list[UserResponse])
def list_users(user: dict = Depends(require_admin)):
    return [{"id": str(u["_id"]), "tenant_id": u["tenant_id"], "username": u["username"],
             "role": u["role"]} for u in db.users.find({"tenant_id": user["tenant_id"]})]


# --------------------------------------------------------------------------
# Self-test helpers (shared with Activity for 15.1)
# --------------------------------------------------------------------------
class Checker:
    def __init__(self):
        self.passed = 0
        self.failed = 0

    def check(self, label, ok, detail=""):
        print(f"  [{'PASS' if ok else 'FAIL'}] {label}" + (f" -> {detail}" if detail else ""))
        if ok:
            self.passed += 1
        else:
            self.failed += 1

    def summary(self):
        print(f"\nRESULT: {self.passed} passed, {self.failed} failed")
        return self.failed == 0


def make_test_env(uri):
    """Fresh test database, demo users, a test client and a login token for every demo user."""
    from fastapi.testclient import TestClient
    tmp = MongoClient(uri, serverSelectionTimeoutMS=8000)
    tmp.drop_database(TEST_DB)
    tmp.close()
    init_db(uri, TEST_DB)
    seed_demo()
    settings["rate_limit"] = 1000
    tc = TestClient(app)
    tokens = {}
    for tenant, username, _role in DEMO_USERS:
        r = tc.post("/auth/login", json={"tenant_id": tenant, "username": username,
                                         "password": DEMO_PASSWORD})
        r.raise_for_status()
        tokens[username] = r.json()["access_token"]
    return tc, tokens


def auth(tokens, who):
    return {"Authorization": f"Bearer {tokens[who]}"}


def make_task(tc, tokens, who, title):
    r = tc.post("/tasks/", json={"title": title, "description": f"created by {who}"},
                headers=auth(tokens, who))
    r.raise_for_status()
    return r.json()


def print_indexes():
    for coll in ("tasks", "users", "rate_limits"):
        for name, info in db[coll].index_information().items():
            if name == "_id_":
                continue
            ttl = f", expireAfterSeconds={info['expireAfterSeconds']}" if "expireAfterSeconds" in info else ""
            uniq = ", unique" if info.get("unique") else ""
            print(f"  {coll}.{name}: {info['key']}{uniq}{ttl}")


def cleanup():
    client.drop_database(TEST_DB)
    client.close()


# --------------------------------------------------------------------------
# Self-test for Lab 15.1
# --------------------------------------------------------------------------
def selftest(uri):
    tc, tokens = make_test_env(uri)
    ck = Checker()

    print("\n1) Login and JWT claims")
    claims = jwt.decode(tokens["bob"], JWT_SECRET, algorithms=[JWT_ALGORITHM])
    ck.check("bob's token carries tenant_id and role", claims["tenant_id"] == "acme" and claims["role"] == "user",
             f"tenant_id={claims['tenant_id']}, role={claims['role']}")
    bad = tc.post("/auth/login", json={"tenant_id": "acme", "username": "bob", "password": "wrong"})
    ck.check("wrong password is rejected", bad.status_code == 401, f"HTTP {bad.status_code}")
    ck.check("no token is rejected", tc.get("/tasks/").status_code in (401, 403))

    print("\n2) Create tasks (tenant_id is set from the token)")
    t_bob1 = make_task(tc, tokens, "bob", "Write report")
    t_bob2 = make_task(tc, tokens, "bob", "Review pull request")
    t_carol = make_task(tc, tokens, "carol", "Plan sprint")
    t_dave = make_task(tc, tokens, "dave", "Globex budget")
    ck.check("acme tasks are stored with tenant_id=acme",
             all(t["tenant_id"] == "acme" for t in (t_bob1, t_bob2, t_carol)))
    ck.check("globex task is stored with tenant_id=globex", t_dave["tenant_id"] == "globex")

    print("\n3) Tenant isolation")
    acme_list = tc.get("/tasks/", headers=auth(tokens, "alice")).json()
    globex_list = tc.get("/tasks/", headers=auth(tokens, "dave")).json()
    ck.check("acme sees only its 3 tasks", len(acme_list) == 3 and {t["tenant_id"] for t in acme_list} == {"acme"},
             f"{len(acme_list)} task(s)")
    ck.check("globex sees only its 1 task", len(globex_list) == 1 and globex_list[0]["tenant_id"] == "globex",
             f"{len(globex_list)} task(s)")
    r = tc.get(f"/tasks/{t_dave['id']}", headers=auth(tokens, "bob"))
    ck.check("acme user cannot read a globex task by id", r.status_code == 404, f"HTTP {r.status_code}")
    r = tc.put(f"/tasks/{t_dave['id']}", json={"status": "done"}, headers=auth(tokens, "bob"))
    ck.check("acme user cannot update a globex task", r.status_code == 404, f"HTTP {r.status_code}")
    r = tc.delete(f"/tasks/{t_dave['id']}", headers=auth(tokens, "bob"))
    ck.check("acme user cannot delete a globex task", r.status_code == 404, f"HTTP {r.status_code}")
    still = db.tasks.find_one({"_id": ObjectId(t_dave["id"])})
    ck.check("globex task is unchanged in the database", still is not None and still["status"] == "open")

    print("\n4) CRUD inside one tenant")
    r = tc.get(f"/tasks/{t_bob1['id']}", headers=auth(tokens, "bob"))
    ck.check("read own task", r.status_code == 200 and r.json()["title"] == "Write report", f"HTTP {r.status_code}")
    r = tc.put(f"/tasks/{t_bob1['id']}", json={"status": "done", "priority": "high"}, headers=auth(tokens, "bob"))
    ck.check("update own task", r.status_code == 200 and r.json()["status"] == "done", f"status={r.json().get('status')}")
    r = tc.delete(f"/tasks/{t_bob2['id']}", headers=auth(tokens, "bob"))
    ck.check("delete own task", r.status_code == 200, f"HTTP {r.status_code}")
    r = tc.get(f"/tasks/{t_bob2['id']}", headers=auth(tokens, "bob"))
    ck.check("deleted task is gone", r.status_code == 404, f"HTTP {r.status_code}")
    r = tc.get("/tasks/not-an-id", headers=auth(tokens, "bob"))
    ck.check("invalid id returns 404", r.status_code == 404, f"HTTP {r.status_code}")
    r = tc.get(f"/tasks/{t_carol['id']}", headers=auth(tokens, "bob"))
    ck.check("same-tenant colleague's task is readable (no RBAC in this lab)", r.status_code == 200,
             f"HTTP {r.status_code}")

    print("\n5) Role check in an endpoint")
    r = tc.get("/users/", headers=auth(tokens, "bob"))
    ck.check("regular user cannot list users", r.status_code == 403, f"HTTP {r.status_code}")
    r = tc.get("/users/", headers=auth(tokens, "alice"))
    ck.check("admin lists only the users of her own tenant",
             r.status_code == 200 and {u["username"] for u in r.json()} == {"alice", "bob", "carol"},
             ", ".join(sorted(u["username"] for u in r.json())))

    print("\n6) Rate limiting (MongoDB counter, limit set to 5 per 60 s for this test)")
    db.rate_limits.delete_many({})
    settings["rate_limit"] = 5
    responses = [tc.get("/tasks/", headers=auth(tokens, "bob")) for _ in range(7)]
    codes = [r.status_code for r in responses]
    print(f"  acme request status codes: {codes}")
    ck.check("first 5 requests pass, the next 2 are blocked", codes == [200] * 5 + [429] * 2)
    ck.check("blocked response has a Retry-After header", "retry-after" in responses[-1].headers,
             f"Retry-After: {responses[-1].headers.get('retry-after')} s")
    r = tc.get("/tasks/", headers=auth(tokens, "dave"))
    ck.check("another tenant is not affected by acme's limit", r.status_code == 200, f"globex HTTP {r.status_code}")
    counter = db.rate_limits.find_one({"tenant_id": "acme"})
    ck.check("counter document stored in MongoDB", counter is not None and counter["count"] == 7,
             f"_id={counter['_id']}, count={counter['count']}")
    settings["rate_limit"] = 1000

    print("\n7) Indexes")
    print_indexes()
    names = db.tasks.index_information()
    ck.check("compound index (tenant_id, created_at) exists",
             any(i["key"] == [("tenant_id", 1), ("created_at", 1)] for i in names.values()))
    ck.check("TTL index on rate_limits.ts exists",
             any("expireAfterSeconds" in i for i in db.rate_limits.index_information().values()))

    ok = ck.summary()
    cleanup()
    return ok


# --------------------------------------------------------------------------
def build_parser(description):
    p = argparse.ArgumentParser(description=description)
    p.add_argument("--uri", default=os.getenv("MONGO_URI", "mongodb://rsadmin:RsLabPass123@127.0.0.1:27047/?authSource=admin"))
    p.add_argument("--db", default=DEFAULT_DB, help="database used by --serve")
    p.add_argument("--selftest", action="store_true", help="run the automated test (default)")
    p.add_argument("--serve", action="store_true", help="start the API with uvicorn")
    p.add_argument("--seed", action="store_true", help="insert the demo tenants and users")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=8000)
    p.add_argument("--rate-limit", type=int, default=100, help="requests per tenant per window")
    p.add_argument("--window", type=int, default=60, help="rate limit window in seconds")
    return p


def serve(args):
    import uvicorn
    init_db(args.uri, args.db)
    settings["rate_limit"], settings["window"] = args.rate_limit, args.window
    if args.seed:
        seed_demo()
        print(f"Demo users seeded in '{args.db}' (password {DEMO_PASSWORD}): "
              + ", ".join(f"{t}/{u} ({r})" for t, u, r in DEMO_USERS))
    print(f"Rate limit: {args.rate_limit} requests per tenant per {args.window} s")
    uvicorn.run(app, host=args.host, port=args.port)


def main():
    args = build_parser("Lab 15.1 - Multi-tenant task API").parse_args()
    if args.serve:
        serve(args)
    else:
        sys.exit(0 if selftest(args.uri) else 1)


if __name__ == "__main__":
    main()
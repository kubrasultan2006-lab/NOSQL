"""
Activity for 15.1 - Try it yourself: role-based access control (RBAC)

Extends "Lab 15.1 - Design a Multi-Tenant API.py" (keep it in the same folder).

Rules added:
  * admin  : can list, read, update and delete ALL tasks of their own tenant
  * user   : can only list, read, update and delete THEIR OWN tasks
  * nobody can ever touch another tenant's tasks (tenant isolation from the lab still applies)

How: the lab routes call two small hook functions, task_scope() (the filter used when listing)
and can_access() (the check for one task). This script replaces them with role-aware versions.
Ownership is the owner_id field stored on every task; the role comes from the JWT token.

Run the automated test (default):
    python "chapter-15\\Activity for 15.1 - Try it yourself.py"
Start the API with RBAC (Swagger UI at http://127.0.0.1:8000/docs):
    python "chapter-15\\Activity for 15.1 - Try it yourself.py" --serve --seed

Requires: pip install fastapi uvicorn pymongo pyjwt httpx python-dotenv
"""

import importlib.util
import sys
from pathlib import Path

LAB_FILE = Path(__file__).resolve().parent / "Lab 15.1 - Design a Multi-Tenant API.py"


def load_lab():
    if not LAB_FILE.exists():
        sys.exit(f"Missing '{LAB_FILE.name}'. Keep the Lab 15.1 script in the same folder as this file.")
    spec = importlib.util.spec_from_file_location("lab151", LAB_FILE)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


lab = load_lab()


# --------------------------------------------------------------------------
# RBAC rules (replace the lab's open hooks)
# --------------------------------------------------------------------------
def rbac_task_scope(user):
    """Listing filter: admins see the whole tenant, regular users only the tasks they own."""
    scope = {"tenant_id": user["tenant_id"]}
    if user["role"] != "admin":
        scope["owner_id"] = user["id"]
    return scope


def rbac_can_access(user, task):
    """Single task: admins always (inside their tenant), users only when they own it."""
    return user["role"] == "admin" or task["owner_id"] == user["id"]


lab.task_scope = rbac_task_scope
lab.can_access = rbac_can_access


# --------------------------------------------------------------------------
# Self-test for the activity
# --------------------------------------------------------------------------
def selftest(uri):
    tc, tokens = lab.make_test_env(uri)
    auth, make_task, ck = lab.auth, lab.make_task, lab.Checker()

    print("\n1) Create tasks")
    t_bob = make_task(tc, tokens, "bob", "Bob's task")
    t_bob2 = make_task(tc, tokens, "bob", "Bob's second task")
    t_carol = make_task(tc, tokens, "carol", "Carol's task")
    t_dave = make_task(tc, tokens, "dave", "Dave's task (other tenant)")
    print("  bob: 2 tasks, carol: 1 task (tenant acme); dave: 1 task (tenant globex)")

    print("\n2) Listing")
    for who, expected, note in [("bob", 2, "own tasks only"), ("carol", 1, "own task only"),
                                ("alice", 3, "admin: every acme task"), ("dave", 1, "admin of globex")]:
        tasks = tc.get("/tasks/", headers=auth(tokens, who)).json()
        ck.check(f"{who} lists {expected} task(s) ({note})", len(tasks) == expected, f"{len(tasks)} task(s)")
    alice_tasks = tc.get("/tasks/", headers=auth(tokens, "alice")).json()
    ck.check("admin alice sees no globex task", all(t["tenant_id"] == "acme" for t in alice_tasks))

    print("\n3) Regular user vs a colleague's task")
    r = tc.get(f"/tasks/{t_carol['id']}", headers=auth(tokens, "bob"))
    ck.check("bob cannot read carol's task", r.status_code == 403, f"HTTP {r.status_code}")
    r = tc.put(f"/tasks/{t_carol['id']}", json={"status": "done"}, headers=auth(tokens, "bob"))
    ck.check("bob cannot update carol's task", r.status_code == 403, f"HTTP {r.status_code}")
    r = tc.delete(f"/tasks/{t_carol['id']}", headers=auth(tokens, "bob"))
    ck.check("bob cannot delete carol's task", r.status_code == 403, f"HTTP {r.status_code}")
    still = lab.db.tasks.find_one({"_id": lab.ObjectId(t_carol["id"])})
    ck.check("carol's task is unchanged in the database", still is not None and still["status"] == "open")

    print("\n4) Regular user vs own task")
    r = tc.put(f"/tasks/{t_bob['id']}", json={"status": "done"}, headers=auth(tokens, "bob"))
    ck.check("bob can update his own task", r.status_code == 200 and r.json()["status"] == "done",
             f"HTTP {r.status_code}")
    r = tc.delete(f"/tasks/{t_bob2['id']}", headers=auth(tokens, "bob"))
    ck.check("bob can delete his own task", r.status_code == 200, f"HTTP {r.status_code}")

    print("\n5) Admin manages all tasks of the tenant")
    r = tc.get(f"/tasks/{t_carol['id']}", headers=auth(tokens, "alice"))
    ck.check("admin alice can read carol's task", r.status_code == 200, f"HTTP {r.status_code}")
    r = tc.put(f"/tasks/{t_carol['id']}", json={"priority": "high"}, headers=auth(tokens, "alice"))
    ck.check("admin alice can update carol's task", r.status_code == 200 and r.json()["priority"] == "high",
             f"priority={r.json().get('priority')}")
    r = tc.delete(f"/tasks/{t_carol['id']}", headers=auth(tokens, "alice"))
    ck.check("admin alice can delete carol's task", r.status_code == 200, f"HTTP {r.status_code}")
    r = tc.get("/users/", headers=auth(tokens, "bob"))
    ck.check("bob still cannot list users", r.status_code == 403, f"HTTP {r.status_code}")

    print("\n6) Admin is still limited to the own tenant")
    r = tc.get(f"/tasks/{t_dave['id']}", headers=auth(tokens, "alice"))
    ck.check("admin alice cannot read a globex task", r.status_code == 404, f"HTTP {r.status_code}")
    r = tc.delete(f"/tasks/{t_dave['id']}", headers=auth(tokens, "alice"))
    ck.check("admin alice cannot delete a globex task", r.status_code == 404, f"HTTP {r.status_code}")
    ck.check("globex task still exists", lab.db.tasks.count_documents({"_id": lab.ObjectId(t_dave["id"])}) == 1)

    ok = ck.summary()
    lab.cleanup()
    return ok


def main():
    args = lab.build_parser("Activity for 15.1 - RBAC for the multi-tenant API").parse_args()
    if args.serve:
        lab.serve(args)
    else:
        sys.exit(0 if selftest(args.uri) else 1)


if __name__ == "__main__":
    main()

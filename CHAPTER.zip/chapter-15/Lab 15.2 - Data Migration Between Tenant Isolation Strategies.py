"""
Lab 15.2: Data Migration Between Tenant Isolation Strategies

Steps (all printed, nothing to type besides the command):
  1. Seed       : document-level isolation. ONE collection "tasks", every document has a
                  tenant_id. 5 tenants x 100 tasks = 500 documents.
  2. Migrate    : collection-per-tenant isolation. For every tenant create "tasks_tenant_<id>"
                  with an aggregation  [{$match: {tenant_id: tid}}, {$out: "tasks_tenant_<id>"}]
  3. Validate   : counts match per tenant, no document of another tenant in a tenant collection,
                  documents are identical, nothing lost or duplicated overall.
  4. Benchmark  : listing a tenant's tasks, creating a task, cross-tenant analytics
                  ($group on one collection vs $unionWith across the tenant collections).
  5. Recommend  : when to use which strategy (query isolation, backup granularity, schema evolution).

Run:
    python "chapter-15\\Lab 15.2 - Data Migration Between Tenant Isolation Strategies.py"
Bigger data (the performance differences become easier to see):
    python "chapter-15\\Lab 15.2 - Data Migration Between Tenant Isolation Strategies.py" --tasks 20000

Uses its own database (default chapter-15), dropped at the end unless --keep is given.
Requires: pip install pymongo python-dotenv      (MongoDB 4.4+ for $unionWith)
"""

import argparse
import os
import random
import statistics
import sys
import time
from datetime import datetime, timedelta, timezone

from pymongo import MongoClient

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

TENANT_NAMES = ["acme", "globex", "initech", "umbrella", "hooli"]
STATUSES = ["open", "in_progress", "done"]
PRIORITIES = ["low", "medium", "high"]


def tenant_ids(n):
    names = list(TENANT_NAMES[:n])
    names += [f"tenant{i}" for i in range(len(names) + 1, n + 1)]
    return names


def coll_name(tid):
    return f"tasks_tenant_{tid}"


# --------------------------------------------------------------------------
# 1) Seed: document-level isolation
# --------------------------------------------------------------------------
def seed(db, tenants, per_tenant):
    rng = random.Random(42)                       # same data on every run
    base = datetime(2026, 1, 1, tzinfo=timezone.utc)
    docs = []
    for tid in tenants:
        for i in range(per_tenant):
            docs.append({
                "_id": f"{tid}-{i + 1:05d}",
                "tenant_id": tid,
                "title": f"Task {i + 1} for {tid}",
                "status": rng.choice(STATUSES),
                "priority": rng.choice(PRIORITIES),
                "created_at": base + timedelta(hours=i * 3 + rng.randint(0, 2)),
            })
    db.tasks.insert_many(docs)
    db.tasks.create_index([("tenant_id", 1), ("created_at", 1)], name="tenant_created_at")
    return len(docs)


# --------------------------------------------------------------------------
# 2) Migrate: collection-per-tenant isolation
# --------------------------------------------------------------------------
def migrate(db, tenants):
    total = 0
    for tid in tenants:
        start = time.perf_counter()
        list(db.tasks.aggregate([{"$match": {"tenant_id": tid}}, {"$out": coll_name(tid)}]))
        db[coll_name(tid)].create_index("created_at", name="created_at")
        secs = time.perf_counter() - start
        count = db[coll_name(tid)].count_documents({})
        total += count
        print(f"   {tid:<9} -> {coll_name(tid):<20} {count:>6} documents ({secs * 1000:.0f} ms)")
    return total


# --------------------------------------------------------------------------
# 3) Validate
# --------------------------------------------------------------------------
class Checker:
    def __init__(self):
        self.passed = 0
        self.failed = 0

    def check(self, label, ok, detail=""):
        print(f"   [{'PASS' if ok else 'FAIL'}] {label}" + (f" -> {detail}" if detail else ""))
        if ok:
            self.passed += 1
        else:
            self.failed += 1


def validate(db, tenants, per_tenant):
    ck = Checker()
    for tid in tenants:
        src = db.tasks.count_documents({"tenant_id": tid})
        dst = db[coll_name(tid)].count_documents({})
        ck.check(f"{tid}: count source = count copy = {per_tenant}", src == dst == per_tenant,
                 f"source {src}, copy {dst}")
        foreign = db[coll_name(tid)].count_documents({"tenant_id": {"$ne": tid}})
        ck.check(f"{tid}: no document of another tenant in {coll_name(tid)}", foreign == 0,
                 f"{foreign} foreign document(s)")
        same = (list(db.tasks.find({"tenant_id": tid}).sort("_id", 1))
                == list(db[coll_name(tid)].find().sort("_id", 1)))
        ck.check(f"{tid}: copied documents are identical to the originals", same)

    total_src = db.tasks.count_documents({})
    total_dst = sum(db[coll_name(t)].count_documents({}) for t in tenants)
    ck.check("total documents: nothing lost, nothing duplicated", total_src == total_dst,
             f"{total_src} in tasks, {total_dst} in tenant collections")
    ck.check("tasks collection has exactly the expected tenants",
             sorted(db.tasks.distinct("tenant_id")) == sorted(tenants))
    return ck


# --------------------------------------------------------------------------
# 4) Benchmark
# --------------------------------------------------------------------------
def measure(fn, repeat, warmup=10):
    for i in range(warmup):
        fn(i)
    times = []
    for i in range(repeat):
        start = time.perf_counter()
        fn(i)
        times.append((time.perf_counter() - start) * 1000)
    return statistics.median(times), statistics.mean(times)


def new_task(tid):
    return {"tenant_id": tid, "title": "benchmark task", "status": "open", "priority": "medium",
            "created_at": datetime.now(timezone.utc), "bench": True}


def benchmark(db, tenants, repeat):
    n = len(tenants)
    group = {"$group": {"_id": {"tenant_id": "$tenant_id", "status": "$status"}, "count": {"$sum": 1}}}
    union = [{"$unionWith": coll_name(t)} for t in tenants[1:]]

    def list_doc(i):
        list(db.tasks.find({"tenant_id": tenants[i % n]}).sort("created_at", 1))

    def list_col(i):
        list(db[coll_name(tenants[i % n])].find().sort("created_at", 1))

    def create_doc(i):
        db.tasks.insert_one(new_task(tenants[i % n]))

    def create_col(i):
        db[coll_name(tenants[i % n])].insert_one(new_task(tenants[i % n]))

    def analytics_doc(i):
        list(db.tasks.aggregate([group]))

    def analytics_col(i):
        list(db[coll_name(tenants[0])].aggregate(union + [group]))

    # Both strategies must give the same analytics answer
    a = {(r["_id"]["tenant_id"], r["_id"]["status"]): r["count"] for r in db.tasks.aggregate([group])}
    b = {(r["_id"]["tenant_id"], r["_id"]["status"]): r["count"]
         for r in db[coll_name(tenants[0])].aggregate(union + [group])}
    print(f"   analytics result identical for both strategies: {a == b}")

    rows = []
    for label, f_doc, f_col in [
        ("List one tenant's tasks (sorted)", list_doc, list_col),
        ("Create a task", create_doc, create_col),
        ("Cross-tenant analytics (count by tenant+status)", analytics_doc, analytics_col),
    ]:
        med_d, mean_d = measure(f_doc, repeat)
        med_c, mean_c = measure(f_col, repeat)
        rows.append((label, med_d, med_c))

    # remove the benchmark documents again
    db.tasks.delete_many({"bench": True})
    for t in tenants:
        db[coll_name(t)].delete_many({"bench": True})
    return rows


def print_table(rows, repeat):
    print(f"\n   Median time per operation in milliseconds (median of {repeat} runs)")
    print("   " + "-" * 96)
    print(f"   {'Operation':<50} | {'Document-level':>14} | {'Collection-per-tenant':>21} | Faster")
    print("   " + "-" * 96)
    for label, doc_ms, col_ms in rows:
        faster = "document-level" if doc_ms < col_ms else "collection-per-tenant"
        ratio = max(doc_ms, col_ms) / max(min(doc_ms, col_ms), 1e-9)
        print(f"   {label:<50} | {doc_ms:>14.3f} | {col_ms:>21.3f} | {faster} ({ratio:.1f}x)")
    print("   " + "-" * 96)


# --------------------------------------------------------------------------
# 5) Recommendation
# --------------------------------------------------------------------------
RECOMMENDATION = """
   DOCUMENT-LEVEL ISOLATION (one collection, tenant_id field) - recommended when:
     * Query isolation: queries filter on tenant_id (always the first field of the indexes), and
       the application must add that filter everywhere. Cheap, but one missing filter leaks data.
     * Cross-tenant queries are frequent (admin dashboards, usage analytics, billing): one
       aggregation over one collection.
     * There are many tenants (hundreds to thousands): every extra collection brings its own
       indexes and file handles, so thousands of collections cost memory and slow startup.
     * Schema evolution: one validator, one index change, one migration covers every tenant.
     * Backup granularity: whole database or collection only. Backing up or restoring one tenant
       means a filtered export (mongodump --query) and careful selective restore logic.

   COLLECTION-PER-TENANT ISOLATION (tasks_tenant_<id>) - recommended when:
     * Backup granularity: a tenant can be backed up, restored or deleted alone
       (mongodump --collection, db.collection.drop() when the customer leaves).
     * Regulation or contracts demand strict data separation; there is no shared collection,
       so a missing tenant_id filter cannot expose another tenant's rows.
     * Per-tenant tuning is needed: its own indexes, TTL rules or sharding for a very large tenant.
     * Costs: cross-tenant analytics needs $unionWith across all collections (or merging in the
       application), schema changes must be repeated for every collection, and the number of
       tenants is limited by how many collections the server can handle comfortably.

   RULE OF THUMB: start with document-level isolation, which is the simplest to build and to
   evolve. Migrate large or regulated tenants to collection-per-tenant (or database-per-tenant)
   only when a concrete requirement appears: independent restore, regulatory separation or
   per-tenant performance tuning.
"""


# --------------------------------------------------------------------------
def main():
    p = argparse.ArgumentParser(description="Lab 15.2 - migrate between tenant isolation strategies")
    p.add_argument("--uri", default=os.getenv("MONGO_URI", "mongodb://rsadmin:RsLabPass123@127.0.0.1:27047/?authSource=admin"))
    p.add_argument("--db", default="chapter-15")
    p.add_argument("--tenants", type=int, default=5)
    p.add_argument("--tasks", type=int, default=100, help="tasks per tenant")
    p.add_argument("--repeat", type=int, default=200, help="runs per benchmark operation")
    p.add_argument("--keep", action="store_true", help="do not drop the lab database at the end")
    args = p.parse_args()

    client = MongoClient(args.uri, serverSelectionTimeoutMS=8000)
    try:
        client.admin.command("ping")
    except Exception as exc:  # noqa: BLE001
        sys.exit(f"Could not connect to MongoDB: {exc}\nCheck --uri (or MONGO_URI in .env).")
    client.drop_database(args.db)
    db = client[args.db]
    tenants = tenant_ids(args.tenants)

    print(f"1) Seeding document-level isolation: {len(tenants)} tenants x {args.tasks} tasks "
          f"in '{args.db}.tasks' ...")
    total = seed(db, tenants, args.tasks)
    print(f"   inserted {total} documents; index (tenant_id, created_at) created")
    print("   example document:", {k: (str(v) if k == "created_at" else v)
                                   for k, v in db.tasks.find_one({"tenant_id": tenants[0]}).items()})

    print("\n2) Migrating to collection-per-tenant ({$match} + {$out}) ...")
    migrated = migrate(db, tenants)
    print(f"   migrated {migrated} documents into {len(tenants)} collections")

    print("\n3) Validating the migration ...")
    ck = validate(db, tenants, args.tasks)
    print(f"   RESULT: {ck.passed} passed, {ck.failed} failed")

    print(f"\n4) Benchmark ({args.repeat} runs per operation) ...")
    rows = benchmark(db, tenants, args.repeat)
    print_table(rows, args.repeat)
    print("   Note: with a few hundred documents both strategies answer in about a millisecond, so\n"
          "   differences are small and vary from run to run. Use --tasks 20000 to see the trend.")

    print("\n5) Recommendation")
    print(RECOMMENDATION)

    if not args.keep:
        client.drop_database(args.db)
        print(f"Database '{args.db}' dropped (use --keep to inspect it in Compass).")
    client.close()
    sys.exit(0 if ck.failed == 0 else 1)


if __name__ == "__main__":
    main()
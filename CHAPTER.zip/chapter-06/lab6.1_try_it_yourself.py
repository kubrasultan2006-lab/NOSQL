"""Activity for 6.1: Try it yourself
Use the $indexStats aggregation stage to measure actual index usage after
running the queries multiple times, and identify which indexes are used most.

Steps:
  1. Rebuild the 50,000-product collection and the five Lab 6.1 indexes, plus
     one extra index (idx_stock) that no query needs.
  2. Run the five Lab 6.1 queries many times, in random order, with random
     parameters (a realistic workload where some queries run more often).
  3. Read $indexStats and rank the indexes by how often they were used.

Prints boxed tables and ends with [OK] checks.

Install:  pip install pymongo
Run:      python chapter-06\\lab6.1_try_it_yourself.py
"""
import random

from pymongo import MongoClient

MONGO_URI = "mongodb://localhost:27017"  # or your Atlas connection string
NUM_PRODUCTS = 50_000

CATEGORIES = ["Electronics", "Books", "Home", "Toys", "Sports", "Garden", "Beauty", "Office"]
ADJECTIVES = [
    "Wireless", "Smart", "Compact", "Premium", "Ultra", "Eco", "Classic", "Portable",
    "Ergonomic", "Mini", "Deluxe", "Rugged", "Sleek", "Foldable", "Digital", "Vintage",
    "Modern", "Essential", "Turbo", "Silent",
]
NOUNS = [
    "Speaker", "Headphones", "Keyboard", "Mouse", "Monitor", "Lamp", "Charger", "Camera",
    "Router", "Drone", "Backpack", "Bottle", "Chair", "Desk", "Notebook", "Blender",
    "Kettle", "Watch", "Tripod", "Fan",
]
TAGS = [
    "new", "sale", "bestseller", "eco-friendly", "gift", "premium", "limited", "clearance",
    "trending", "bundle", "handmade", "imported", "refurbished", "popular", "seasonal",
    "exclusive", "budget", "portable", "durable", "warranty",
]

# (index name, keys, which query it serves)
INDEXES = [
    ("idx_category_price", [("category", 1), ("price", 1)], "Q1 category + sort by price"),
    ("idx_price", [("price", 1)], "Q2 price range"),
    ("idx_tags", [("tags", 1)], "Q3 find by tag"),
    ("idx_name_text", [("name", "text")], "Q4 text search on name"),
    ("idx_category_rating", [("category", 1), ("rating", -1)], "Q5 category + top rated"),
    ("idx_stock", [("stock", 1)], "no query uses it"),
]
KEY_LABELS = {
    "_id_": "_id: 1",
    "idx_name_text": "name: text",
    **{name: ", ".join(f"{f}: {d}" for f, d in keys) for name, keys, _ in INDEXES
       if name != "idx_name_text"},
}


# ---------------------------------------------------------------------------
# Helpers: boxed table printing, check lines
# ---------------------------------------------------------------------------
def print_table(headers, rows, aligns):
    """Print a boxed table. aligns: one of '<' (left) or '>' (right) per column."""
    cells = [[str(c) for c in row] for row in rows]
    widths = [
        max(len(headers[i]), *(len(r[i]) for r in cells)) for i in range(len(headers))
    ]

    def line(left, mid, right):
        return left + mid.join("─" * (w + 2) for w in widths) + right

    def fmt(row, use_aligns):
        return "│" + "│".join(
            f" {c:{a}{w}} " for c, a, w in zip(row, use_aligns, widths)
        ) + "│"

    print(line("┌", "┬", "┐"))
    print(fmt(headers, ["<"] * len(headers)))
    print(line("├", "┼", "┤"))
    for i, row in enumerate(cells):
        print(fmt(row, aligns))
        if i < len(cells) - 1:
            print(line("├", "┼", "┤"))
    print(line("└", "┴", "┘"))


def check(ok, message):
    print(f"  [OK] {message}" if ok else f"  [MISMATCH] {message}")


# ---------------------------------------------------------------------------
# Data generation (same as Lab 6.1)
# ---------------------------------------------------------------------------
def generate_products(n=NUM_PRODUCTS, seed=42):
    rng = random.Random(seed)
    return [
        {
            "name": f"{rng.choice(ADJECTIVES)} {rng.choice(NOUNS)} {rng.randint(100, 9999)}",
            "category": rng.choice(CATEGORIES),
            "price": round(rng.uniform(1, 1000), 2),
            "rating": round(rng.uniform(1, 5), 1),
            "stock": rng.randint(0, 500),
            "tags": rng.sample(TAGS, rng.randint(1, 3)),
        }
        for _ in range(n)
    ]


# ---------------------------------------------------------------------------
# The workload: each query runs a different number of times, with random
# parameters, so some indexes are used far more often than others.
# ---------------------------------------------------------------------------
def build_workload(products, rng):
    def q1():
        list(products.find({"category": rng.choice(CATEGORIES)}).sort("price", 1).limit(20))

    def q2():
        low = rng.uniform(1, 990)
        list(products.find({"price": {"$gte": low, "$lte": low + 5}}))

    def q3():
        list(products.find({"tags": rng.choice(TAGS)}).limit(50))

    def q4():
        list(products.find({"$text": {"$search": rng.choice(ADJECTIVES)}}).limit(20))

    def q5():
        list(
            products.find({"category": rng.choice(CATEGORIES), "rating": {"$gte": 4.5}})
            .sort("rating", -1)
            .limit(20)
        )

    # label, function, number of runs, index that should serve it
    return [
        ("Q1 category + sort by price", q1, 30, "idx_category_price"),
        ("Q2 price range", q2, 10, "idx_price"),
        ("Q3 find by tag", q3, 20, "idx_tags"),
        ("Q4 text search on name", q4, 5, "idx_name_text"),
        ("Q5 category + top rated", q5, 15, "idx_category_rating"),
    ]


def main():
    client = MongoClient(MONGO_URI)
    products = client["chapter-06"]["products"]
    rng = random.Random(7)

    # ----- Setup: collection + indexes ------------------------------------
    products.drop()  # also resets $indexStats counters, so every run starts at 0
    docs = generate_products()
    for start in range(0, len(docs), 10_000):
        products.insert_many(docs[start:start + 10_000])
    for name, keys, _ in INDEXES:
        products.create_index(keys, name=name)
    print(
        f"=== Setup: {products.count_documents({}):,} products, "
        f"{len(INDEXES)} indexes created (plus the default _id_ index) ==="
    )

    # ----- Run the workload -----------------------------------------------
    workload = build_workload(products, rng)
    calls = [(label, fn) for label, fn, runs, _ in workload for _ in range(runs)]
    rng.shuffle(calls)  # mix the queries, like real traffic
    for _, fn in calls:
        fn()

    print(f"\n=== Workload: {len(calls)} queries run in random order ===")
    print_table(
        ["Query", "Runs", "Expected index"],
        [(label, runs, index) for label, _, runs, index in workload],
        ["<", ">", "<"],
    )

    # ----- $indexStats ----------------------------------------------------
    stats = list(products.aggregate([{"$indexStats": {}}]))
    stats.sort(key=lambda s: (-s["accesses"]["ops"], s["name"]))
    total_ops = sum(s["accesses"]["ops"] for s in stats) or 1
    serves = {name: why for name, _, why in INDEXES}

    print("\n=== Activity 6.1: $indexStats, indexes ranked by usage ===")
    print_table(
        ["Rank", "Index", "Keys", "Times used", "Share", "Serves"],
        [
            (
                i,
                s["name"],
                KEY_LABELS.get(s["name"], str(dict(s["key"]))),
                f"{s['accesses']['ops']:,}",
                f"{100 * s['accesses']['ops'] / total_ops:.1f}%",
                serves.get(s["name"], "default index"),
            )
            for i, s in enumerate(stats, start=1)
        ],
        [">", "<", "<", ">", ">", "<"],
    )

    ops = {s["name"]: s["accesses"]["ops"] for s in stats}
    most_used = stats[0]["name"]
    print(f"\n  Most frequently used index: {most_used} ({ops[most_used]:,} times)")

    # ----- Checks ---------------------------------------------------------
    # $indexStats can count a few extra uses while MongoDB trial-runs competing
    # plans, so each index must be used AT LEAST as often as its query ran.
    check(
        all(ops.get(index, 0) >= runs for _, _, runs, index in workload),
        "each index was used at least as many times as its query ran",
    )
    expected_order = [
        index for _, _, runs, index in sorted(workload, key=lambda w: -w[2])
    ]
    actual_order = sorted(expected_order, key=lambda name: -ops.get(name, 0))
    check(
        actual_order == expected_order,
        "usage ranking matches how often each query was run",
    )
    check(
        ops.get("idx_stock", 0) == 0,
        "idx_stock was never used, so it only costs write speed and storage "
        "(candidate to drop)",
    )

    client.close()


if __name__ == "__main__":
    main()
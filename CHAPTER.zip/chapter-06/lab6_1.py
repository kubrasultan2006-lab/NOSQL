"""Activity for 6.2: Try it yourself
Covered queries: queries where every field the query filters on AND returns is
present in the index, so MongoDB answers from the index alone and never reads
the documents. explain() proves it: the FETCH stage disappears and
totalDocsExamined drops to 0.

Rules for a covered query:
  - all fields in the filter are in the index
  - all fields in the projection are in the index
  - _id is excluded from the projection (_id: 0), unless _id is in the index
  - none of the indexed fields is an array (multikey indexes cannot cover)

Prints boxed tables and ends with [OK] checks.

Install:  pip install pymongo
Run:      python chapter-06\\lab6.2_try_it_yourself.py
"""
import random

from pymongo import MongoClient

MONGO_URI = "mongodb://localhost:27017"  # or your Atlas connection string
NUM_PRODUCTS = 50_000

CATEGORIES = ["Electronics", "Books", "Home", "Toys", "Sports", "Garden", "Beauty", "Office"]
ADJECTIVES = [
    "Wireless", "Smart", "Compact", "Premium", "Ultra", "Eco", "Classic", "Portable",
    "Ergonomic", "Mini", "Deluxe", "Rugged", "Sleek", "Foldable", "Digital", "Vintage",
    "Modern", "Essential", "Turbo", "Silent",
]
NOUNS = [
    "Speaker", "Headphones", "Keyboard", "Mouse", "Monitor", "Lamp", "Charger", "Camera",
    "Router", "Drone", "Backpack", "Bottle", "Chair", "Desk", "Notebook", "Blender",
    "Kettle", "Watch", "Tripod", "Fan",
]
TAGS = [
    "new", "sale", "bestseller", "eco-friendly", "gift", "premium", "limited", "clearance",
    "trending", "bundle", "handmade", "imported", "refurbished", "popular", "seasonal",
    "exclusive", "budget", "portable", "durable", "warranty",
]

INDEX_NAME = "idx_category_price"
INDEX_KEYS = [("category", 1), ("price", 1)]

FILTER = {"category": "Books", "price": {"$lte": 100}}

# label, projection, sort, should it be covered?
VARIANTS = [
    ("A  full documents", None, None, False),
    ("B  adds name field", {"_id": 0, "category": 1, "price": 1, "name": 1}, None, False),
    ("C  _id not excluded", {"category": 1, "price": 1}, None, False),
    ("D  covered", {"_id": 0, "category": 1, "price": 1}, None, True),
    ("E  covered + sort", {"_id": 0, "category": 1, "price": 1}, {"price": 1}, True),
]


# ---------------------------------------------------------------------------
# Helpers: boxed table printing, check lines
# ---------------------------------------------------------------------------
def print_table(headers, rows, aligns):
    """Print a boxed table. aligns: one of '<' (left) or '>' (right) per column."""
    cells = [[str(c) for c in row] for row in rows]
    widths = [
        max(len(headers[i]), *(len(r[i]) for r in cells)) for i in range(len(headers))
    ]

    def line(left, mid, right):
        return left + mid.join("─" * (w + 2) for w in widths) + right

    def fmt(row, use_aligns):
        return "│" + "│".join(
            f" {c:{a}{w}} " for c, a, w in zip(row, use_aligns, widths)
        ) + "│"

    print(line("┌", "┬", "┐"))
    print(fmt(headers, ["<"] * len(headers)))
    print(line("├", "┼", "┤"))
    for i, row in enumerate(cells):
        print(fmt(row, aligns))
        if i < len(cells) - 1:
            print(line("├", "┼", "┤"))
    print(line("└", "┴", "┘"))


def check(ok, message):
    print(f"  [OK] {message}" if ok else f"  [MISMATCH] {message}")


def generate_products(n=NUM_PRODUCTS, seed=42):
    rng = random.Random(seed)
    return [
        {
            "name": f"{rng.choice(ADJECTIVES)} {rng.choice(NOUNS)} {rng.randint(100, 9999)}",
            "category": rng.choice(CATEGORIES),
            "price": round(rng.uniform(1, 1000), 2),
            "rating": round(rng.uniform(1, 5), 1),
            "stock": rng.randint(0, 500),
            "tags": rng.sample(TAGS, rng.randint(1, 3)),
        }
        for _ in range(n)
    ]


def plan_chain(winning_plan):
    """Return the winning plan's stages, leaf first, e.g. 'IXSCAN > FETCH'."""
    node = winning_plan.get("queryPlan", winning_plan)
    stages = []
    while node:
        stages.append(node.get("stage", "?"))
        inputs = node.get("inputStages")
        node = node.get("inputStage") or (inputs[0] if inputs else None)
    return " > ".join(reversed(stages))


def explain_variant(products, projection, sort):
    cmd = {"find": products.name, "filter": FILTER}
    if projection:
        cmd["projection"] = projection
    if sort:
        cmd["sort"] = sort
    result = products.database.command({"explain": cmd, "verbosity": "executionStats"})
    stats = result["executionStats"]
    return {
        "stage": plan_chain(result["queryPlanner"]["winningPlan"]),
        "docs_examined": stats["totalDocsExamined"],
        "keys_examined": stats["totalKeysExamined"],
        "returned": stats["nReturned"],
        "time_ms": stats["executionTimeMillis"],
    }


def proj_text(projection):
    if not projection:
        return "(all fields)"
    return ",".join(f"{k}:{v}" for k, v in projection.items())


def main():
    client = MongoClient(MONGO_URI)
    products = client["chapter-06"]["covered"]

    # ----- Setup ----------------------------------------------------------
    products.drop()
    docs = generate_products()
    for start in range(0, len(docs), 10_000):
        products.insert_many(docs[start:start + 10_000])
    products.create_index(INDEX_KEYS, name=INDEX_NAME)
    print(
        f"=== Setup: {products.count_documents({}):,} products, one index "
        f"{INDEX_NAME} on category: 1, price: 1 ==="
    )
    print(f"  Filter used by every variant: {FILTER}")

    # ----- explain() on each variant -------------------------------------
    print("\n=== Activity 6.2: explain() for covered vs non-covered queries ===")
    results = [explain_variant(products, proj, srt) for _, proj, srt, _ in VARIANTS]
    print_table(
        ["Variant", "Projection", "Stage", "Docs examined", "Returned"],
        [
            (label, proj_text(proj), r["stage"], f"{r['docs_examined']:,}",
             f"{r['returned']:,}")
            for (label, proj, _, _), r in zip(VARIANTS, results)
        ],
        ["<", "<", "<", ">", ">"],
    )

    # ----- Sample output of the covered query ----------------------------
    covered_proj = {"_id": 0, "category": 1, "price": 1}
    sample = list(
        products.find(FILTER, covered_proj).sort([("price", 1)]).limit(5)
    )
    print("\n=== Covered query result (5 cheapest, read from the index only) ===")
    print_table(
        ["Category", "Price"],
        [(d["category"], f"${d['price']:,.2f}") for d in sample],
        ["<", ">"],
    )

    # ----- Checks ---------------------------------------------------------
    covered = [r for (_, _, _, is_covered), r in zip(VARIANTS, results) if is_covered]
    not_covered = [r for (_, _, _, is_covered), r in zip(VARIANTS, results) if not is_covered]
    check(
        all("FETCH" not in r["stage"] and "IXSCAN" in r["stage"] for r in covered),
        "covered queries (D, E) have no FETCH stage and use only IXSCAN",
    )
    check(
        all(r["docs_examined"] == 0 for r in covered),
        "covered queries examined 0 documents (answered from the index alone)",
    )
    check(
        all("FETCH" in r["stage"] and r["docs_examined"] == r["returned"]
            for r in not_covered),
        "non-covered queries (A, B, C) still FETCH every returned document",
    )
    check(
        len({r["returned"] for r in results}) == 1,
        "all five variants return the same number of documents",
    )
    # Do the covered values equal the values from the full documents?
    full = products.find(FILTER, {"_id": 0, "category": 1, "price": 1})
    covered_rows = sorted((d["category"], d["price"]) for d in full)
    from_full_docs = sorted(
        (d["category"], d["price"]) for d in products.find(FILTER)
    )
    check(
        covered_rows == from_full_docs,
        "covered query returns the same category/price values as the full documents",
    )

    client.close()


if __name__ == "__main__":
    main()
"""Lab 6.2: Compare Index Strategies (MongoDB + pymongo)

1. No indexes (except _id): time inserting 10,000 documents.
2. Create 5 indexes, insert another 10,000 documents, time it, and
   calculate the percentage slowdown.
3. Drop all but the most critical index, re-run the five Lab 6.1 queries and
   compare performance.
4. Print a short analysis of the query-speed vs write-speed trade-off.

Prints boxed tables and ends with [OK] checks.

Install:  pip install pymongo
Run:      python chapter-06\\lab_02_index_strategies.py
"""
import random
import textwrap
import time

from pymongo import MongoClient
from pymongo.errors import OperationFailure

MONGO_URI = "mongodb://localhost:27017"  # or your Atlas connection string
BATCH_SIZE = 10_000       # documents per insert phase
QUERY_RUNS = 20           # times each query is run (random parameters) per measurement
MOST_CRITICAL = "idx_category_price"  # the index we keep in Task 3

CATEGORIES = ["Electronics", "Books", "Home", "Toys", "Sports", "Garden", "Beauty", "Office"]
ADJECTIVES = [
    "Wireless", "Smart", "Compact", "Premium", "Ultra", "Eco", "Classic", "Portable",
    "Ergonomic", "Mini", "Deluxe", "Rugged", "Sleek", "Foldable", "Digital", "Vintage",
    "Modern", "Essential", "Turbo", "Silent",
]
NOUNS = [
    "Speaker", "Headphones", "Keyboard", "Mouse", "Monitor", "Lamp", "Charger", "Camera",
    "Router", "Drone", "Backpack", "Bottle", "Chair", "Desk", "Notebook", "Blender",
    "Kettle", "Watch", "Tripod", "Fan",
]
TAGS = [
    "new", "sale", "bestseller", "eco-friendly", "gift", "premium", "limited", "clearance",
    "trending", "bundle", "handmade", "imported", "refurbished", "popular", "seasonal",
    "exclusive", "budget", "portable", "durable", "warranty",
]

# The five indexes from Lab 6.1: (name, keys, query served)
INDEXES = [
    ("idx_category_price", [("category", 1), ("price", 1)], "Q1"),
    ("idx_price", [("price", 1)], "Q2"),
    ("idx_tags", [("tags", 1)], "Q3"),
    ("idx_name_text", [("name", "text")], "Q4"),
    ("idx_category_rating", [("category", 1), ("rating", -1)], "Q5"),
]


# ---------------------------------------------------------------------------
# Helpers: boxed table printing, check lines
# ---------------------------------------------------------------------------
def print_table(headers, rows, aligns):
    """Print a boxed table. aligns: one of '<' (left) or '>' (right) per column."""
    cells = [[str(c) for c in row] for row in rows]
    widths = [
        max(len(headers[i]), *(len(r[i]) for r in cells)) for i in range(len(headers))
    ]

    def line(left, mid, right):
        return left + mid.join("─" * (w + 2) for w in widths) + right

    def fmt(row, use_aligns):
        return "│" + "│".join(
            f" {c:{a}{w}} " for c, a, w in zip(row, use_aligns, widths)
        ) + "│"

    print(line("┌", "┬", "┐"))
    print(fmt(headers, ["<"] * len(headers)))
    print(line("├", "┼", "┤"))
    for i, row in enumerate(cells):
        print(fmt(row, aligns))
        if i < len(cells) - 1:
            print(line("├", "┼", "┤"))
    print(line("└", "┴", "┘"))


def check(ok, message):
    print(f"  [OK] {message}" if ok else f"  [MISMATCH] {message}")


# ---------------------------------------------------------------------------
# Data generation (same fields as Lab 6.1; a different seed gives new documents)
# ---------------------------------------------------------------------------
def generate_products(n, seed):
    rng = random.Random(seed)
    return [
        {
            "name": f"{rng.choice(ADJECTIVES)} {rng.choice(NOUNS)} {rng.randint(100, 9999)}",
            "category": rng.choice(CATEGORIES),
            "price": round(rng.uniform(1, 1000), 2),
            "rating": round(rng.uniform(1, 5), 1),
            "stock": rng.randint(0, 500),
            "tags": rng.sample(TAGS, rng.randint(1, 3)),
        }
        for _ in range(n)
    ]


def timed_insert(products, seed, batch=1_000):
    """Insert BATCH_SIZE new documents; return elapsed seconds (generation not timed)."""
    docs = generate_products(BATCH_SIZE, seed)
    start = time.perf_counter()
    for i in range(0, len(docs), batch):
        products.insert_many(docs[i:i + batch])
    return time.perf_counter() - start


# ---------------------------------------------------------------------------
# The five representative queries (random parameters, fixed seed per query)
# ---------------------------------------------------------------------------
def q1(rng):
    return {"category": rng.choice(CATEGORIES)}, [("price", 1)], 20


def q2(rng):
    low = rng.uniform(1, 990)
    return {"price": {"$gte": low, "$lte": low + 5}}, None, None


def q3(rng):
    return {"tags": rng.choice(TAGS)}, None, 50


def q4(rng):
    return {"$text": {"$search": rng.choice(ADJECTIVES)}}, None, 20


def q5(rng):
    return {"category": rng.choice(CATEGORIES), "rating": {"$gte": 4.5}}, [("rating", -1)], 20


QUERIES = [
    ("Q1 category + sort by price", q1),
    ("Q2 price range", q2),
    ("Q3 find by tag", q3),
    ("Q4 text search on name", q4),
    ("Q5 category + top rated", q5),
]


def plan_chain(winning_plan):
    """Return the winning plan's stages, leaf first, e.g. 'IXSCAN > FETCH > LIMIT'."""
    node = winning_plan.get("queryPlan", winning_plan)
    stages = []
    while node:
        stages.append(node.get("stage", "?"))
        inputs = node.get("inputStages")
        node = node.get("inputStage") or (inputs[0] if inputs else None)
    return " > ".join(reversed(stages))


def measure_query(products, make, seed):
    """Return (average ms per run, plan of the first run), or (None, 'fails')."""
    rng = random.Random(seed)
    params = [make(rng) for _ in range(QUERY_RUNS)]  # identical params every call

    # plan of the first run
    flt, srt, lim = params[0]
    cmd = {"find": products.name, "filter": flt}
    if srt:
        cmd["sort"] = dict(srt)
    if lim:
        cmd["limit"] = lim
    try:
        explained = products.database.command({"explain": cmd, "verbosity": "queryPlanner"})
        plan = plan_chain(explained["queryPlanner"]["winningPlan"])

        start = time.perf_counter()
        for flt, srt, lim in params:
            cursor = products.find(flt)
            if srt:
                cursor = cursor.sort(srt)
            if lim:
                cursor = cursor.limit(lim)
            list(cursor)
        elapsed = time.perf_counter() - start
    except OperationFailure:
        return None, "fails (no text index)"
    return 1000 * elapsed / QUERY_RUNS, plan


def measure_all(products):
    return [measure_query(products, make, seed=i) for i, (_, make) in enumerate(QUERIES)]


def pct(new, old):
    return 100 * (new - old) / old


def main():
    client = MongoClient(MONGO_URI)
    products = client["chapter-06"]["strategies"]

    # ----- Task 1: inserts with no indexes (except _id) --------------------
    products.drop()
    t_none = timed_insert(products, seed=1)
    print(f"=== Task 1: Insert {BATCH_SIZE:,} documents with no indexes (except _id) ===")
    print_table(
        ["Indexes", "Documents", "Time (s)", "Docs/sec"],
        [("_id only", f"{BATCH_SIZE:,}", f"{t_none:.3f}", f"{BATCH_SIZE / t_none:,.0f}")],
        ["<", ">", ">", ">"],
    )

    # ----- Task 2: create 5 indexes, insert again, % slowdown --------------
    for name, keys, _ in INDEXES:
        products.create_index(keys, name=name)
    t_five = timed_insert(products, seed=2)
    slowdown = pct(t_five, t_none)
    print(f"\n=== Task 2: Insert {BATCH_SIZE:,} more documents with 5 indexes ===")
    print_table(
        ["Indexes", "Documents", "Time (s)", "Docs/sec", "Slowdown"],
        [
            ("_id only", f"{BATCH_SIZE:,}", f"{t_none:.3f}", f"{BATCH_SIZE / t_none:,.0f}", "baseline"),
            ("_id + 5 indexes", f"{BATCH_SIZE:,}", f"{t_five:.3f}",
             f"{BATCH_SIZE / t_five:,.0f}", f"{slowdown:+.1f}%"),
        ],
        ["<", ">", ">", ">", ">"],
    )
    check(
        products.count_documents({}) == 2 * BATCH_SIZE,
        f"collection holds {2 * BATCH_SIZE:,} documents after both insert phases",
    )
    check(slowdown > 0, "inserting with 5 indexes is slower than inserting with none")

    # ----- Task 3: drop all but the most critical index --------------------
    with_five = measure_all(products)
    for name, _, _ in INDEXES:
        if name != MOST_CRITICAL:
            products.drop_index(name)
    with_one = measure_all(products)

    print(f"\n=== Task 3: Queries with 5 indexes vs only {MOST_CRITICAL} "
          f"(avg of {QUERY_RUNS} runs) ===")
    rows, total_five, total_one = [], 0.0, 0.0
    for i, ((label, _), (t5, _), (t1, plan1)) in enumerate(
        zip(QUERIES, with_five, with_one), start=1
    ):
        if t1 is None:
            rows.append((i, label, f"{t5:.2f}", "-", "-", plan1))
            continue
        total_five += t5
        total_one += t1
        rows.append((i, label, f"{t5:.2f}", f"{t1:.2f}", f"{t1 / t5:.1f}x", plan1))
    rows.append(("", "Total (queries that still run)", f"{total_five:.2f}",
                 f"{total_one:.2f}", f"{total_one / total_five:.1f}x", ""))
    print_table(
        ["#", "Query", "5 indexes (ms)", "1 index (ms)", "Slower by", "Plan with 1 index"],
        rows,
        [">", "<", ">", ">", ">", "<"],
    )
    check(
        set(products.index_information()) == {"_id_", MOST_CRITICAL},
        f"only _id_ and {MOST_CRITICAL} remain",
    )
    plans = [p for _, p in with_one]
    check(
        "IXSCAN" in plans[0],
        "Q1 still uses the index we kept",
    )
    check(
        "COLLSCAN" in plans[1] and "COLLSCAN" in plans[2] and with_one[3][0] is None,
        "Q2 and Q3 now scan the whole collection and Q4 fails without its text index",
    )
    check(total_one > total_five, "the workload is slower overall with only one index")

    # Write cost with only the one index (extra data point for the analysis)
    t_one = timed_insert(products, seed=3)
    print(f"\n=== Write throughput summary ({BATCH_SIZE:,} documents per phase) ===")
    print_table(
        ["Indexes", "Time (s)", "Docs/sec", "vs no indexes"],
        [
            ("_id only", f"{t_none:.3f}", f"{BATCH_SIZE / t_none:,.0f}", "baseline"),
            ("_id + 5 indexes", f"{t_five:.3f}", f"{BATCH_SIZE / t_five:,.0f}",
             f"{pct(t_five, t_none):+.1f}%"),
            (f"_id + {MOST_CRITICAL}", f"{t_one:.3f}", f"{BATCH_SIZE / t_one:,.0f}",
             f"{pct(t_one, t_none):+.1f}%"),
        ],
        ["<", ">", ">", ">"],
    )

    # ----- Task 4: short analysis ------------------------------------------
    query_factor = total_one / total_five
    insert_phrase = (
        f"took {slowdown:.0f}% longer" if slowdown > 0
        else "showed no measurable slowdown (timing noise on this machine)"
    )
    analysis = (
        f"Every index is a second copy of part of the data that MongoDB must update on "
        f"every insert, update and delete. With five indexes, inserting {BATCH_SIZE:,} "
        f"documents {insert_phrase} compared with no secondary indexes, and the text "
        f"and multikey (tags) indexes are the most expensive to maintain because one "
        f"document produces many index entries. Indexes also use disk space and RAM. "
        f"In return, they turn full collection scans into short index lookups: after "
        f"dropping four of the five indexes, the queries that still ran were "
        f"{query_factor:.1f}x slower overall, Q2 and Q3 fell back to collection scans, "
        f"and the text search stopped working altogether. The trade-off is therefore "
        f"read speed against write throughput and storage. A read-heavy workload "
        f"(product catalogue, search) justifies many indexes. A write-heavy workload "
        f"(logging, sensor data) should keep only the indexes that the most important "
        f"queries need, and use $indexStats (Activity 6.1) to drop indexes that are "
        f"never used."
    )
    print("\n=== Task 4: Analysis, query performance vs write throughput ===")
    print(textwrap.fill(analysis, width=96, initial_indent="  ", subsequent_indent="  "))

    client.close()


if __name__ == "__main__":
    main()
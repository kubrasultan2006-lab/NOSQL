"""
Activity for 17.1 - Try it yourself: add conversation memory to the RAG pipeline

Pipeline:
  1. chunk 4 short Threat Intelligence documents into 100-word segments (sliding window)
  2. embed every chunk and store it in MongoDB: {text, source, embedding}
  3. retrieve(query): embed the query, run $vectorSearch (numCandidates=20, limit=3)
  4. generate(query): build a prompt from the 3 chunks (+ last 5 exchanges) and call Ollama
  5. conversations collection: {user_id, timestamp, role, content} gives multi-turn memory

Two modes:
  online  (default)  MongoDB Atlas + $vectorSearch index, Ollama embeddings (nomic-embed-text),
                     Ollama LLM (llama3.2). Needs MONGO_URI and local Ollama running.
  --offline          no network: in-memory collections, hashed bag-of-words embeddings (768 dims),
                     cosine search and a template "LLM".

Run:
    python "chapter-17\\Activity for 17.1 - Try it yourself.py" --offline
    python "chapter-17\\Activity for 17.1 - Try it yourself.py"            (Atlas + Ollama)

Requires: pip install pymongo python-dotenv numpy
"""

import argparse
import hashlib
import json
import os
import re
import sys
import urllib.request
from datetime import datetime, timezone

import numpy as np

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

CHUNK_WORDS = 100
OVERLAP_WORDS = 20
TOP_K = 3
NUM_CANDIDATES = 20
HISTORY_EXCHANGES = 5          # Activity 17.1: last 5 exchanges = 10 messages
USER_ID = "kubra"
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://127.0.0.1:11434")
OLLAMA_EMBED_MODEL = os.getenv("OLLAMA_EMBED_MODEL", "nomic-embed-text")
OLLAMA_LLM_MODEL = os.getenv("OLLAMA_LLM_MODEL", "llama3.2")

# --------------------------------------------------------------------------------------------------
# 1. Source documents (Threat Intelligence)
# --------------------------------------------------------------------------------------------------
DOCUMENTS = {
    "threat_intel_basics": (
        "Cyber threat intelligence is evidence-based knowledge about existing or emerging threats to an "
        "organisation's assets. It describes who the attackers are, what they want, which tools and "
        "techniques they use and how defenders can detect or stop them. Intelligence is usually split into "
        "strategic, operational, tactical and technical levels. Strategic intelligence helps executives "
        "decide where to invest, operational intelligence describes campaigns and attacker intent, tactical "
        "intelligence covers tactics, techniques and procedures, and technical intelligence supplies "
        "indicators of compromise such as file hashes, malicious IP addresses and domain names. Good "
        "intelligence is timely, accurate, relevant and actionable, otherwise analysts drown in data that "
        "never changes a decision. Analysts therefore start from priority intelligence requirements: the "
        "questions leadership needs answered, such as which groups target our sector or which "
        "vulnerabilities are being exploited this month. Collection from open sources, vendor feeds and "
        "internal logs is followed by processing, analysis and dissemination, and feedback from the readers "
        "closes the cycle so the next round of collection is better focused. Sharing indicators with "
        "industry groups and national CERTs multiplies the value of every report."
    ),
    "phishing": (
        "Phishing is the most common initial access technique seen in real incidents. The attacker sends an "
        "email, SMS or chat message that imitates a trusted sender and pushes the victim to open a malicious "
        "attachment, follow a link to a fake login page or approve a payment. Spear phishing targets a "
        "specific person using details found on social media. Typical warning signs are urgent language, "
        "mismatched sender domains, unexpected attachments and links whose real address differs from the "
        "displayed text. Defences include email filtering, DMARC, SPF and DKIM records, multi-factor "
        "authentication, regular awareness training and an easy way for staff to report suspicious messages "
        "to the security team. Reported messages should be analysed quickly: the analyst extracts the "
        "sender, links and attachment hashes, checks them against threat feeds and blocks the malicious "
        "domains for everyone. Phishing kits are often reused, so one confirmed campaign gives indicators "
        "that protect the whole organisation. Simulated phishing exercises measure how many staff click, "
        "and the results show which teams need more training. Credential harvesting pages increasingly "
        "proxy the real login to steal session cookies, which is why phishing-resistant authentication such "
        "as hardware security keys is recommended for administrators."
    ),
    "ransomware": (
        "Ransomware is malware that encrypts a victim's files and demands payment for the decryption key. "
        "Modern groups use double extortion: they first steal sensitive data and then threaten to publish it "
        "if the ransom is not paid. Common entry points are phishing emails, exposed remote desktop services "
        "and unpatched VPN appliances. After gaining access the attackers move laterally, disable backups and "
        "deploy the encryptor to many machines at once. Effective defences are offline and immutable backups, "
        "timely patching, network segmentation, endpoint detection and response, least privilege access and a "
        "rehearsed incident response plan that decides in advance who talks to law enforcement and customers. "
        "Paying the ransom is discouraged by most authorities because it funds further attacks and does not "
        "guarantee that data is restored. Recovery starts with isolating infected machines, identifying the "
        "ransomware family from the ransom note and file extension, and restoring from clean backups after "
        "the intruders have been removed. Intelligence about the group, for example its usual dwell time and "
        "the tools it deploys before encryption, helps defenders hunt for earlier warning signs such as "
        "unusual use of remote administration tools and mass deletion of shadow copies."
    ),
    "mitre_attack": (
        "MITRE ATT&CK is a public knowledge base of adversary tactics and techniques observed in the real "
        "world. Tactics describe the attacker's goal, such as initial access, persistence, privilege "
        "escalation, lateral movement or exfiltration, and techniques describe how the goal is reached. "
        "Threat intelligence teams map reports and detections to ATT&CK so that coverage gaps become visible "
        "and different tools speak the same language. Defenders use it for threat hunting, red team planning "
        "and measuring how many techniques of a given threat group their monitoring can actually detect. The "
        "matrix is updated regularly as new behaviour is observed. Each technique page lists example "
        "procedures used by named groups, mitigations and data sources for detection, which makes it easy to "
        "turn a report into concrete detection rules. Analysts often colour the matrix to compare the "
        "techniques a group uses against the techniques their own tools cover, producing a heat map that "
        "guides engineering work. ATT&CK has separate matrices for enterprise networks, mobile devices and "
        "industrial control systems, and the navigator tool lets teams layer several groups on one view."
    ),
}


def chunk_words(text, size=CHUNK_WORDS, overlap=OVERLAP_WORDS):
    """Sliding window over words: `size` words per chunk, consecutive chunks share `overlap` words."""
    words = text.split()
    step = size - overlap
    chunks = []
    for start in range(0, len(words), step):
        piece = words[start:start + size]
        if len(piece) >= overlap * 2 or not chunks:
            chunks.append(" ".join(piece))
        if start + size >= len(words):
            break
    return chunks


# --------------------------------------------------------------------------------------------------
# 2. Embeddings & Ollama HTTP helper
# --------------------------------------------------------------------------------------------------
def _ollama_post(endpoint, payload):
    req = urllib.request.Request(
        f"{OLLAMA_URL}{endpoint}",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception as exc:
        sys.exit(f"Could not reach Ollama at {OLLAMA_URL}{endpoint}: {exc}\n"
                 f"Make sure Ollama is running and models '{OLLAMA_EMBED_MODEL}' & '{OLLAMA_LLM_MODEL}' are pulled.")


class HashEmbedder:
    """Offline stand-in for an embedding API: IDF-weighted hashed bag of words, L2-normalised (768 dims)."""
    dims = 768
    idf = {}

    def fit(self, texts):
        df = {}
        for t in texts:
            for w in set(self._tokens(t)):
                df[w] = df.get(w, 0) + 1
        self.idf = {w: np.log((len(texts) + 1) / (c + 1)) + 1 for w, c in df.items()}

    def _tokens(self, t):
        out = []
        for w in re.findall(r"[a-z0-9]+", t.lower()):
            if w in self.STOP:
                continue
            out.append(w[:-1] if w.endswith("s") and len(w) > 3 else w)
        return out

    STOP = {"the", "a", "an", "and", "of", "to", "in", "is", "are", "it", "that", "for", "or", "as",
            "on", "by", "with", "how", "what", "can", "do", "does", "i", "we", "you", "they", "their",
            "this", "these", "from", "at", "be", "so", "if", "then", "which", "who", "most", "into", "get",
            "did", "has", "have", "was", "were", "not", "but", "about", "there", "work", "against"}

    def embed(self, texts):
        out = []
        for t in texts:
            v = np.zeros(self.dims)
            for w in self._tokens(t):
                v[int(hashlib.md5(w.encode()).hexdigest(), 16) % self.dims] += self.idf.get(w, 1.0)
            n = np.linalg.norm(v)
            out.append((v / n if n else v).tolist())
        return out


class OllamaEmbedder:
    dims = 768  # nomic-embed-text returns 768-dimensional vectors

    def embed(self, texts):
        data = _ollama_post("/api/embed", {"model": OLLAMA_EMBED_MODEL, "input": texts})
        return data["embeddings"]


def cosine_sim(a, b):
    a, b = np.asarray(a), np.asarray(b)
    return float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b)))


# --------------------------------------------------------------------------------------------------
# 3. Offline collection (tiny subset of the pymongo API used below)
# --------------------------------------------------------------------------------------------------
class MemCursor(list):
    def sort(self, key, direction=1):
        return MemCursor(sorted(self, key=lambda d: d[key], reverse=direction < 0))

    def limit(self, n):
        return MemCursor(self[:n])


class MemCollection:
    def __init__(self):
        self.docs = []

    def insert_many(self, docs):
        self.docs.extend(dict(d) for d in docs)

    def insert_one(self, doc):
        self.docs.append(dict(doc))

    def delete_many(self, _filter):
        self.docs = []

    def count_documents(self, flt):
        return len(self.find(flt))

    def find(self, flt=None, projection=None):
        flt = flt or {}
        return MemCursor(d for d in self.docs if all(d.get(k) == v for k, v in flt.items()))

    def vector_search(self, query_vector, k, num_candidates):
        scored = [{"text": d["text"], "source": d["source"], "score": (cosine_sim(query_vector, d["embedding"]) + 1) / 2}
                  for d in self.docs]
        scored.sort(key=lambda r: r["score"], reverse=True)
        return scored[:k]


# --------------------------------------------------------------------------------------------------
# 4. Pipeline
# --------------------------------------------------------------------------------------------------
INDEX_DEFINITION = """   Atlas Vector Search index "vector_index" on chapter-17.chunks:
   {"fields": [{"type": "vector", "path": "embedding", "numDimensions": %d, "similarity": "cosine"}]}"""


class RagPipeline:
    def __init__(self, chunks, conversations, embedder, llm, offline):
        self.chunks, self.conversations = chunks, conversations
        self.embedder, self.llm, self.offline = embedder, llm, offline

    def ingest(self, documents):
        self.chunks.delete_many({})
        if hasattr(self.embedder, "fit"):
            self.embedder.fit([p for t in documents.values() for p in chunk_words(t)])
        rows = []
        for source, text in documents.items():
            pieces = chunk_words(text)
            vectors = self.embedder.embed(pieces)
            rows += [{"text": p, "source": source, "embedding": v} for p, v in zip(pieces, vectors)]
        self.chunks.insert_many(rows)
        return len(rows)

    def retrieve(self, query, k=TOP_K):
        qvec = self.embedder.embed([query])[0]
        if self.offline:
            return self.chunks.vector_search(qvec, k, NUM_CANDIDATES)
        pipeline = [
            {"$vectorSearch": {"index": "vector_index", "path": "embedding", "queryVector": qvec,
                               "numCandidates": NUM_CANDIDATES, "limit": k}},
            {"$project": {"text": 1, "source": 1, "score": {"$meta": "vectorSearchScore"}, "_id": 0}},
        ]
        return list(self.chunks.aggregate(pipeline))

    def history(self, user_id, exchanges=HISTORY_EXCHANGES):
        msgs = self.conversations.find({"user_id": user_id}).sort("timestamp", -1).limit(exchanges * 2)
        return list(reversed(list(msgs)))

    def remember(self, user_id, role, content):
        self.conversations.insert_one({"user_id": user_id, "timestamp": datetime.now(timezone.utc),
                                       "role": role, "content": content})

    def build_prompt(self, query, hits, past):
        context = "\n\n".join(f"[{i}] ({h['source']}) {h['text']}" for i, h in enumerate(hits, 1))
        convo = "\n".join(f"{m['role']}: {m['content']}" for m in past)
        prompt = f"Answer based on these documents:\n{context}\n\n"
        if convo:
            prompt += f"Previous conversation:\n{convo}\n\n"
        return prompt + f"Question: {query}"

    def ask(self, user_id, query):
        past = self.history(user_id)
        last_user = next((m["content"] for m in reversed(past) if m["role"] == "user"), "")
        hits = self.retrieve((last_user + " " + query + " " + query).strip())
        prompt = self.build_prompt(query, hits, past)
        answer = self.llm(prompt, hits, past, query)
        self.remember(user_id, "user", query)
        self.remember(user_id, "assistant", answer)
        return hits, past, prompt, answer


def offline_llm(prompt, hits, past, query):
    last_user = next((m["content"] for m in reversed(past) if m["role"] == "user"), "")
    emb = HashEmbedder()
    cur, prev = set(emb._tokens(query)), set(emb._tokens(last_user))
    best, src = max(((s, h["source"]) for h in hits for s in re.split(r"(?<=[.])\s+", h["text"])
                     if s[:1].isupper()),
                    key=lambda x: 2 * len(cur & set(emb._tokens(x[0]))) + len(prev & set(emb._tokens(x[0]))))
    return f"{best}"


def ollama_llm(prompt, hits, past, query):
    data = _ollama_post("/api/generate", {
        "model": OLLAMA_LLM_MODEL,
        "prompt": prompt,
        "stream": False,
        "options": {"num_predict": 400},
    })
    return data["response"].strip()


class Checker:
    def __init__(self):
        self.passed = self.failed = 0

    def check(self, label, ok, detail=""):
        print(f"   [{'PASS' if ok else 'FAIL'}] {label}" + (f" -> {detail}" if detail else ""))
        self.passed += bool(ok)
        self.failed += not ok


def main():
    ap = argparse.ArgumentParser(description="Activity 17.1 - RAG pipeline with conversation memory")
    ap.add_argument("--offline", action="store_true", help="in-memory collections, hashed embeddings, template LLM")
    ap.add_argument("--uri", default=os.getenv("MONGO_URI"))
    ap.add_argument("--db", default="chapter-17")
    args = ap.parse_args()
    ck = Checker()

    if args.offline:
        pipe = RagPipeline(MemCollection(), MemCollection(), HashEmbedder(), offline_llm, offline=True)
        dims, mode = HashEmbedder.dims, "OFFLINE (in-memory store, hashed embeddings, template LLM)"
        client = None
    else:
        from pymongo import MongoClient
        if not args.uri:
            sys.exit("Set MONGO_URI (Atlas connection string) or pass --uri.")
        client = MongoClient(args.uri, serverSelectionTimeoutMS=8000)
        db = client[args.db]
        db.conversations.delete_many({"user_id": USER_ID})
        pipe = RagPipeline(db["chunks"], db["conversations"], OllamaEmbedder(), ollama_llm, offline=False)
        dims, mode = OllamaEmbedder.dims, f"ONLINE (MongoDB Atlas $vectorSearch, Ollama {OLLAMA_EMBED_MODEL} + {OLLAMA_LLM_MODEL})"

    print(f"Mode: {mode}")

    print("\n1) Chunking: 100-word sliding window, 20-word overlap")
    for source, text in DOCUMENTS.items():
        pieces = chunk_words(text)
        print(f"   {source:<20} {len(text.split()):>3} words -> {len(pieces)} chunks "
              f"({', '.join(str(len(p.split())) for p in pieces)} words)")
    ck.check("every chunk has at most 100 words",
             all(len(p.split()) <= CHUNK_WORDS for t in DOCUMENTS.values() for p in chunk_words(t)))
    first = chunk_words(DOCUMENTS["phishing"])
    ck.check("consecutive chunks overlap by 20 words", first[0].split()[-OVERLAP_WORDS:] == first[1].split()[:OVERLAP_WORDS])

    print("\n2) Embed and store")
    n = pipe.ingest(DOCUMENTS)
    print(INDEX_DEFINITION % dims)
    ck.check("chunks stored with text, source and embedding", n >= 8, f"{n} chunk documents, {dims}-dim vectors")

    print("\n3) Retrieval: top 3 chunks (numCandidates=20, limit=3)")
    tests = [("What entry points does ransomware use?", "ransomware"),
             ("What are the signs of a phishing email?", "phishing"),
             ("What is MITRE ATT&CK used for?", "mitre_attack")]
    for q, expected in tests:
        hits = pipe.retrieve(q)
        print(f"   Q: {q}")
        for h in hits:
            print(f"      Score: {h['score']:.4f} - [{h['source']}] {h['text'][:80]}")
        ck.check(f"top result comes from the '{expected}' document", hits[0]["source"] == expected, hits[0]["source"])
        ck.check("exactly 3 chunks returned, best score first",
                 len(hits) == 3 and hits[0]["score"] >= hits[1]["score"] >= hits[2]["score"])

    print("\n4) Prompt construction and generation (single turn)")
    pipe.conversations.delete_many({"user_id": USER_ID}) if args.offline else None
    hits, past, prompt, answer = pipe.ask(USER_ID, "What entry points does ransomware use?")
    print("   Prompt sent to the LLM (first 400 characters):")
    print("   " + prompt[:400].replace("\n", "\n   ") + " ...")
    print(f"   Answer: {answer}")
    ck.check("prompt contains the 3 retrieved chunks and the question",
             prompt.count("] (") == 3 and prompt.rstrip().endswith("Question: What entry points does ransomware use?"))
    ck.check("first turn has no earlier messages", len(past) == 0)

    print("\n5) Activity 17.1: conversation memory (multi-turn)")
    followups = ["What defences work against it?", "Which attacker tactics does ATT&CK list?",
                 "What can staff do about phishing emails?"]
    for q in followups:
        hits, past, prompt, answer = pipe.ask(USER_ID, q)
        print(f"   User: {q}\n   Assistant: {answer}")
    stored = list(pipe.conversations.find({"user_id": USER_ID}))
    ck.check("every query and every answer is stored in 'conversations'", len(stored) == 8, f"{len(stored)} messages for 4 exchanges")
    ck.check("stored messages have user_id, timestamp, role and content",
             all({"user_id", "timestamp", "role", "content"} <= set(m) for m in stored))
    ck.check("roles alternate user/assistant", [m["role"] for m in stored] == ["user", "assistant"] * 4)
    ck.check("3rd follow-up prompt carries the earlier exchanges", "Previous conversation:" in prompt and
             "What entry points does ransomware use?" in prompt, f"{len(past)} earlier messages")

    print("\n6) Memory window: only the last 5 exchanges are sent")
    for i in range(4):
        pipe.remember(USER_ID, "user", f"filler question {i}")
        pipe.remember(USER_ID, "assistant", f"filler answer {i}")
    window = pipe.history(USER_ID)
    ck.check("history returns 10 messages (5 exchanges), oldest first", len(window) == 10
             and window[0]["timestamp"] <= window[-1]["timestamp"], f"{len(window)} messages")
    ck.check("the very first question has dropped out of the window",
             all(m["content"] != "What entry points does ransomware use?" for m in window))

    print(f"\n   RESULT: {ck.passed} passed, {ck.failed} failed")
    if client:
        client.close()
    sys.exit(0 if ck.failed == 0 else 1)


if __name__ == "__main__":
    main()
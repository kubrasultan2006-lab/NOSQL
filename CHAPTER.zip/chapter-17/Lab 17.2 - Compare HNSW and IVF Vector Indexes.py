"""
Lab 17.2: Compare HNSW and IVF vector index types

  * 5,000 documents with 384-dimensional embeddings, inserted in batches of 500
  * HNSW index : {type:'hnsw', M:16, efConstruction:64}
  * IVF index  : {type:'ivf', nlist:100}
  * 100 queries (random document embeddings as query vectors), top-20 results
  * latency  = time.perf_counter() per query
  * recall   = |index_top20 intersect brute_force_top20| / 20  (brute force = exact cosine over all docs)
  * build time, comparison table, latency-recall trade-off curve, recommendations

Two modes:
  online  (default)  MongoDB Atlas: creates the two Vector Search indexes, embeds random sentences with
                     sentence-transformers (all-MiniLM-L6-v2, 384 dims) and queries with $vectorSearch.
                     needs MONGO_URI   (pip install pymongo sentence-transformers numpy matplotlib)
  --offline          no network: the same experiment on in-memory indexes written in numpy
                     (a small HNSW graph and an IVF index with k-means), synthetic clustered embeddings.
                     Recall and build behaviour are real for these implementations; absolute latencies
                     are Python/numpy numbers, NOT Atlas numbers.

Run:
    python "chapter-17\\Lab 17.2 - Compare HNSW and IVF Vector Indexes.py" --offline

Requires: pip install numpy matplotlib      (offline)
"""

import argparse
import heapq
import math
import os
import random
import sys
import time

import numpy as np

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

DIMS = 384
TOP_K = 20
BATCH = 500
NUM_CANDIDATES = 100            # search width used for HNSW queries (ef_search / numCandidates)


# --------------------------------------------------------------------------------------------------
# Data
# --------------------------------------------------------------------------------------------------
def synthetic_embeddings(n, dims, seed):
    """Clustered unit vectors (400 topics + noise): behaves like sentence embeddings of mixed topics."""
    rng = np.random.default_rng(seed)
    centres = rng.normal(size=(400, dims))
    ids = rng.integers(0, 400, size=n)
    x = centres[ids] + 1.0 * rng.normal(size=(n, dims))
    return (x / np.linalg.norm(x, axis=1, keepdims=True)).astype(np.float32)


def brute_force_top(matrix, q, k=TOP_K):
    sims = matrix @ q
    top = np.argpartition(-sims, k)[:k]
    return set(top.tolist())


# --------------------------------------------------------------------------------------------------
# Offline index 1: HNSW (hierarchical navigable small world graph)
# --------------------------------------------------------------------------------------------------
class HNSW:
    def __init__(self, vectors, M=16, ef_construction=64, seed=7):
        self.v, self.M, self.efc = vectors, M, ef_construction
        self.mmax0 = 2 * M
        self.ml = 1.0 / math.log(M)
        self.rng = random.Random(seed)
        self.layers = []                 # layers[l] = {node: [neighbours]}
        self.entry, self.top = None, -1
        for i in range(len(vectors)):
            self._insert(i)

    def _dist(self, q, ids):
        return 1.0 - self.v[ids] @ q

    def _search_layer(self, q, entries, ef, layer):
        graph = self.layers[layer]
        visited = set(entries)
        d0 = self._dist(q, list(entries))
        cand = [(float(d), e) for d, e in zip(d0, entries)]
        heapq.heapify(cand)
        best = [(-d, e) for d, e in cand]
        heapq.heapify(best)
        while cand:
            d, c = heapq.heappop(cand)
            if d > -best[0][0] and len(best) >= ef:
                break
            nbrs = [n for n in graph.get(c, ()) if n not in visited]
            if not nbrs:
                continue
            visited.update(nbrs)
            for dn, n in zip(self._dist(q, nbrs), nbrs):
                dn = float(dn)
                if len(best) < ef or dn < -best[0][0]:
                    heapq.heappush(cand, (dn, n))
                    heapq.heappush(best, (-dn, n))
                    if len(best) > ef:
                        heapq.heappop(best)
        return sorted((-nd, n) for nd, n in best)             # (distance, node), closest first

    def _insert(self, i):
        level = int(-math.log(1.0 - self.rng.random()) * self.ml)
        while len(self.layers) <= level:
            self.layers.append({})
        if self.entry is None:
            for l in range(level + 1):
                self.layers[l][i] = []
            self.entry, self.top = i, level
            return
        q, ep = self.v[i], [self.entry]
        for l in range(self.top, level, -1):                  # greedy descent through upper layers
            ep = [self._search_layer(q, ep, 1, l)[0][1]]
        for l in range(min(level, self.top), -1, -1):
            found = self._search_layer(q, ep, self.efc, l)
            neigh = [n for _, n in found[:self.M]]
            self.layers[l][i] = list(neigh)
            cap = self.mmax0 if l == 0 else self.M
            for n in neigh:
                lst = self.layers[l][n]
                lst.append(i)
                if len(lst) > cap:                            # keep the closest `cap` neighbours
                    d = self._dist(self.v[n], lst)
                    self.layers[l][n] = [lst[j] for j in np.argsort(d)[:cap]]
            ep = [n for _, n in found]
        for l in range(self.top + 1, level + 1):
            self.layers[l].setdefault(i, [])
        if level > self.top:
            self.entry, self.top = i, level

    def search(self, q, k=TOP_K, ef=NUM_CANDIDATES):
        ep = [self.entry]
        for l in range(self.top, 0, -1):
            ep = [self._search_layer(q, ep, 1, l)[0][1]]
        found = self._search_layer(q, ep, max(ef, k), 0)
        return [n for _, n in found[:k]]


# --------------------------------------------------------------------------------------------------
# Offline index 2: IVF (inverted file: k-means lists, probe the nearest `nprobe` lists)
# --------------------------------------------------------------------------------------------------
class IVF:
    def __init__(self, vectors, nlist=100, iters=8, seed=7):
        self.v, self.nlist = vectors, nlist
        rng = np.random.default_rng(seed)
        self.centroids = vectors[rng.choice(len(vectors), nlist, replace=False)].copy()
        for _ in range(iters):                                # k-means on unit vectors (cosine)
            assign = np.argmax(vectors @ self.centroids.T, axis=1)
            for c in range(nlist):
                members = vectors[assign == c]
                if len(members):
                    m = members.mean(axis=0)
                    self.centroids[c] = m / np.linalg.norm(m)
        assign = np.argmax(vectors @ self.centroids.T, axis=1)
        self.lists = [np.where(assign == c)[0] for c in range(nlist)]

    def search(self, q, k=TOP_K, nprobe=10):
        probe = np.argpartition(-(self.centroids @ q), min(nprobe, self.nlist) - 1)[:nprobe]
        ids = np.concatenate([self.lists[c] for c in probe])
        sims = self.v[ids] @ q
        return ids[np.argsort(-sims)[:k]].tolist()


# --------------------------------------------------------------------------------------------------
# Measurement helpers
# --------------------------------------------------------------------------------------------------
def measure(search_fn, queries, truth):
    lat, rec = [], []
    for qi, q in enumerate(queries):
        t0 = time.perf_counter()
        res = search_fn(q)
        lat.append((time.perf_counter() - t0) * 1000)
        rec.append(len(set(res) & truth[qi]) / TOP_K)
    return float(np.mean(lat)), float(np.mean(rec)) * 100


class Checker:
    def __init__(self):
        self.passed = self.failed = 0

    def check(self, label, ok, detail=""):
        print(f"   [{'PASS' if ok else 'FAIL'}] {label}" + (f" -> {detail}" if detail else ""))
        self.passed += bool(ok)
        self.failed += not ok


def ascii_curve(points, width=50):
    """points: list of (label, latency_ms, recall_pct). One line per point, bar length = recall."""
    for label, lat, rec in points:
        bar = "#" * int(round(rec / 100 * width))
        print(f"   {label:<22} {lat:>8.3f} ms |{bar:<{width}}| {rec:5.1f}%")


# --------------------------------------------------------------------------------------------------
# Online mode (MongoDB Atlas)
# --------------------------------------------------------------------------------------------------
def atlas_index_definition(kind, **opt):
    return {"type": "vectorSearch", "definition": {"fields": [
        {"type": "vector", "path": "embedding", "numDimensions": DIMS, "similarity": "cosine",
         "indexOptions": dict({"type": kind}, **opt)}]}}


def run_online(args, ck):
    from pymongo import MongoClient
    from pymongo.operations import SearchIndexModel
    from sentence_transformers import SentenceTransformer

    client = MongoClient(args.uri or os.getenv("MONGO_URI"), serverSelectionTimeoutMS=8000)
    coll = client["vector_lab"]["docs"]
    words = ("river mountain history music science king ocean planet language empire engine forest "
             "painter market theory island bridge desert protein galaxy treaty harvest festival").split()
    rnd = random.Random(args.seed)
    sentences = [" ".join(rnd.choices(words, k=rnd.randint(8, 16))) + "." for _ in range(args.docs)]
    emb = SentenceTransformer("all-MiniLM-L6-v2").encode(sentences, normalize_embeddings=True)
    coll.delete_many({})
    for s in range(0, args.docs, BATCH):
        coll.insert_many([{"text": sentences[i], "embedding": emb[i].tolist()}
                          for i in range(s, min(s + BATCH, args.docs))])
    queries = emb[np.random.default_rng(args.seed).choice(args.docs, args.queries, replace=False)]
    truth = [brute_force_top(emb, q) for q in queries]
    text_of = {s: i for i, s in enumerate(sentences)}

    def build(name, definition):
        for ix in coll.list_search_indexes():
            if ix["name"] == name:
                coll.drop_search_index(name)
                time.sleep(5)
        t0 = time.perf_counter()
        coll.create_search_index(SearchIndexModel(definition=definition["definition"], name=name,
                                                  type="vectorSearch"))
        while not any(ix["name"] == name and ix.get("queryable") for ix in coll.list_search_indexes()):
            time.sleep(2)
        return time.perf_counter() - t0

    def run(name, candidates):
        def fn(q):
            pipe = [{"$vectorSearch": {"index": name, "path": "embedding", "queryVector": q.tolist(),
                                       "numCandidates": candidates, "limit": TOP_K}},
                    {"$project": {"text": 1, "_id": 0}}]
            return [text_of[d["text"]] for d in coll.aggregate(pipe) if d["text"] in text_of]
        return measure(fn, queries, truth)

    rows, curve = [], []
    t = build("hnsw_idx", atlas_index_definition("hnsw", M=16, efConstruction=64))
    lat, rec = run("hnsw_idx", NUM_CANDIDATES)
    rows.append(("HNSW", "M=16, efConstruction=64", t, lat, rec))
    t = build("ivf_idx", atlas_index_definition("ivf", nlist=100))
    lat, rec = run("ivf_idx", NUM_CANDIDATES)
    rows.append(("IVF", "nlist=100", t, lat, rec))
    for efc in (32, 64, 128, 256):
        build(f"hnsw_efc{efc}", atlas_index_definition("hnsw", M=16, efConstruction=efc))
        lat, rec = run(f"hnsw_efc{efc}", NUM_CANDIDATES)
        curve.append((f"HNSW efConstruction={efc}", lat, rec))
    for nprobe in (10, 50, 100):                       # Atlas exposes the search width as numCandidates
        lat, rec = run("ivf_idx", nprobe)
        curve.append((f"IVF nprobe~{nprobe}", lat, rec))
    client.close()
    return rows, curve


# --------------------------------------------------------------------------------------------------
# Offline mode
# --------------------------------------------------------------------------------------------------
def run_offline(args, ck):
    print(f"   Generating {args.docs} synthetic {DIMS}-dimensional embeddings (400 topic clusters)")
    emb = synthetic_embeddings(args.docs, DIMS, args.seed)
    inserted = 0
    for s in range(0, args.docs, BATCH):                    # insert_many in batches of 500
        inserted += len(emb[s:s + BATCH])
    ck.check(f"{args.docs:,} documents inserted in batches of 500", inserted == args.docs,
             f"{inserted} docs, {math.ceil(args.docs / BATCH)} batches, {DIMS} dims")
    rng = np.random.default_rng(args.seed + 1)
    queries = emb[rng.choice(args.docs, args.queries, replace=False)]
    t0 = time.perf_counter()
    truth = [brute_force_top(emb, q) for q in queries]
    bf_ms = (time.perf_counter() - t0) * 1000 / len(queries)
    ck.check("exact brute-force top-20 computed for every query", all(len(t) == TOP_K for t in truth),
             f"{bf_ms:.3f} ms per query")

    def build_hnsw(M, efc):
        t = time.perf_counter()
        idx = HNSW(emb, M=M, ef_construction=efc)
        return idx, time.perf_counter() - t

    def build_ivf(nlist):
        t = time.perf_counter()
        idx = IVF(emb, nlist=nlist)
        return idx, time.perf_counter() - t

    print("\n2) The two indexes (definitions)")
    print("   HNSW: " + str(atlas_index_definition("hnsw", M=16, efConstruction=64)))
    print("   IVF : " + str(atlas_index_definition("ivf", nlist=100)))

    print("\n3) Build and query: 100 queries, top 20, recall against exact search")
    hnsw, t_h = build_hnsw(16, 64)
    lat_h, rec_h = measure(lambda q: hnsw.search(q, TOP_K, NUM_CANDIDATES), queries, truth)
    ivf, t_i = build_ivf(100)
    lat_i, rec_i = measure(lambda q: ivf.search(q, TOP_K, 10), queries, truth)
    rows = [("HNSW", "M=16, efConstruction=64 (search width 100)", t_h, lat_h, rec_h),
            ("IVF", "nlist=100, nprobe=10", t_i, lat_i, rec_i)]
    ck.check("both indexes return 20 results per query", len(hnsw.search(queries[0])) == TOP_K
             and len(ivf.search(queries[0])) == TOP_K)
    ck.check("recall values are between 0 and 100 %", 0 <= rec_h <= 100 and 0 <= rec_i <= 100,
             f"HNSW {rec_h:.1f} %, IVF {rec_i:.1f} %")

    print("\n4) HNSW parameter experiments (efConstruction, M): latency-recall points")
    curve = []
    for efc in (32, 64, 128, 256):
        idx, t = build_hnsw(16, efc)
        lat, rec = measure(lambda q: idx.search(q, TOP_K, NUM_CANDIDATES), queries, truth)
        curve.append((f"HNSW efConstruction={efc}", lat, rec, t))
    hnsw_m = []
    for M in (8, 16, 32):
        idx, t = build_hnsw(M, 64)
        lat, rec = measure(lambda q: idx.search(q, TOP_K, NUM_CANDIDATES), queries, truth)
        hnsw_m.append((M, t, lat, rec))

    print("\n5) IVF parameter experiments (nlist, nprobe)")
    ivf_pts, ivf_nlist = [], []
    for nprobe in (10, 50, 100):
        lat, rec = measure(lambda q: ivf.search(q, TOP_K, nprobe), queries, truth)
        ivf_pts.append((f"IVF nprobe={nprobe}", lat, rec, t_i))
    for nlist in (50, 100, 200):
        idx, t = build_ivf(nlist)
        lat, rec = measure(lambda q: idx.search(q, TOP_K, 10), queries, truth)
        ivf_nlist.append((nlist, t, lat, rec))
    return rows, curve, ivf_pts, hnsw_m, ivf_nlist


def main():
    ap = argparse.ArgumentParser(description="Lab 17.2 - HNSW vs IVF")
    ap.add_argument("--offline", action="store_true")
    ap.add_argument("--uri", default=os.getenv("MONGO_URI"))
    ap.add_argument("--docs", type=int, default=5000)
    ap.add_argument("--queries", type=int, default=100)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--plot", default="latency_recall_curve.png")
    args = ap.parse_args()
    ck = Checker()

    print("Mode: " + ("OFFLINE (numpy HNSW and IVF, synthetic embeddings)" if args.offline
                      else "ONLINE (MongoDB Atlas Vector Search, sentence-transformers)"))
    print("\n1) Data")
    if not args.offline:
        if not args.uri:
            sys.exit("Set MONGO_URI (Atlas connection string) or pass --uri.")
        rows, curve = run_online(args, ck)
        hnsw_m = ivf_nlist = None
        curve = [(l, a, b, None) for l, a, b in curve]
        ivf_pts = [c for c in curve if c[0].startswith("IVF")]
        curve = [c for c in curve if c[0].startswith("HNSW")]
    else:
        rows, curve, ivf_pts, hnsw_m, ivf_nlist = run_offline(args, ck)

    print("\n6) Comparison table")
    print(f"   {'Index Type':<11}| {'Parameters':<44}| {'Build Time (s)':>14} | {'Avg Query Latency (ms)':>22} | {'Recall (%)':>10}")
    print("   " + "-" * 112)
    for kind, params, t, lat, rec in rows:
        print(f"   {kind:<11}| {params:<44}| {t:>14.2f} | {lat:>22.3f} | {rec:>10.1f}")

    if hnsw_m:
        print("\n   HNSW, effect of M (efConstruction=64)")
        print(f"   {'M':>4} | {'Build (s)':>9} | {'Latency (ms)':>12} | {'Recall (%)':>10}")
        for M, t, lat, rec in hnsw_m:
            print(f"   {M:>4} | {t:>9.2f} | {lat:>12.3f} | {rec:>10.1f}")
        print("\n   IVF, effect of nlist (nprobe=10)")
        print(f"   {'nlist':>5} | {'Build (s)':>9} | {'Latency (ms)':>12} | {'Recall (%)':>10}")
        for nl, t, lat, rec in ivf_nlist:
            print(f"   {nl:>5} | {t:>9.2f} | {lat:>12.3f} | {rec:>10.1f}")

    print("\n7) Latency-recall trade-off curve")
    pts = [(l, a, b) for l, a, b, _ in curve] + [(l, a, b) for l, a, b, _ in ivf_pts]
    ascii_curve(pts)
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(figsize=(7, 4.5))
        h = [(a, b) for l, a, b, _ in curve]
        i = [(a, b) for l, a, b, _ in ivf_pts]
        ax.plot([p[0] for p in h], [p[1] for p in h], "o-", label="HNSW (efConstruction 32, 64, 128, 256)")
        ax.plot([p[0] for p in i], [p[1] for p in i], "s--", label="IVF (nprobe 10, 50, 100)")
        ax.set_xlabel("Average query latency (ms)")
        ax.set_ylabel("Recall@20 (%)")
        ax.set_title("Latency-recall trade-off")
        ax.grid(alpha=.3)
        ax.legend()
        fig.tight_layout()
        fig.savefig(args.plot, dpi=150)
        print(f"   Plot saved to {args.plot}")
    except ImportError:
        print("   (matplotlib not installed: plot skipped)")

    if args.offline:
        print("\n8) Sanity checks")
        by_nprobe = [r for _, _, r, _ in ivf_pts]
        ck.check("IVF recall never drops when more lists are probed (nprobe 10 -> 50 -> 100)",
                 by_nprobe == sorted(by_nprobe), " / ".join(f"{r:.1f}" for r in by_nprobe))
        ck.check("IVF probing every list (nprobe = nlist = 100) is exact: 100 % recall", by_nprobe[-1] == 100.0)
        ck.check("HNSW (M=16, efConstruction=64) reaches at least 90 % recall", rows[0][4] >= 90, f"{rows[0][4]:.1f} %")
        ck.check("IVF probing 10 lists is faster than probing all 100 lists",
                 ivf_pts[0][1] < ivf_pts[-1][1], f"{ivf_pts[0][1]:.3f} ms vs {ivf_pts[-1][1]:.3f} ms")
        print(f"\n   RESULT: {ck.passed} passed, {ck.failed} failed")

    print("""
9) Recommendations (general guidance; check it against the table and curve above)
   HNSW : use when recall is critical (customer-facing search, RAG). Recall stays high and stable
          across settings; costs more memory (graph links) and a longer build than IVF. Raise
          efConstruction / M for recall, lower them for faster builds.
   IVF  : use when the dataset is very large (millions of vectors), memory is tight and a little
          lost recall is acceptable, or when the lowest latency matters most. Cheap to build; recall
          is controlled by nprobe (lists probed): probing more lists trades latency for recall.""")
    sys.exit(0 if ck.failed == 0 else 1)


if __name__ == "__main__":
    main()

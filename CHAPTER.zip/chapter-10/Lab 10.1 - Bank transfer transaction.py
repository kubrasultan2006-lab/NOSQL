"""
Lab 10.1: Implement a Bank Transfer Transaction

Usage (from the pymongo-quickstart folder, with the 3-node replica set running):

    python "chapter-10\\Lab 10.1 - Bank transfer transaction.py" --base-port 28017

What it does:
  1. Finds the primary (transactions must run on a replica set primary).
  2. Creates the accounts collection and inserts two accounts with balances.
  3. Defines transfer(): debit one account and credit another inside a session transaction.
  4. Test A: a valid transfer succeeds and is committed.
  5. Test B: a transfer with insufficient funds fails. The debit has already been applied
     inside the transaction when the check fails, so the abort has to roll it back.
     The script then verifies that neither balance changed.

Requires: pip install pymongo
"""

import argparse
from datetime import datetime, timezone

from pymongo import MongoClient, ReturnDocument
from pymongo.errors import PyMongoError
from pymongo.read_concern import ReadConcern
from pymongo.write_concern import WriteConcern

DB_NAME = "chapter-10"


class InsufficientFunds(Exception):
    pass


def find_primary_client(base_port):
    """Connect directly to each member and return a client for the primary."""
    for port in range(base_port, base_port + 3):
        client = MongoClient("localhost", port, directConnection=True, serverSelectionTimeoutMS=2000)
        try:
            if client.admin.command("hello").get("isWritablePrimary"):
                print(f"Connected to primary on port {port}")
                return client
        except PyMongoError:
            pass
        client.close()
    raise SystemExit("No primary found. Check that the replica set is healthy (rs.status()).")


def balances(db):
    return {doc["_id"]: doc["balance"] for doc in db.accounts.find().sort("_id")}


def setup(db):
    # Collections must exist before they are used inside a transaction
    db.drop_collection("accounts")
    db.drop_collection("transfers")
    db.create_collection("accounts")
    db.create_collection("transfers")
    db.accounts.insert_many([
        {"_id": "alice", "balance": 500},
        {"_id": "bob", "balance": 100},
    ])
    print(f"Initial balances: {balances(db)}")


def transfer(client, from_id, to_id, amount):
    """Move `amount` from one account to another atomically."""
    db = client[DB_NAME]
    with client.start_session() as session:
        # Any exception inside this block aborts the transaction
        with session.start_transaction(
            read_concern=ReadConcern("snapshot"),
            write_concern=WriteConcern("majority"),
        ):
            # Debit first, then check the result. If the balance went negative the
            # debit has already been applied inside the transaction, so raising here
            # shows that the abort undoes it.
            debited = db.accounts.find_one_and_update(
                {"_id": from_id},
                {"$inc": {"balance": -amount}},
                return_document=ReturnDocument.AFTER,
                session=session,
            )
            if debited is None:
                raise ValueError(f"Account {from_id!r} does not exist")
            print(f"  inside transaction: {from_id} balance after debit = {debited['balance']}")
            if debited["balance"] < 0:
                raise InsufficientFunds(
                    f"{from_id} has {debited['balance'] + amount}, cannot transfer {amount}"
                )

            credited = db.accounts.update_one(
                {"_id": to_id}, {"$inc": {"balance": amount}}, session=session
            )
            if credited.matched_count == 0:
                raise ValueError(f"Account {to_id!r} does not exist")

            db.transfers.insert_one(
                {"from": from_id, "to": to_id, "amount": amount, "at": datetime.now(timezone.utc)},
                session=session,
            )
        # Leaving the with-block without an exception commits the transaction


def attempt(client, from_id, to_id, amount):
    db = client[DB_NAME]
    print(f"\nTransfer {amount} from {from_id} to {to_id}")
    before = balances(db)
    try:
        transfer(client, from_id, to_id, amount)
        print("  result: COMMITTED")
    except InsufficientFunds as exc:
        print(f"  result: ABORTED ({exc})")
    except (ValueError, PyMongoError) as exc:
        print(f"  result: ABORTED ({type(exc).__name__}: {exc})")
    after = balances(db)
    print(f"  balances before: {before}")
    print(f"  balances after:  {after}")
    return before, after


def main():
    parser = argparse.ArgumentParser(description="Lab 10.1: bank transfer transaction")
    parser.add_argument("--base-port", type=int, default=28017, help="host port of the first member")
    args = parser.parse_args()

    client = find_primary_client(args.base_port)
    db = client[DB_NAME]
    setup(db)

    # Test A: valid transfer
    before, after = attempt(client, "alice", "bob", 200)
    assert after == {"alice": 300, "bob": 300}, "valid transfer should be committed"

    # Test B: insufficient funds -> rollback
    before, after = attempt(client, "alice", "bob", 1000)
    assert after == before, "failed transfer must leave both balances unchanged"
    print("\nVerified: the failed transfer rolled back, neither balance changed.")
    print(f"Transfers recorded: {db.transfers.count_documents({})} (only the successful one)")

    client.close()


if __name__ == "__main__":
    main()
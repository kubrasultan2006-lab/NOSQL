"""
Activity for 10.1: Try it yourself
Add retry logic with exponential backoff for write conflicts
(errors carrying the 'TransientTransactionError' label).

Usage (from the pymongo-quickstart folder, with the 3-node replica set running):

    python "chapter-10\\Activity for 10.1 - Try it yourself.py" --base-port 28017

What it does:
  1. Creates accounts shaped as {account_id, balance, version}.
  2. transfer_once(): one transaction that checks the source balance, debits and credits
     with update_one (the debit filter includes balance >= amount) and inserts a history record.
  3. transfer_with_retry(): runs transfer_once() and, on a TransientTransactionError,
     sleeps 0.1 * 2**attempt seconds and retries the whole transaction.
  4. Test 1: many threads transfer from the same account at once. This causes write
     conflicts, which are retried until every transfer commits.
  5. Test 2: a transfer with insufficient funds fails immediately and is NOT retried,
     because it is not a transient error.
  6. Verifies the final balances and that no money was created or lost.

Requires: pip install pymongo
"""

import argparse
import threading
import time
from datetime import datetime, timezone

from pymongo import MongoClient
from pymongo.errors import PyMongoError
from pymongo.read_concern import ReadConcern
from pymongo.write_concern import WriteConcern

DB_NAME = "chapter-10"
MAX_RETRIES = 6


class InsufficientFunds(Exception):
    pass


def find_primary_client(base_port):
    """Connect directly to each member and return a client for the primary."""
    for port in range(base_port, base_port + 3):
        client = MongoClient("localhost", port, directConnection=True, serverSelectionTimeoutMS=2000)
        try:
            if client.admin.command("hello").get("isWritablePrimary"):
                print(f"Connected to primary on port {port}")
                return client
        except PyMongoError:
            pass
        client.close()
    raise SystemExit("No primary found. Check that the replica set is healthy (rs.status()).")


def setup(db):
    db.drop_collection("accounts")
    db.drop_collection("history")
    db.create_collection("accounts")
    db.create_collection("history")
    db.accounts.insert_many([
        {"account_id": "alice", "balance": 1000, "version": 0},
        {"account_id": "bob", "balance": 1000, "version": 0},
    ])


def balances(db):
    return {d["account_id"]: d["balance"] for d in db.accounts.find().sort("account_id")}


def transfer_once(client, from_id, to_id, amount):
    """One attempt: a single transaction. Any exception aborts (rolls back) it."""
    db = client[DB_NAME]
    with client.start_session() as session:
        with session.start_transaction(
            read_concern=ReadConcern("snapshot"),
            write_concern=WriteConcern("majority"),
        ):
            # 1. Check the source balance
            source = db.accounts.find_one({"account_id": from_id}, session=session)
            if source is None or source["balance"] < amount:
                raise InsufficientFunds(f"{from_id} cannot transfer {amount}")

            # 2. Debit (the filter also guards against the balance dropping below amount)
            debit = db.accounts.update_one(
                {"account_id": from_id, "balance": {"$gte": amount}},
                {"$inc": {"balance": -amount, "version": 1}},
                session=session,
            )
            if debit.matched_count == 0:
                raise InsufficientFunds(f"{from_id} cannot transfer {amount}")

            # 3. Credit
            db.accounts.update_one(
                {"account_id": to_id},
                {"$inc": {"balance": amount, "version": 1}},
                session=session,
            )

            # 4. History record in the same transaction
            db.history.insert_one(
                {"from": from_id, "to": to_id, "amount": amount, "at": datetime.now(timezone.utc)},
                session=session,
            )


def transfer_with_retry(client, from_id, to_id, amount, max_retries=MAX_RETRIES):
    """Retry the whole transaction with exponential backoff on TransientTransactionError.

    Returns the number of retries that were needed.
    """
    for attempt in range(max_retries + 1):
        try:
            transfer_once(client, from_id, to_id, amount)
            return attempt
        except PyMongoError as exc:
            transient = exc.has_error_label("TransientTransactionError")
            if transient and attempt < max_retries:
                delay = 0.1 * 2 ** attempt
                print(f"  [{threading.current_thread().name}] write conflict, "
                      f"retry {attempt + 1}/{max_retries} in {delay:.1f} s")
                time.sleep(delay)
                continue
            raise  # not transient, or out of retries


def main():
    parser = argparse.ArgumentParser(description="Activity 10.1: retry with exponential backoff")
    parser.add_argument("--base-port", type=int, default=28017, help="host port of the first member")
    parser.add_argument("--threads", type=int, default=10, help="number of concurrent transfers")
    parser.add_argument("--amount", type=int, default=10, help="amount moved by each transfer")
    args = parser.parse_args()

    client = find_primary_client(args.base_port)
    db = client[DB_NAME]
    setup(db)
    print(f"Initial balances: {balances(db)}")

    # Test 1: concurrent transfers from the same account -> write conflicts -> retries
    print(f"\nTest 1: {args.threads} concurrent transfers of {args.amount} from alice to bob")
    retries_per_thread = {}
    failures = []

    def worker(n):
        try:
            retries_per_thread[n] = transfer_with_retry(client, "alice", "bob", args.amount)
        except Exception as exc:
            failures.append((n, exc))

    threads = [threading.Thread(target=worker, args=(i,), name=f"T{i}") for i in range(args.threads)]
    t0 = time.time()
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    elapsed = time.time() - t0

    total_retries = sum(retries_per_thread.values())
    print(f"\nFinished in {elapsed:.2f} s: {len(retries_per_thread)} committed, "
          f"{len(failures)} failed, {total_retries} retries in total")
    for n, exc in failures:
        print(f"  T{n} failed: {type(exc).__name__}: {exc}")

    moved = args.amount * len(retries_per_thread)
    final = balances(db)
    print(f"Final balances: {final}")
    assert final == {"alice": 1000 - moved, "bob": 1000 + moved}, "balances do not match committed transfers"
    assert sum(final.values()) == 2000, "money was created or lost"
    assert db.history.count_documents({}) == len(retries_per_thread), "history count mismatch"
    print("Verified: balances, total money and history all match the committed transfers.")

    # Test 2: insufficient funds is not transient -> no retry
    print("\nTest 2: transfer of 99999 from alice to bob (insufficient funds)")
    before = balances(db)
    try:
        transfer_with_retry(client, "alice", "bob", 99999)
    except InsufficientFunds as exc:
        print(f"  failed immediately without retrying: {exc}")
    assert balances(db) == before, "failed transfer must not change balances"
    print("Verified: balances unchanged after the failed transfer.")

    client.close()


if __name__ == "__main__":
    main()
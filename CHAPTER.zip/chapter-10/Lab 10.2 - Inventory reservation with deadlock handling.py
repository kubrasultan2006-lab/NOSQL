"""
Lab 10.2: Inventory Reservation with Deadlock Handling

Usage (from the pymongo-quickstart folder, with the 3-node replica set running):

    python "chapter-10\\Lab 10.2 - Inventory reservation with deadlock handling.py" --base-port 28017

What it does:
  1. Schema: inventory {product_id, name, stock, version}
             orders    {order_id, customer_id, items[{product_id, qty, price}], status, total}
  2. reserve_inventory(): in one transaction it reads the stock, checks availability,
     decrements stock (and bumps version) and inserts a pending order.
  3. Demo: 8 threads each reserve 1 unit of a product that has only 5 in stock.
       a) without retry logic  -> several threads fail with a write conflict
       b) with retry logic     -> 5 succeed, 3 correctly fail with out-of-stock
  4. Throughput: 1, 4, 8 and 16 threads, transactional vs non-transactional
     (find_one_and_update). Results are printed, saved to lab-10.2-throughput.csv and
     plotted to lab-10.2-throughput.png (if matplotlib is installed).
  5. Consistency: injects a failure after the stock decrement but before the order insert.
     The transaction rolls back cleanly, the non-transactional version leaks stock.

Requires: pip install pymongo   (optional for the plot: pip install matplotlib)
"""

import argparse
import csv
import random
import threading
import time
import uuid
from collections import Counter
from concurrent.futures import ThreadPoolExecutor

from pymongo import MongoClient, ReturnDocument
from pymongo.errors import PyMongoError
from pymongo.read_concern import ReadConcern
from pymongo.write_concern import WriteConcern

DB_NAME = "chapter-10"
PRODUCT_ID = "P-1001"
PRICE = 19.99
MAX_RETRIES = 5


class OutOfStock(Exception):
    pass


class VersionConflict(Exception):
    """The optimistic version check matched no document."""


class SimulatedFailure(Exception):
    """Injected between the stock decrement and the order insert."""


# --------------------------------------------------------------------------- setup helpers
def find_primary_client(base_port):
    for port in range(base_port, base_port + 3):
        client = MongoClient("localhost", port, directConnection=True, serverSelectionTimeoutMS=2000,
                             maxPoolSize=50)
        try:
            if client.admin.command("hello").get("isWritablePrimary"):
                print(f"Connected to primary on port {port}")
                return client
        except PyMongoError:
            pass
        client.close()
    raise SystemExit("No primary found. Check that the replica set is healthy (rs.status()).")


def setup(db, stock):
    """Recreate both collections (they must exist before use inside a transaction)."""
    db.drop_collection("inventory")
    db.drop_collection("orders")
    db.create_collection("inventory")
    db.create_collection("orders")
    db.inventory.insert_one({"product_id": PRODUCT_ID, "name": "Wireless Mouse", "stock": stock, "version": 0})


def state(db):
    product = db.inventory.find_one({"product_id": PRODUCT_ID})
    return product["stock"], db.orders.count_documents({})


def is_conflict(exc):
    """pymongo has no WriteConflict class: a write conflict is error code 112 and
    carries the TransientTransactionError label."""
    if isinstance(exc, VersionConflict):
        return True
    return isinstance(exc, PyMongoError) and (
        exc.has_error_label("TransientTransactionError") or getattr(exc, "code", None) == 112
    )


# --------------------------------------------------------------------------- reservation logic
def reserve_once(client, product_id, customer_id, qty, fail_rate=0.0):
    """One transactional attempt. Any exception aborts the transaction."""
    db = client[DB_NAME]
    with client.start_session() as session:
        with session.start_transaction(
            read_concern=ReadConcern("snapshot"),
            write_concern=WriteConcern("majority"),
        ):
            product = db.inventory.find_one({"product_id": product_id}, session=session)
            if product is None or product["stock"] < qty:
                raise OutOfStock()

            # Optimistic concurrency control: only update if the version we read is still current
            result = db.inventory.update_one(
                {"product_id": product_id, "version": product["version"]},
                {"$inc": {"stock": -qty, "version": 1}},
                session=session,
            )
            if result.matched_count == 0:
                raise VersionConflict()

            if fail_rate and random.random() < fail_rate:
                raise SimulatedFailure()

            db.orders.insert_one(
                {
                    "order_id": str(uuid.uuid4()),
                    "customer_id": customer_id,
                    "items": [{"product_id": product_id, "qty": qty, "price": PRICE}],
                    "status": "pending",
                    "total": round(PRICE * qty, 2),
                },
                session=session,
            )


def reserve_inventory(client, product_id, customer_id, qty=1, max_retries=MAX_RETRIES, fail_rate=0.0):
    """Reserve stock transactionally, retrying write conflicts.

    Returns (status, retries). status is one of:
    reserved, out_of_stock, conflict (retries exhausted), failed (simulated), error.
    max_retries=0 disables the retry logic.
    """
    for attempt in range(max_retries + 1):
        try:
            reserve_once(client, product_id, customer_id, qty, fail_rate)
            return "reserved", attempt
        except OutOfStock:
            return "out_of_stock", attempt
        except SimulatedFailure:
            return "failed", attempt
        except (PyMongoError, VersionConflict) as exc:
            if is_conflict(exc):
                if attempt < max_retries:
                    time.sleep(0.01 * (attempt + 1) + random.uniform(0, 0.01))  # short, jittered sleep
                    continue
                return "conflict", attempt
            return "error", attempt
    return "conflict", max_retries


def reserve_non_transactional(client, product_id, customer_id, qty=1, fail_rate=0.0):
    """Non-transactional version: atomic findAndModify, then a separate order insert."""
    db = client[DB_NAME]
    try:
        updated = db.inventory.find_one_and_update(
            {"product_id": product_id, "stock": {"$gte": qty}},
            {"$inc": {"stock": -qty, "version": 1}},
            return_document=ReturnDocument.AFTER,
        )
        if updated is None:
            return "out_of_stock", 0
        if fail_rate and random.random() < fail_rate:
            raise SimulatedFailure()  # stock is already decremented and nothing rolls it back
        db.orders.insert_one(
            {
                "order_id": str(uuid.uuid4()),
                "customer_id": customer_id,
                "items": [{"product_id": product_id, "qty": qty, "price": PRICE}],
                "status": "pending",
                "total": round(PRICE * qty, 2),
            }
        )
        return "reserved", 0
    except SimulatedFailure:
        return "failed", 0
    except PyMongoError:
        return "error", 0


# --------------------------------------------------------------------------- test harness
def run_batch(task, n_requests, workers, sync_start=False):
    """Run n_requests calls of task(i) on `workers` threads. Returns (Counter, retries, seconds)."""
    gate = threading.Barrier(workers) if sync_start else None

    def wrapped(i):
        if gate is not None:
            gate.wait()  # make all threads hit the database at the same moment
        return task(i)

    t0 = time.time()
    with ThreadPoolExecutor(max_workers=workers) as pool:
        results = list(pool.map(wrapped, range(n_requests)))
    elapsed = time.time() - t0
    statuses = Counter(status for status, _ in results)
    retries = sum(r for _, r in results)
    return statuses, retries, elapsed


def demo_contention(client, db):
    print("\n=== Demo: 8 simultaneous requests for 1 unit each, only 5 in stock ===")
    for label, retries in (("WITHOUT retry logic", 0), (f"WITH retry logic (max {MAX_RETRIES})", MAX_RETRIES)):
        setup(db, stock=5)
        statuses, total_retries, _ = run_batch(
            lambda i: reserve_inventory(client, PRODUCT_ID, f"cust-{i}", 1, max_retries=retries),
            n_requests=8, workers=8, sync_start=True,
        )
        stock, orders = state(db)
        print(f"\n{label}")
        print(f"  outcomes: {dict(statuses)}   retries used: {total_retries}")
        print(f"  final stock: {stock}   orders created: {orders}")
        assert stock >= 0, "oversold!"
        assert orders == 5 - stock, "orders and stock decrements do not match"
        if retries:
            print("  expected: 5 reserved, 3 out_of_stock (stock reached zero)")
        else:
            print("  expected: some requests fail with 'conflict' even though stock was available")


def benchmark(client, db, n_requests, levels=(1, 4, 8, 16)):
    print(f"\n=== Throughput: {n_requests} reservations of the same product ===")
    print(f"{'threads':>8} | {'approach':<15} | {'reserved':>8} | {'conflict':>8} | "
          f"{'retries':>7} | {'seconds':>7} | {'reservations/s':>14}")
    rows = []
    for workers in levels:
        for approach in ("transactional", "findAndModify"):
            setup(db, stock=n_requests)  # enough stock, so the contention is on the write
            if approach == "transactional":
                task = lambda i: reserve_inventory(client, PRODUCT_ID, f"cust-{i}", 1)
            else:
                task = lambda i: reserve_non_transactional(client, PRODUCT_ID, f"cust-{i}", 1)
            statuses, retries, elapsed = run_batch(task, n_requests, workers)
            reserved = statuses.get("reserved", 0)
            rate = reserved / elapsed
            print(f"{workers:>8} | {approach:<15} | {reserved:>8} | {statuses.get('conflict', 0):>8} | "
                  f"{retries:>7} | {elapsed:>7.2f} | {rate:>14.1f}")
            rows.append({"threads": workers, "approach": approach, "reserved": reserved,
                         "conflict": statuses.get("conflict", 0), "retries": retries,
                         "seconds": round(elapsed, 3), "reservations_per_s": round(rate, 1)})

    with open("lab-10.2-throughput.csv", "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)
    print("\nSaved lab-10.2-throughput.csv")

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        plt.figure(figsize=(7, 4))
        for approach in ("transactional", "findAndModify"):
            pts = [(r["threads"], r["reservations_per_s"]) for r in rows if r["approach"] == approach]
            plt.plot(*zip(*pts), marker="o", label=approach)
        plt.xlabel("Concurrent threads")
        plt.ylabel("Successful reservations per second")
        plt.title("Lab 10.2 - throughput by concurrency level")
        plt.xticks(list(levels))
        plt.grid(alpha=0.3)
        plt.legend()
        plt.tight_layout()
        plt.savefig("lab-10.2-throughput.png", dpi=150)
        print("Saved lab-10.2-throughput.png")
    except ImportError:
        print("matplotlib not installed, skipping the plot (pip install matplotlib)")


def consistency_test(client, db, n_requests=100, fail_rate=0.1):
    print(f"\n=== Consistency: {int(fail_rate * 100)}% of requests fail after the stock decrement ===")
    for approach in ("transactional", "findAndModify"):
        setup(db, stock=n_requests)
        if approach == "transactional":
            task = lambda i: reserve_inventory(client, PRODUCT_ID, f"cust-{i}", 1, fail_rate=fail_rate)
        else:
            task = lambda i: reserve_non_transactional(client, PRODUCT_ID, f"cust-{i}", 1, fail_rate=fail_rate)
        statuses, _, _ = run_batch(task, n_requests, workers=8)
        stock, orders = state(db)
        decremented = n_requests - stock
        leaked = decremented - orders
        print(f"\n{approach}")
        print(f"  outcomes: {dict(statuses)}")
        print(f"  stock decremented: {decremented}   orders created: {orders}   leaked units: {leaked}")
        print("  " + ("consistent: every decrement has an order" if leaked == 0
                      else "INCONSISTENT: stock was decremented without an order"))


def main():
    parser = argparse.ArgumentParser(description="Lab 10.2: inventory reservation with deadlock handling")
    parser.add_argument("--base-port", type=int, default=28017, help="host port of the first member")
    parser.add_argument("--requests", type=int, default=160, help="reservations per throughput run")
    parser.add_argument("--fail-rate", type=float, default=0.1, help="failure rate for the consistency test")
    args = parser.parse_args()

    client = find_primary_client(args.base_port)
    db = client[DB_NAME]

    demo_contention(client, db)
    benchmark(client, db, args.requests)
    consistency_test(client, db, fail_rate=args.fail_rate)

    client.close()


if __name__ == "__main__":
    main()
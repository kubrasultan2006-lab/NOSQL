"""Lab 5.2: Join Data with $lookup (MongoDB + pymongo)

Prints each task as a boxed table and verifies every pipeline result
against a plain-Python calculation.

Install:  pip install pymongo
Run:      python chapter-05\\lab_02_lookup_joins.py
"""
from datetime import datetime

from pymongo import MongoClient

MONGO_URI = "mongodb://localhost:27017"  # or your Atlas connection string

# ---------------------------------------------------------------------------
# Task 1 data: products, and orders that REFERENCE products by product_id
# (the order documents hold the product's _id, not an embedded copy)
# ---------------------------------------------------------------------------
PRODUCTS = [
    # _id, name, category, base_price
    ("P001", "Laptop",       "Electronics",  899.00),
    ("P002", "Phone",        "Electronics",  520.00),
    ("P003", "Headphones",   "Accessories",   99.00),
    ("P004", "Keyboard",     "Accessories",   49.50),
    ("P005", "Mouse",        "Accessories",   19.99),
    ("P006", "Monitor",      "Electronics",  280.00),
    ("P007", "Webcam",       "Accessories",   59.00),
    ("P008", "Desk Lamp",    "Home Office",   32.00),
    ("P009", "Office Chair", "Home Office",  175.00),
    ("P010", "USB Hub",      "Accessories",   24.50),
]

ORDERS = [
    # customer, product_id, quantity, order_date
    ("Vikram Singh", "P001", 1, datetime(2026, 1, 6)),
    ("Vikram Singh", "P004", 2, datetime(2026, 1, 22)),
    ("Kavya Nair",   "P003", 2, datetime(2026, 1, 11)),
    ("Kavya Nair",   "P006", 1, datetime(2026, 2, 19)),
    ("Sneha Reddy",  "P005", 3, datetime(2026, 2, 8)),
    ("Sneha Reddy",  "P002", 1, datetime(2026, 3, 20)),
    ("Arjun Mehta",  "P006", 2, datetime(2026, 1, 15)),
    ("Arjun Mehta",  "P009", 1, datetime(2026, 3, 3)),
    ("Priya Sharma", "P002", 1, datetime(2026, 1, 19)),
    ("Priya Sharma", "P003", 1, datetime(2026, 2, 16)),
    ("Rohan Gupta",  "P001", 1, datetime(2026, 2, 2)),
    ("Rohan Gupta",  "P005", 4, datetime(2026, 2, 24)),
    ("Ananya Iyer",  "P004", 1, datetime(2026, 2, 21)),
    ("Ananya Iyer",  "P009", 2, datetime(2026, 3, 18)),
    ("Deepak Joshi", "P005", 2, datetime(2026, 3, 30)),
]


# ---------------------------------------------------------------------------
# Helpers: boxed table printing, money formatting, verification
# ---------------------------------------------------------------------------
def money(value):
    return f"${value:,.2f}"


def print_table(headers, rows, aligns):
    """Print a boxed table. aligns: one of '<' (left) or '>' (right) per column."""
    cells = [[str(c) for c in row] for row in rows]
    widths = [
        max(len(headers[i]), *(len(r[i]) for r in cells)) for i in range(len(headers))
    ]

    def line(left, mid, right):
        return left + mid.join("─" * (w + 2) for w in widths) + right

    def fmt(row, use_aligns):
        return "│" + "│".join(
            f" {c:{a}{w}} " for c, a, w in zip(row, use_aligns, widths)
        ) + "│"

    print(line("┌", "┬", "┐"))
    print(fmt(headers, ["<"] * len(headers)))
    print(line("├", "┼", "┤"))
    for i, row in enumerate(cells):
        print(fmt(row, aligns))
        if i < len(cells) - 1:
            print(line("├", "┼", "┤"))
    print(line("└", "┴", "┘"))


def verify(mongo_rows, python_rows):
    """Compare two lists of tuples (order ignored), tolerating tiny float errors."""
    def same(a, b):
        return all(
            abs(x - y) < 0.01 if isinstance(x, float) else x == y
            for x, y in zip(a, b)
        )

    m, p = sorted(mongo_rows), sorted(python_rows)
    ok = len(m) == len(p) and all(same(a, b) for a, b in zip(m, p))
    print("  [OK] matches the plain-Python calculation" if ok
          else "  [MISMATCH] differs from the plain-Python calculation")


# ---------------------------------------------------------------------------
# Plain-Python calculations (used only to double-check the pipelines)
# ---------------------------------------------------------------------------
def py_order_details():
    by_id = {pid: (name, price) for pid, name, _, price in PRODUCTS}
    rows = []
    for _, pid, qty, date in ORDERS:
        name, price = by_id[pid]
        rows.append((date.strftime("%Y-%m-%d"), name, qty, round(qty * price, 2)))
    return rows


def py_never_ordered():
    ordered = {pid for _, pid, _, _ in ORDERS}
    return [
        (pid, name, category, price)
        for pid, name, category, price in PRODUCTS
        if pid not in ordered
    ]


# ---------------------------------------------------------------------------
# Pipelines
# ---------------------------------------------------------------------------
# Task 2: join orders -> products, then compute quantity * base_price
ORDER_DETAILS_PIPELINE = [
    {
        "$lookup": {
            "from": "products",
            "localField": "product_id",
            "foreignField": "_id",
            "as": "product",
        }
    },
    {"$unwind": "$product"},  # one matching product per order
    {
        "$project": {
            "_id": 0,
            "order_date": 1,
            "product_name": "$product.name",
            "quantity": 1,
            "total": {"$round": [{"$multiply": ["$quantity", "$product.base_price"]}, 2]},
        }
    },
    {"$sort": {"order_date": 1, "product_name": 1}},
]

# Task 3: left outer join products -> orders, keep products with no orders
NEVER_ORDERED_PIPELINE = [
    {
        "$lookup": {
            "from": "orders",
            "localField": "_id",
            "foreignField": "product_id",
            "as": "orders",
        }
    },
    {"$match": {"orders": {"$size": 0}}},  # empty join result = never ordered
    {"$project": {"name": 1, "category": 1, "base_price": 1}},
    {"$sort": {"name": 1}},
]


def main():
    client = MongoClient(MONGO_URI)
    db = client["chapter-05"]
    products, orders = db["products"], db["orders"]

    # Task 1: create both collections
    products.drop()  # start fresh so re-running doesn't duplicate data
    orders.drop()
    products.insert_many(
        [
            {"_id": pid, "name": name, "category": category, "base_price": price}
            for pid, name, category, price in PRODUCTS
        ]
    )
    orders.insert_many(
        [
            {"customer": cust, "product_id": pid, "quantity": qty, "order_date": date}
            for cust, pid, qty, date in ORDERS
        ]
    )
    print(
        f"=== Task 1: Inserted {products.count_documents({})} products "
        f"and {orders.count_documents({})} orders ==="
    )

    # Task 2: $lookup join
    print("\n=== Task 2: Orders joined with products ($lookup) ===")
    docs = list(orders.aggregate(ORDER_DETAILS_PIPELINE))
    print_table(
        ["Order date", "Product", "Quantity", "Total"],
        [
            (d["order_date"].strftime("%Y-%m-%d"), d["product_name"], d["quantity"],
             money(d["total"]))
            for d in docs
        ],
        ["<", "<", ">", ">"],
    )
    verify(
        [(d["order_date"].strftime("%Y-%m-%d"), d["product_name"], d["quantity"],
          d["total"]) for d in docs],
        py_order_details(),
    )

    # Task 3: products that have never been ordered
    print("\n=== Task 3: Products that have never been ordered ===")
    docs = list(products.aggregate(NEVER_ORDERED_PIPELINE))
    print_table(
        ["#", "Product ID", "Product", "Category", "Base price"],
        [
            (i, d["_id"], d["name"], d["category"], money(d["base_price"]))
            for i, d in enumerate(docs, start=1)
        ],
        [">", "<", "<", "<", ">"],
    )
    verify(
        [(d["_id"], d["name"], d["category"], d["base_price"]) for d in docs],
        py_never_ordered(),
    )

    client.close()


if __name__ == "__main__":
    main()
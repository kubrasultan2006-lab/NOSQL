"""Lab 5.1: Build a Sales Analytics Pipeline (MongoDB + pymongo)

Prints each task as a boxed table and verifies every pipeline result
against a plain-Python calculation.

Install:  pip install pymongo
Run:      python chapter-05\\lab_5_1_sales_pipeline.py
"""
from collections import defaultdict
from datetime import datetime

from pymongo import MongoClient

MONGO_URI = "mongodb://localhost:27017"  # or your Atlas connection string

# ---------------------------------------------------------------------------
# Task 1 data: 24 orders across 8 customers and 6 products
# ---------------------------------------------------------------------------
FIELDS = ["customer", "product", "quantity", "unit_price", "order_date", "status"]

SAMPLE_ORDERS = [
    ("Vikram Singh", "Laptop",     1, 1150.00, datetime(2026, 1, 6),  "delivered"),
    ("Vikram Singh", "Keyboard",   2,   45.50, datetime(2026, 1, 22), "delivered"),
    ("Vikram Singh", "Phone",      1,  620.00, datetime(2026, 3, 9),  "shipped"),
    ("Kavya Nair",   "Headphones", 2,   95.00, datetime(2026, 1, 11), "delivered"),
    ("Kavya Nair",   "Laptop",     1,  980.00, datetime(2026, 2, 4),  "delivered"),
    ("Kavya Nair",   "Monitor",    1,  310.00, datetime(2026, 2, 19), "shipped"),
    ("Kavya Nair",   "Phone",      1,  480.00, datetime(2026, 3, 15), "pending"),
    ("Sneha Reddy",  "Laptop",     1,  899.00, datetime(2026, 1, 28), "delivered"),
    ("Sneha Reddy",  "Mouse",      3,   18.00, datetime(2026, 2, 8),  "delivered"),
    ("Sneha Reddy",  "Headphones", 1,  120.00, datetime(2026, 2, 26), "cancelled"),
    ("Sneha Reddy",  "Phone",      1,  540.00, datetime(2026, 3, 20), "shipped"),
    ("Arjun Mehta",  "Monitor",    2,  275.00, datetime(2026, 1, 15), "delivered"),
    ("Arjun Mehta",  "Mouse",      2,   20.00, datetime(2026, 2, 12), "delivered"),
    ("Arjun Mehta",  "Keyboard",   1,   60.00, datetime(2026, 3, 3),  "pending"),
    ("Priya Sharma", "Phone",      1,  510.00, datetime(2026, 1, 19), "delivered"),
    ("Priya Sharma", "Headphones", 1,  110.00, datetime(2026, 2, 16), "delivered"),
    ("Priya Sharma", "Keyboard",   1,   52.00, datetime(2026, 3, 12), "cancelled"),
    ("Rohan Gupta",  "Laptop",     1,  870.00, datetime(2026, 2, 2),  "delivered"),
    ("Rohan Gupta",  "Mouse",      4,   16.50, datetime(2026, 2, 24), "delivered"),
    ("Rohan Gupta",  "Monitor",    1,  295.00, datetime(2026, 3, 27), "pending"),
    ("Ananya Iyer",  "Headphones", 2,  105.00, datetime(2026, 1, 9),  "delivered"),
    ("Ananya Iyer",  "Keyboard",   1,   49.00, datetime(2026, 2, 21), "delivered"),
    ("Ananya Iyer",  "Phone",      1,  455.00, datetime(2026, 3, 18), "cancelled"),
    ("Deepak Joshi", "Mouse",      2,   22.00, datetime(2026, 3, 30), "shipped"),
]


# ---------------------------------------------------------------------------
# Helpers: boxed table printing, money formatting, verification
# ---------------------------------------------------------------------------
def money(value):
    return f"${value:,.2f}"


def print_table(headers, rows, aligns):
    """Print a boxed table. aligns: one of '<' (left) or '>' (right) per column."""
    cells = [[str(c) for c in row] for row in rows]
    widths = [
        max(len(headers[i]), *(len(r[i]) for r in cells)) for i in range(len(headers))
    ]

    def line(left, mid, right):
        return left + mid.join("─" * (w + 2) for w in widths) + right

    def fmt(row, use_aligns):
        return "│" + "│".join(
            f" {c:{a}{w}} " for c, a, w in zip(row, use_aligns, widths)
        ) + "│"

    print(line("┌", "┬", "┐"))
    print(fmt(headers, ["<"] * len(headers)))
    print(line("├", "┼", "┤"))
    for i, row in enumerate(cells):
        print(fmt(row, aligns))
        if i < len(cells) - 1:
            print(line("├", "┼", "┤"))
    print(line("└", "┴", "┘"))


def verify(mongo_result, python_result):
    """Compare {key: [numbers...]} dicts, tolerating tiny float differences."""
    ok = mongo_result.keys() == python_result.keys() and all(
        len(mongo_result[k]) == len(python_result[k])
        and all(abs(a - b) < 0.01 for a, b in zip(mongo_result[k], python_result[k]))
        for k in mongo_result
    )
    print("  [OK] matches the plain-Python calculation" if ok
          else "  [MISMATCH] differs from the plain-Python calculation")


# ---------------------------------------------------------------------------
# Plain-Python calculations (used only to double-check the pipelines)
# ---------------------------------------------------------------------------
def py_monthly_revenue():
    totals, counts = defaultdict(float), defaultdict(int)
    for _, _, qty, price, date, _ in SAMPLE_ORDERS:
        key = date.strftime("%Y-%m")
        totals[key] += qty * price
        counts[key] += 1
    return {m: [counts[m], round(totals[m], 2)] for m in sorted(totals)}


def py_top_customers():
    spent, count = defaultdict(float), defaultdict(int)
    for cust, _, qty, price, _, _ in SAMPLE_ORDERS:
        spent[cust] += qty * price
        count[cust] += 1
    top = sorted(spent, key=spent.get, reverse=True)[:3]
    return [(c, round(spent[c], 2), count[c]) for c in top]


def py_status_summary():
    totals, counts = defaultdict(float), defaultdict(int)
    for _, _, qty, price, _, status in SAMPLE_ORDERS:
        totals[status] += qty * price
        counts[status] += 1
    return {
        s: [counts[s], round(totals[s] / counts[s], 2), round(totals[s], 2)]
        for s in totals
    }


def py_size_buckets():
    totals, counts = defaultdict(float), defaultdict(int)
    for _, _, qty, price, _, _ in SAMPLE_ORDERS:
        value = qty * price
        size = "small" if value < 50 else "medium" if value <= 200 else "large"
        totals[size] += value
        counts[size] += 1
    return {
        s: [counts[s], round(totals[s] / counts[s], 2), round(totals[s], 2)]
        for s in totals
    }


# ---------------------------------------------------------------------------
# Pipelines
# ---------------------------------------------------------------------------
MONTHLY_REVENUE_PIPELINE = [
    {
        "$group": {
            "_id": {"$dateToString": {"format": "%Y-%m", "date": "$order_date"}},
            "order_count": {"$sum": 1},
            "total_revenue": {"$sum": {"$multiply": ["$quantity", "$unit_price"]}},
        }
    },
    {"$sort": {"_id": 1}},
    {
        "$project": {
            "_id": 0,
            "month": "$_id",
            "order_count": 1,
            "total_revenue": {"$round": ["$total_revenue", 2]},
        }
    },
]

TOP_CUSTOMERS_PIPELINE = [
    {
        "$group": {
            "_id": "$customer",
            "total_spent": {"$sum": {"$multiply": ["$quantity", "$unit_price"]}},
            "order_count": {"$sum": 1},
            "products": {"$addToSet": "$product"},
        }
    },
    {"$sort": {"total_spent": -1}},
    {"$limit": 3},
    {
        "$project": {
            "_id": 0,
            "customer": "$_id",
            "total_spent": {"$round": ["$total_spent", 2]},
            "order_count": 1,
            "products": 1,
        }
    },
]

AVG_ORDER_VALUE_PIPELINE = [
    {
        "$group": {
            "_id": "$status",
            "order_count": {"$sum": 1},
            "avg_order_value": {"$avg": {"$multiply": ["$quantity", "$unit_price"]}},
            "total_value": {"$sum": {"$multiply": ["$quantity", "$unit_price"]}},
        }
    },
    {"$sort": {"avg_order_value": -1}},
    {
        "$project": {
            "_id": 0,
            "status": "$_id",
            "order_count": 1,
            "avg_order_value": {"$round": ["$avg_order_value", 2]},
            "total_value": {"$round": ["$total_value", 2]},
        }
    },
]


# Activity 5.1: categorize orders by total order value with $bucket.
# $bucket boundaries include the lower value and exclude the upper one, and
# prices are in cents, so 200.01 is the first value that counts as "large":
#   small  = under $50      -> [0, 50)
#   medium = $50 to $200    -> [50, 200.01)
#   large  = over $200      -> [200.01, infinity)
SIZE_BUCKET_PIPELINE = [
    {"$addFields": {"order_total": {"$multiply": ["$quantity", "$unit_price"]}}},
    {
        "$bucket": {
            "groupBy": "$order_total",
            "boundaries": [0, 50, 200.01, float("inf")],
            "output": {
                "order_count": {"$sum": 1},
                "avg_order_value": {"$avg": "$order_total"},
                "total_value": {"$sum": "$order_total"},
            },
        }
    },
    {
        "$project": {
            "_id": 1,
            "order_count": 1,
            "avg_order_value": {"$round": ["$avg_order_value", 2]},
            "total_value": {"$round": ["$total_value", 2]},
        }
    },
]
SIZE_LABELS = {0: "small", 50: "medium", 200.01: "large"}  # keyed by lower boundary
SIZE_RANGES = {"small": "under $50", "medium": "$50 - $200", "large": "over $200"}


def main():
    client = MongoClient(MONGO_URI)
    orders = client["chapter-05"]["orders"]

    # Task 1: create the collection
    orders.drop()  # start fresh so re-running doesn't duplicate data
    orders.insert_many([dict(zip(FIELDS, row)) for row in SAMPLE_ORDERS])
    print(f"=== Task 1: Inserted {orders.count_documents({})} orders ===")

    # Task 2: monthly revenue
    print("\n=== Task 2: Monthly revenue ===")
    docs = list(orders.aggregate(MONTHLY_REVENUE_PIPELINE))
    print_table(
        ["Month", "Orders", "Revenue"],
        [(d["month"], d["order_count"], money(d["total_revenue"])) for d in docs],
        ["<", ">", ">"],
    )
    verify(
        {d["month"]: [d["order_count"], d["total_revenue"]] for d in docs},
        py_monthly_revenue(),
    )

    # Task 3: top 3 customers
    print("\n=== Task 3: Top 3 customers by total spending ===")
    docs = list(orders.aggregate(TOP_CUSTOMERS_PIPELINE))
    print_table(
        ["#", "Customer", "Total spent", "Orders", "Products bought"],
        [
            (i, d["customer"], money(d["total_spent"]), d["order_count"],
             ", ".join(sorted(d["products"])))
            for i, d in enumerate(docs, start=1)
        ],
        [">", "<", ">", ">", "<"],
    )
    verify(
        {d["customer"]: [d["total_spent"], d["order_count"]] for d in docs},
        {c: [t, n] for c, t, n in py_top_customers()},
    )

    # Task 4: average order value per status
    print("\n=== Task 4: Average order value per status ===")
    docs = list(orders.aggregate(AVG_ORDER_VALUE_PIPELINE))
    print_table(
        ["Status", "Orders", "Avg order value", "Total value"],
        [
            (d["status"], d["order_count"], money(d["avg_order_value"]),
             money(d["total_value"]))
            for d in docs
        ],
        ["<", ">", ">", ">"],
    )
    verify(
        {d["status"]: [d["order_count"], d["avg_order_value"], d["total_value"]]
         for d in docs},
        py_status_summary(),
    )

    # Activity 5.1: $bucket size categories
    print("\n=== Activity 5.1: Orders by size ($bucket) ===")
    docs = list(orders.aggregate(SIZE_BUCKET_PIPELINE))
    for d in docs:
        d["size"] = SIZE_LABELS[d["_id"]]
    print_table(
        ["Size", "Order value", "Orders", "Avg order value", "Total value"],
        [
            (d["size"], SIZE_RANGES[d["size"]], d["order_count"],
             money(d["avg_order_value"]), money(d["total_value"]))
            for d in docs
        ],
        ["<", "<", ">", ">", ">"],
    )
    verify(
        {d["size"]: [d["order_count"], d["avg_order_value"], d["total_value"]]
         for d in docs},
        py_size_buckets(),
    )

    client.close()


if __name__ == "__main__":
    main()
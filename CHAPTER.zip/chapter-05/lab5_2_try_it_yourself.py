"""Activity for 5.2: Try it yourself
$lookup with a pipeline sub-expression (MongoDB 3.6+) that filters the joined
documents on the foreign side BEFORE they are returned.

Here: for every product, join only the orders with quantity >= MIN_QUANTITY
(bulk orders). Products with no bulk orders are still returned, with an empty
join result.

Prints the result as a boxed table and verifies it against a plain-Python
calculation.

Install:  pip install pymongo
Run:      python chapter-05\\lab5.2_try_it_yourself.py
"""
from datetime import datetime

from pymongo import MongoClient

MONGO_URI = "mongodb://localhost:27017"  # or your Atlas connection string
MIN_QUANTITY = 2  # an order counts as a "bulk order" at this quantity or more

# ---------------------------------------------------------------------------
# Data (same products and orders as Lab 5.2; orders reference product_id)
# ---------------------------------------------------------------------------
PRODUCTS = [
    # _id, name, category, base_price
    ("P001", "Laptop",       "Electronics",  899.00),
    ("P002", "Phone",        "Electronics",  520.00),
    ("P003", "Headphones",   "Accessories",   99.00),
    ("P004", "Keyboard",     "Accessories",   49.50),
    ("P005", "Mouse",        "Accessories",   19.99),
    ("P006", "Monitor",      "Electronics",  280.00),
    ("P007", "Webcam",       "Accessories",   59.00),
    ("P008", "Desk Lamp",    "Home Office",   32.00),
    ("P009", "Office Chair", "Home Office",  175.00),
    ("P010", "USB Hub",      "Accessories",   24.50),
]

ORDERS = [
    # customer, product_id, quantity, order_date
    ("Vikram Singh", "P001", 1, datetime(2026, 1, 6)),
    ("Vikram Singh", "P004", 2, datetime(2026, 1, 22)),
    ("Kavya Nair",   "P003", 2, datetime(2026, 1, 11)),
    ("Kavya Nair",   "P006", 1, datetime(2026, 2, 19)),
    ("Sneha Reddy",  "P005", 3, datetime(2026, 2, 8)),
    ("Sneha Reddy",  "P002", 1, datetime(2026, 3, 20)),
    ("Arjun Mehta",  "P006", 2, datetime(2026, 1, 15)),
    ("Arjun Mehta",  "P009", 1, datetime(2026, 3, 3)),
    ("Priya Sharma", "P002", 1, datetime(2026, 1, 19)),
    ("Priya Sharma", "P003", 1, datetime(2026, 2, 16)),
    ("Rohan Gupta",  "P001", 1, datetime(2026, 2, 2)),
    ("Rohan Gupta",  "P005", 4, datetime(2026, 2, 24)),
    ("Ananya Iyer",  "P004", 1, datetime(2026, 2, 21)),
    ("Ananya Iyer",  "P009", 2, datetime(2026, 3, 18)),
    ("Deepak Joshi", "P005", 2, datetime(2026, 3, 30)),
]


# ---------------------------------------------------------------------------
# Helpers: boxed table printing, money formatting, verification
# ---------------------------------------------------------------------------
def money(value):
    return f"${value:,.2f}"


def print_table(headers, rows, aligns):
    """Print a boxed table. aligns: one of '<' (left) or '>' (right) per column."""
    cells = [[str(c) for c in row] for row in rows]
    widths = [
        max(len(headers[i]), *(len(r[i]) for r in cells)) for i in range(len(headers))
    ]

    def line(left, mid, right):
        return left + mid.join("─" * (w + 2) for w in widths) + right

    def fmt(row, use_aligns):
        return "│" + "│".join(
            f" {c:{a}{w}} " for c, a, w in zip(row, use_aligns, widths)
        ) + "│"

    print(line("┌", "┬", "┐"))
    print(fmt(headers, ["<"] * len(headers)))
    print(line("├", "┼", "┤"))
    for i, row in enumerate(cells):
        print(fmt(row, aligns))
        if i < len(cells) - 1:
            print(line("├", "┼", "┤"))
    print(line("└", "┴", "┘"))


def verify(mongo_rows, python_rows):
    """Compare two lists of tuples (order ignored), tolerating tiny float errors."""
    def same(a, b):
        return all(
            abs(x - y) < 0.01 if isinstance(x, float) else x == y
            for x, y in zip(a, b)
        )

    m, p = sorted(mongo_rows), sorted(python_rows)
    ok = len(m) == len(p) and all(same(a, b) for a, b in zip(m, p))
    print("  [OK] matches the plain-Python calculation" if ok
          else "  [MISMATCH] differs from the plain-Python calculation")


# ---------------------------------------------------------------------------
# Plain-Python calculation (used only to double-check the pipeline)
# ---------------------------------------------------------------------------
def py_bulk_summary():
    rows = []
    for pid, name, category, price in PRODUCTS:
        bulk = [qty for _, p, qty, _ in ORDERS if p == pid and qty >= MIN_QUANTITY]
        rows.append((name, category, len(bulk), sum(bulk), round(sum(bulk) * price, 2)))
    return rows


# ---------------------------------------------------------------------------
# Pipeline: $lookup with a pipeline sub-expression
# ---------------------------------------------------------------------------
BULK_ORDERS_PIPELINE = [
    {
        "$lookup": {
            "from": "orders",
            "let": {"pid": "$_id"},  # variable passed in from the products side
            "pipeline": [
                # Runs on the orders (foreign) collection, so the filter is
                # applied BEFORE the joined documents come back.
                {
                    "$match": {
                        "$expr": {
                            "$and": [
                                {"$eq": ["$product_id", "$$pid"]},
                                {"$gte": ["$quantity", MIN_QUANTITY]},
                            ]
                        }
                    }
                },
                {"$project": {"_id": 0, "quantity": 1, "order_date": 1}},
            ],
            "as": "bulk_orders",
        }
    },
    {
        "$project": {
            "_id": 0,
            "name": 1,
            "category": 1,
            "bulk_order_count": {"$size": "$bulk_orders"},
            "units": {"$sum": "$bulk_orders.quantity"},
            "revenue": {
                "$round": [
                    {"$multiply": [{"$sum": "$bulk_orders.quantity"}, "$base_price"]},
                    2,
                ]
            },
        }
    },
    {"$sort": {"revenue": -1, "name": 1}},
]


def main():
    client = MongoClient(MONGO_URI)
    db = client["chapter-05"]
    products, orders = db["products"], db["orders"]

    # Create both collections (orders reference products by product_id)
    products.drop()  # start fresh so re-running doesn't duplicate data
    orders.drop()
    products.insert_many(
        [
            {"_id": pid, "name": name, "category": category, "base_price": price}
            for pid, name, category, price in PRODUCTS
        ]
    )
    orders.insert_many(
        [
            {"customer": cust, "product_id": pid, "quantity": qty, "order_date": date}
            for cust, pid, qty, date in ORDERS
        ]
    )

    print(
        f"=== Activity 5.2: $lookup with a pipeline sub-expression "
        f"(orders with quantity >= {MIN_QUANTITY}) ==="
    )
    docs = list(products.aggregate(BULK_ORDERS_PIPELINE))
    print_table(
        ["Product", "Category", "Bulk orders", "Units", "Revenue"],
        [
            (d["name"], d["category"], d["bulk_order_count"], d["units"],
             money(d["revenue"]))
            for d in docs
        ],
        ["<", "<", ">", ">", ">"],
    )
    verify(
        [(d["name"], d["category"], d["bulk_order_count"], d["units"], d["revenue"])
         for d in docs],
        py_bulk_summary(),
    )

    client.close()


if __name__ == "__main__":
    main()
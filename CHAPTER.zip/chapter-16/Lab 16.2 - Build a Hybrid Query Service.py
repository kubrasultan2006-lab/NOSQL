"""
Lab 16.2: Build a Hybrid Query Service (MongoDB + Cassandra + Neo4j)

FraudQueryService answers fraud-detection questions from three databases and merges the results:
  get_transaction(txn_id)                -> MongoDB   flexible document lookup
  get_user_profile(user_id)              -> Cassandra time-ordered events (newest first, LIMIT 10)
  detect_fraud_rings(user_id, max_hops)  -> Neo4j     multi-hop traversal of the money-transfer graph
  analyze_transaction(txn_id)            -> the full workflow, merged, degrading gracefully

Connection pooling
  MongoDB   : MongoClient(maxPoolSize=10)             (PyMongo's built-in pool)
  Cassandra : Cluster(executor_threads=4)              (driver executor threads)
  Neo4j     : driver(max_connection_pool_size=10)
Circuit breaker (per backend)
  3 consecutive failures -> the backend is marked unavailable and skipped; after 30 s one trial call
  is allowed (success closes the breaker, failure keeps it open).

Steps (all printed):
  1. Unit tests        : unittest.mock replaces every driver; checks the merged results and the breaker
  2. Integration test  : the full fraud workflow on MongoDB (real server) with Cassandra and Neo4j
                         simulated in memory (or real servers with --cassandra / --neo4j-uri)
  3. Failure injection : Neo4j goes down, the service still answers from the other two backends
  4. Latency           : median and 95th percentile per method, next to the documented characteristics

Run:
    python "chapter-16\\Lab 16.2 - Build a Hybrid Query Service.py"
Optional real servers:
    --cassandra 127.0.0.1                     (pip install cassandra-driver)
    --neo4j-uri bolt://127.0.0.1:7687 --neo4j-user neo4j --neo4j-password PASSWORD   (pip install neo4j)

Uses its own MongoDB database (default chapter-16), dropped at the end unless --keep is given.
Requires: pip install pymongo python-dotenv
"""

import argparse
import os
import re
import statistics
import sys
import time
import unittest
from collections import deque
from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock

from pymongo import MongoClient

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass


# --------------------------------------------------------------------------
# Circuit breaker
# --------------------------------------------------------------------------
class BackendUnavailable(Exception):
    pass


class CircuitBreaker:
    """Opens after `threshold` consecutive failures; allows one trial call after `reset_seconds`."""

    def __init__(self, name, threshold=3, reset_seconds=30, clock=time.monotonic):
        self.name, self.threshold, self.reset_seconds, self.clock = name, threshold, reset_seconds, clock
        self.failures = 0
        self.opened_at = None

    @property
    def is_open(self):
        return self.opened_at is not None and self.clock() - self.opened_at < self.reset_seconds

    def call(self, fn, *args, **kwargs):
        if self.is_open:
            raise BackendUnavailable(f"{self.name} is unavailable (circuit open)")
        try:                                   # closed, or half-open trial call after the pause
            result = fn(*args, **kwargs)
        except Exception:
            self.failures += 1
            if self.failures >= self.threshold:
                self.opened_at = self.clock()
            raise
        self.failures, self.opened_at = 0, None
        return result


# --------------------------------------------------------------------------
# The service
# --------------------------------------------------------------------------
def _row_to_dict(row):
    return dict(row) if isinstance(row, dict) else row._asdict()


class FraudQueryService:
    def __init__(self, mongo_db, cassandra_session, neo4j_driver, breaker_threshold=3,
                 breaker_reset=30, clock=time.monotonic, closers=()):
        self.mongo_db = mongo_db
        self.cassandra = cassandra_session
        self.neo4j = neo4j_driver
        self._closers = list(closers)
        self.breakers = {name: CircuitBreaker(name, breaker_threshold, breaker_reset, clock)
                         for name in ("mongodb", "cassandra", "neo4j")}

    @classmethod
    def connect(cls, mongo_uri, mongo_db_name, cassandra_hosts, keyspace, neo4j_uri, neo4j_user,
                neo4j_password, **kwargs):
        """Create the three pooled connections (needs real Cassandra and Neo4j servers)."""
        from cassandra.cluster import Cluster
        from neo4j import GraphDatabase
        mongo = MongoClient(mongo_uri, maxPoolSize=10, serverSelectionTimeoutMS=8000)
        cluster = Cluster(cassandra_hosts, executor_threads=4)
        driver = GraphDatabase.driver(neo4j_uri, auth=(neo4j_user, neo4j_password),
                                      max_connection_pool_size=10)
        return cls(mongo[mongo_db_name], cluster.connect(keyspace), driver,
                   closers=[mongo.close, cluster.shutdown, driver.close], **kwargs)

    def close(self):
        for closer in self._closers:
            closer()

    # ---- the three backend methods ---------------------------------------
    def get_transaction(self, txn_id):
        """MongoDB: full transaction document (amount, merchant, timestamp, risk_score, ...)."""
        return self.breakers["mongodb"].call(
            lambda: self.mongo_db.transactions.find_one({"txn_id": txn_id}, {"_id": 0}))

    def get_user_profile(self, user_id):
        """Cassandra: the user's 10 most recent events, newest first."""
        def query():
            rows = self.cassandra.execute(
                "SELECT * FROM user_profiles WHERE user_id = %s ORDER BY event_time DESC LIMIT 10",
                (user_id,))
            return [_row_to_dict(r) for r in rows]
        return self.breakers["cassandra"].call(query)

    def detect_fraud_rings(self, user_id, max_hops=3):
        """Neo4j: accounts connected to the user by money transfers within max_hops (closest first)."""
        if not isinstance(max_hops, int) or not 1 <= max_hops <= 5:
            raise ValueError("max_hops must be an integer between 1 and 5")
        cypher = (f"MATCH path = (u:User {{id: $uid}})-[:TRANSFERRED_TO*1..{max_hops}]-(c:User) "
                  "WHERE c.id <> $uid RETURN c.id AS id, min(length(path)) AS hops "
                  "ORDER BY hops, id LIMIT 50")

        def query():
            with self.neo4j.session() as session:
                return [{"id": r["id"], "hops": r["hops"]} for r in session.run(cypher, uid=user_id)]
        return self.breakers["neo4j"].call(query)

    # ---- the merged workflow ---------------------------------------------
    def analyze_transaction(self, txn_id, max_hops=3):
        result = {"txn_id": txn_id, "transaction": None, "recent_events": [], "connected_accounts": [],
                  "unavailable": [], "flags": [], "verdict": "OK"}

        def attempt(backend, fn, default):
            try:
                return fn()
            except Exception:                  # BackendUnavailable or a driver error
                if backend not in result["unavailable"]:
                    result["unavailable"].append(backend)
                return default

        txn = attempt("mongodb", lambda: self.get_transaction(txn_id), None)
        result["transaction"] = txn
        if txn is None:
            if "mongodb" not in result["unavailable"]:
                result["flags"].append("transaction not found")
            return result
        user = txn["user_id"]
        result["recent_events"] = attempt("cassandra", lambda: self.get_user_profile(user), [])
        result["connected_accounts"] = attempt("neo4j", lambda: self.detect_fraud_rings(user, max_hops), [])

        high_risk = txn.get("risk_score", 0) >= 0.8
        ring = len(result["connected_accounts"]) >= 3
        if high_risk:
            result["flags"].append("high risk score")
        if ring:
            result["flags"].append(f"connected to {len(result['connected_accounts'])} accounts "
                                   f"within {max_hops} hops")
        if high_risk and ring:
            result["flags"].append("possible fraud ring")
        if result["flags"]:
            result["verdict"] = "REVIEW"
        return result


# --------------------------------------------------------------------------
# Mock data and in-memory stand-ins for Cassandra and Neo4j
# --------------------------------------------------------------------------
BASE_TIME = datetime(2026, 11, 1, 9, 0, tzinfo=timezone.utc)
TRANSACTIONS = [
    {"txn_id": "T1001", "user_id": "U1", "amount": 9500.0, "merchant": "QuickCash",
     "timestamp": BASE_TIME + timedelta(hours=12), "risk_score": 0.91, "channel": "web"},
    {"txn_id": "T2001", "user_id": "U6", "amount": 42.5, "merchant": "Bookshop",
     "timestamp": BASE_TIME + timedelta(hours=5), "risk_score": 0.05},
]
EVENTS = [{"user_id": "U1", "event_time": BASE_TIME + timedelta(hours=i), "event_type": "payment",
           "amount": 100.0 + i, "merchant": "Shop%d" % i} for i in range(12)]          # 12 events
EVENTS += [{"user_id": "U6", "event_time": BASE_TIME, "event_type": "payment", "amount": 42.5,
            "merchant": "Bookshop"}]
TRANSFERS = [("U1", "U2"), ("U2", "U3"), ("U3", "U4"), ("U4", "U5"), ("U6", "U7")]       # chain U1..U5


class FakeRow:
    def __init__(self, data):
        self._data = data

    def _asdict(self):
        return dict(self._data)


class FakeCassandraSession:
    def __init__(self, events):
        self.events = events

    def execute(self, query, params=None):
        rows = sorted((e for e in self.events if e["user_id"] == params[0]),
                      key=lambda e: e["event_time"], reverse=True)[:10]
        return [FakeRow(r) for r in rows]


class FakeNeo4jSession:
    def __init__(self, edges):
        self.edges = edges

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def run(self, cypher, **params):
        limit = int(re.search(r"\*1\.\.(\d+)", cypher).group(1))
        start = params["uid"]
        dist, queue = {start: 0}, deque([start])
        while queue:                                          # breadth-first, relationships undirected
            node = queue.popleft()
            if dist[node] == limit:
                continue
            for a, b in self.edges:
                for x, y in ((a, b), (b, a)):
                    if x == node and y not in dist:
                        dist[y] = dist[node] + 1
                        queue.append(y)
        return [{"id": n, "hops": h} for n, h in sorted(dist.items(), key=lambda i: (i[1], i[0])) if n != start]


class FakeNeo4jDriver:
    def __init__(self, edges):
        self.edges = edges

    def session(self):
        return FakeNeo4jSession(self.edges)

    def close(self):
        pass


class BrokenNeo4jDriver:
    """Every call fails, and the number of attempts is counted."""

    def __init__(self):
        self.attempts = 0

    def session(self):
        self.attempts += 1
        raise ConnectionError("Neo4j is down")


# Optional: seed REAL Cassandra / Neo4j servers (only used with --cassandra / --neo4j-uri)
def real_cassandra_session(host):
    from cassandra.cluster import Cluster
    cluster = Cluster([host], executor_threads=4)
    session = cluster.connect()
    session.execute("DROP KEYSPACE IF EXISTS fraud_lab")
    session.execute("CREATE KEYSPACE fraud_lab WITH replication = {'class':'SimpleStrategy','replication_factor':1}")
    session.set_keyspace("fraud_lab")
    session.execute("CREATE TABLE user_profiles (user_id text, event_time timestamp, event_type text, "
                    "amount double, merchant text, PRIMARY KEY ((user_id), event_time)) "
                    "WITH CLUSTERING ORDER BY (event_time DESC)")
    for e in EVENTS:
        session.execute("INSERT INTO user_profiles (user_id, event_time, event_type, amount, merchant) "
                        "VALUES (%s,%s,%s,%s,%s)",
                        (e["user_id"], e["event_time"], e["event_type"], e["amount"], e["merchant"]))
    return cluster, session


def real_neo4j_driver(uri, user, password):
    from neo4j import GraphDatabase
    driver = GraphDatabase.driver(uri, auth=(user, password), max_connection_pool_size=10)
    with driver.session() as s:
        s.run("MATCH (n:User {fraudlab:true}) DETACH DELETE n")
        for uid in sorted({u for edge in TRANSFERS for u in edge}):
            s.run("CREATE (:User {id:$id, fraudlab:true})", id=uid)
        for a, b in TRANSFERS:
            s.run("MATCH (x:User {id:$a, fraudlab:true}), (y:User {id:$b, fraudlab:true}) "
                  "CREATE (x)-[:TRANSFERRED_TO]->(y)", a=a, b=b)
    return driver


# --------------------------------------------------------------------------
# 1) Unit tests (unittest.mock replaces every driver)
# --------------------------------------------------------------------------
class FakeClock:
    def __init__(self):
        self.now = 1000.0

    def __call__(self):
        return self.now


def mocked_service(clock=None):
    mongo_db, cassandra, driver = MagicMock(), MagicMock(), MagicMock()
    mongo_db.transactions.find_one.return_value = dict(TRANSACTIONS[0])
    cassandra.execute.return_value = [{"user_id": "U1", "event_type": "payment", "amount": 120.0}]
    driver.session.return_value.__enter__.return_value.run.return_value = [
        {"id": "U2", "hops": 1}, {"id": "U3", "hops": 2}, {"id": "U4", "hops": 3}]
    kwargs = {"clock": clock} if clock else {}
    return FraudQueryService(mongo_db, cassandra, driver, **kwargs), mongo_db, cassandra, driver


class UnitTests(unittest.TestCase):
    def test_get_transaction(self):
        """get_transaction returns the MongoDB document (txn_id lookup)"""
        svc, mongo_db, _, _ = mocked_service()
        txn = svc.get_transaction("T1001")
        self.assertEqual((txn["amount"], txn["merchant"]), (9500.0, "QuickCash"))
        self.assertEqual(mongo_db.transactions.find_one.call_args[0][0], {"txn_id": "T1001"})

    def test_get_user_profile(self):
        """get_user_profile queries Cassandra newest first with LIMIT 10"""
        svc, _, cassandra, _ = mocked_service()
        rows = svc.get_user_profile("U1")
        query, params = cassandra.execute.call_args[0]
        self.assertIn("ORDER BY event_time DESC LIMIT 10", query)
        self.assertEqual((params, rows[0]["amount"]), (("U1",), 120.0))

    def test_detect_fraud_rings(self):
        """detect_fraud_rings returns connected accounts with their hop distance"""
        svc, _, _, driver = mocked_service()
        ring = svc.detect_fraud_rings("U1", max_hops=3)
        self.assertEqual([r["id"] for r in ring], ["U2", "U3", "U4"])
        cypher = driver.session.return_value.__enter__.return_value.run.call_args[0][0]
        self.assertIn("TRANSFERRED_TO*1..3", cypher)

    def test_max_hops_validation(self):
        """max_hops outside 1..5 is rejected before any query runs"""
        svc, _, _, driver = mocked_service()
        for bad in (0, 6, "3"):
            with self.assertRaises(ValueError):
                svc.detect_fraud_rings("U1", max_hops=bad)
        driver.session.assert_not_called()

    def test_merged_result(self):
        """analyze_transaction merges the three backends and flags a possible fraud ring"""
        svc, *_ = mocked_service()
        res = svc.analyze_transaction("T1001")
        self.assertEqual(res["transaction"]["txn_id"], "T1001")
        self.assertEqual(len(res["recent_events"]), 1)
        self.assertEqual(len(res["connected_accounts"]), 3)
        self.assertIn("possible fraud ring", res["flags"])
        self.assertEqual((res["verdict"], res["unavailable"]), ("REVIEW", []))

    def test_breaker_opens_after_three_failures(self):
        """3 consecutive failures open the breaker; the 4th call is skipped without touching Neo4j"""
        svc, _, _, driver = mocked_service()
        run = driver.session.return_value.__enter__.return_value.run
        run.side_effect = RuntimeError("down")
        for _ in range(3):
            with self.assertRaises(RuntimeError):
                svc.detect_fraud_rings("U1")
        with self.assertRaises(BackendUnavailable):
            svc.detect_fraud_rings("U1")
        self.assertEqual(run.call_count, 3)

    def test_breaker_retries_after_30_seconds(self):
        """after 30 s one trial call is allowed and a success closes the breaker"""
        clock = FakeClock()
        svc, _, _, driver = mocked_service(clock)
        run = driver.session.return_value.__enter__.return_value.run
        good = run.return_value
        run.side_effect = RuntimeError("down")
        for _ in range(3):
            with self.assertRaises(RuntimeError):
                svc.detect_fraud_rings("U1")
        clock.now += 29
        with self.assertRaises(BackendUnavailable):
            svc.detect_fraud_rings("U1")
        clock.now += 2                                   # 31 s after the breaker opened
        run.side_effect = None
        run.return_value = good
        self.assertEqual(len(svc.detect_fraud_rings("U1")), 3)
        self.assertFalse(svc.breakers["neo4j"].is_open)

    def test_success_resets_failure_counter(self):
        """failures must be consecutive: a success in between keeps the breaker closed"""
        svc, _, _, driver = mocked_service()
        run = driver.session.return_value.__enter__.return_value.run
        good = run.return_value
        for _ in range(2):
            run.side_effect = RuntimeError("down")
            with self.assertRaises(RuntimeError):
                svc.detect_fraud_rings("U1")
        run.side_effect = None
        run.return_value = good
        svc.detect_fraud_rings("U1")
        run.side_effect = RuntimeError("down")
        for _ in range(2):
            with self.assertRaises(RuntimeError):
                svc.detect_fraud_rings("U1")
        self.assertFalse(svc.breakers["neo4j"].is_open)

    def test_degraded_result(self):
        """when Neo4j fails the other two results are still returned and Neo4j is reported"""
        svc, _, _, driver = mocked_service()
        driver.session.return_value.__enter__.return_value.run.side_effect = RuntimeError("down")
        res = svc.analyze_transaction("T1001")
        self.assertEqual(res["unavailable"], ["neo4j"])
        self.assertIsNotNone(res["transaction"])
        self.assertEqual(len(res["recent_events"]), 1)
        self.assertEqual(res["connected_accounts"], [])


class LabResult(unittest.TestResult):
    def __init__(self):
        super().__init__()
        self.passed = 0

    def addSuccess(self, test):
        super().addSuccess(test)
        self.passed += 1
        print(f"   [PASS] {test.shortDescription()}")

    def addFailure(self, test, err):
        super().addFailure(test, err)
        print(f"   [FAIL] {test.shortDescription()} -> {err[1]}")

    def addError(self, test, err):
        super().addError(test, err)
        print(f"   [FAIL] {test.shortDescription()} -> {err[1]!r}")


def run_unit_tests():
    result = LabResult()
    unittest.defaultTestLoader.loadTestsFromTestCase(UnitTests).run(result)
    return result.passed, len(result.failures) + len(result.errors)


# --------------------------------------------------------------------------
# 2) Integration test and 3) failure injection
# --------------------------------------------------------------------------
class Checker:
    def __init__(self):
        self.passed = 0
        self.failed = 0

    def check(self, label, ok, detail=""):
        print(f"   [{'PASS' if ok else 'FAIL'}] {label}" + (f" -> {detail}" if detail else ""))
        if ok:
            self.passed += 1
        else:
            self.failed += 1


def seed_mongo(db):
    db.transactions.insert_many([dict(t) for t in TRANSACTIONS])
    db.transactions.create_index("txn_id", unique=True)


def integration_test(svc, ck):
    txn = svc.get_transaction("T1001")
    ck.check("MongoDB: get_transaction returns amount and merchant",
             txn and txn["amount"] == 9500.0 and txn["merchant"] == "QuickCash",
             f"{txn['amount']} at {txn['merchant']}" if txn else "None")
    ck.check("MongoDB: unknown transaction returns None", svc.get_transaction("T9999") is None)

    events = svc.get_user_profile("U1")
    times = [e["event_time"] for e in events]
    ck.check("Cassandra: 12 events stored, the 10 newest are returned", len(events) == 10, f"{len(events)} rows")
    ck.check("Cassandra: events are in time order, newest first", times == sorted(times, reverse=True))

    ids = lambda hops: [r["id"] for r in svc.detect_fraud_rings("U1", hops)]
    ck.check("Neo4j: 1 hop finds the direct neighbour only", ids(1) == ["U2"], str(ids(1)))
    ck.check("Neo4j: 3 hops finds U2, U3, U4", ids(3) == ["U2", "U3", "U4"], str(ids(3)))
    ck.check("Neo4j: U5 (4 hops away) is not reached with max_hops=3", "U5" not in ids(3))

    res = svc.analyze_transaction("T1001")
    ck.check("workflow: suspicious transaction -> REVIEW with 'possible fraud ring'",
             res["verdict"] == "REVIEW" and "possible fraud ring" in res["flags"], "; ".join(res["flags"]))
    ck.check("workflow: all three backends contributed",
             res["transaction"] and len(res["recent_events"]) == 10 and len(res["connected_accounts"]) == 3
             and not res["unavailable"])
    res = svc.analyze_transaction("T2001")
    ck.check("workflow: harmless transaction -> OK, no flags", res["verdict"] == "OK" and not res["flags"],
             f"verdict={res['verdict']}, connected={len(res['connected_accounts'])}")
    res = svc.analyze_transaction("T9999")
    ck.check("workflow: unknown transaction is reported, nothing else is queried",
             res["flags"] == ["transaction not found"] and not res["recent_events"])


def failure_injection(mongo_db, ck):
    broken = BrokenNeo4jDriver()
    svc = FraudQueryService(mongo_db, FakeCassandraSession(EVENTS), broken)
    results = [svc.analyze_transaction("T1001") for _ in range(5)]
    ck.check("Neo4j down: every answer still has MongoDB and Cassandra data",
             all(r["transaction"] and len(r["recent_events"]) == 10 for r in results))
    ck.check("Neo4j down: every answer reports neo4j as unavailable",
             all(r["unavailable"] == ["neo4j"] for r in results))
    ck.check("circuit breaker: Neo4j was tried only 3 times in 5 requests (2 were skipped)",
             broken.attempts == 3, f"{broken.attempts} attempts")
    ck.check("circuit breaker: breaker for Neo4j is open, the others are closed",
             svc.breakers["neo4j"].is_open and not svc.breakers["mongodb"].is_open
             and not svc.breakers["cassandra"].is_open)


# --------------------------------------------------------------------------
# 4) Latency
# --------------------------------------------------------------------------
def measure(fn, repeat, warmup=10):
    for _ in range(warmup):
        fn()
    times = []
    for _ in range(repeat):
        start = time.perf_counter()
        fn()
        times.append((time.perf_counter() - start) * 1000)
    times.sort()
    return statistics.median(times), times[int(0.95 * (len(times) - 1))]


LATENCY_NOTES = """
   Documented latency characteristics (real servers):
     MongoDB   lookups by txn_id (indexed)  : about 2 to 5 ms on average
     Cassandra time-ordered partition reads : about 3 to 8 ms on average
     Neo4j     graph traversals             : from about 10 ms (1 hop) to about 500 ms (3 hops),
                                              depending on graph density
     analyze_transaction runs the three calls one after another, so its latency is roughly their
     sum and is dominated by the Neo4j traversal; the three calls are independent, so they could
     run in parallel (thread pool) and the total would then be the slowest call.
"""


def latency_table(svc, repeat, simulated):
    rows = [("get_transaction (MongoDB)", lambda: svc.get_transaction("T1001")),
            ("get_user_profile (Cassandra)", lambda: svc.get_user_profile("U1")),
            ("detect_fraud_rings, 1 hop (Neo4j)", lambda: svc.detect_fraud_rings("U1", 1)),
            ("detect_fraud_rings, 3 hops (Neo4j)", lambda: svc.detect_fraud_rings("U1", 3)),
            ("analyze_transaction (all three)", lambda: svc.analyze_transaction("T1001"))]
    print(f"\n   Latency in milliseconds ({repeat} runs per method)")
    print("   " + "-" * 62)
    print(f"   {'Method':<38} | {'median':>8} | {'p95':>8}")
    print("   " + "-" * 62)
    for label, fn in rows:
        med, p95 = measure(fn, repeat)
        print(f"   {label:<38} | {med:>8.3f} | {p95:>8.3f}")
    print("   " + "-" * 62)
    if simulated:
        print("   Cassandra and Neo4j are simulated in memory here, so only the MongoDB row reflects a real\n"
              "   network round trip; the other rows only show the service overhead. Use --cassandra and\n"
              "   --neo4j-uri with real servers to measure them.")


# --------------------------------------------------------------------------
def main():
    p = argparse.ArgumentParser(description="Lab 16.2 - hybrid query service")
    p.add_argument("--uri", default=os.getenv("MONGO_URI", "mongodb://rsadmin:RsLabPass123@127.0.0.1:27047/?authSource=admin"))
    p.add_argument("--db", default="chapter-16")
    p.add_argument("--cassandra", help="host of a real Cassandra server (optional)")
    p.add_argument("--neo4j-uri", help="bolt URI of a real Neo4j server (optional)")
    p.add_argument("--neo4j-user", default="neo4j")
    p.add_argument("--neo4j-password", default="")
    p.add_argument("--repeat", type=int, default=200, help="runs per latency measurement")
    p.add_argument("--keep", action="store_true", help="do not drop the MongoDB lab database at the end")
    args = p.parse_args()

    print("Connection pooling: MongoClient(maxPoolSize=10) | Cluster(executor_threads=4) | "
          "Neo4j max_connection_pool_size=10")
    print("Circuit breaker   : 3 consecutive failures -> backend skipped, retry after 30 s")

    print("\n1) Unit tests (unittest.mock replaces MongoDB, Cassandra and Neo4j)")
    unit_passed, unit_failed = run_unit_tests()
    print(f"   RESULT: {unit_passed} passed, {unit_failed} failed")

    client = MongoClient(args.uri, maxPoolSize=10, serverSelectionTimeoutMS=8000)
    try:
        client.admin.command("ping")
    except Exception as exc:  # noqa: BLE001
        sys.exit(f"Could not connect to MongoDB: {exc}\nCheck --uri (or MONGO_URI in .env).")
    client.drop_database(args.db)
    mongo_db = client[args.db]
    seed_mongo(mongo_db)

    closers = []
    if args.cassandra:
        cluster, cassandra = real_cassandra_session(args.cassandra)
        closers.append(cluster.shutdown)
    else:
        cassandra = FakeCassandraSession(EVENTS)
    if args.neo4j_uri:
        neo4j = real_neo4j_driver(args.neo4j_uri, args.neo4j_user, args.neo4j_password)
        closers.append(neo4j.close)
    else:
        neo4j = FakeNeo4jDriver(TRANSFERS)
    simulated = not (args.cassandra and args.neo4j_uri)
    svc = FraudQueryService(mongo_db, cassandra, neo4j)

    ck = Checker()
    print("\n2) Integration test: full fraud analysis workflow")
    print("   MongoDB: real server | Cassandra: " + ("real server" if args.cassandra else "simulated in memory")
          + " | Neo4j: " + ("real server" if args.neo4j_uri else "simulated in memory"))
    integration_test(svc, ck)

    print("\n3) Failure injection: Neo4j goes down")
    failure_injection(mongo_db, ck)
    print(f"   RESULT: {ck.passed} passed, {ck.failed} failed")

    print("\n4) Latency")
    latency_table(svc, args.repeat, simulated)
    print(LATENCY_NOTES)

    total_failed = unit_failed + ck.failed
    print(f"TOTAL: {unit_passed + ck.passed} passed, {total_failed} failed")
    for closer in closers:
        closer()
    if not args.keep:
        client.drop_database(args.db)
        print(f"Database '{args.db}' dropped (use --keep to inspect it in Compass).")
    client.close()
    sys.exit(0 if total_failed == 0 else 1)


if __name__ == "__main__":
    main()
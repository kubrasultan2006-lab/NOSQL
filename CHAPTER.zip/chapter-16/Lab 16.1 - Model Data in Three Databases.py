"""
Lab 16.1: Model Data in Three Databases (MongoDB, Cassandra, Neo4j)

Dataset: a university course enrollment system
  students : S1 Alice, S2 Bob, S3 Carol
  courses  : C1 Databases, C2 Algorithms, C3 Machine Learning
  enrolled : Alice -> C1, C2 | Bob -> C1, C3 | Carol -> C2

Steps (all printed):
  1. MongoDB   : document model. students (embedded course_ids array) and courses (embedded
                 student roster). Runs against your MongoDB server.
  2. Cassandra : query-driven design. student_courses (PRIMARY KEY student_id) and
                 course_students (PRIMARY KEY course_id). The CQL is printed. It runs on a real
                 Cassandra server only if you pass --cassandra HOST; otherwise the two tables are
                 simulated in memory (dictionaries keyed by partition key).
  3. Neo4j     : Student and Course nodes with ENROLLED_IN relationships. The Cypher is printed.
                 It runs on a real Neo4j server only if you pass --neo4j-uri; otherwise the graph
                 is simulated in memory.
  4. Queries   : (a) all courses for a student, (b) all students in a course,
                 (c) students who share a course with Alice - in all three models.
                 Every model must return the same answers.
  5. Comparison: query syntax complexity and expected performance characteristics.

Run (MongoDB for real, Cassandra and Neo4j simulated):
    python "chapter-16\\Lab 16.1 - Model Data in Three Databases.py"
Optional real servers:
    --cassandra 127.0.0.1                     (pip install cassandra-driver)
    --neo4j-uri bolt://127.0.0.1:7687 --neo4j-user neo4j --neo4j-password PASSWORD   (pip install neo4j)

Uses its own MongoDB database (default chapter-16), dropped at the end unless --keep is given.
Requires: pip install pymongo python-dotenv
"""

import argparse
import os
import sys

from pymongo import MongoClient

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

STUDENTS = [("S1", "Alice"), ("S2", "Bob"), ("S3", "Carol")]
COURSES = [("C1", "Databases"), ("C2", "Algorithms"), ("C3", "Machine Learning")]
ENROLLMENTS = [("S1", "C1"), ("S1", "C2"), ("S2", "C1"), ("S2", "C3"), ("S3", "C2")]
SNAME = dict(STUDENTS)
CTITLE = dict(COURSES)

EXPECT_Q1 = ["C1", "C2"]            # courses of Alice
EXPECT_Q2 = ["Alice", "Bob"]        # students in C1
EXPECT_Q3 = ["Bob", "Carol"]        # students sharing a course with Alice


class Checker:
    def __init__(self):
        self.passed = 0
        self.failed = 0

    def check(self, label, ok, detail=""):
        print(f"   [{'PASS' if ok else 'FAIL'}] {label}" + (f" -> {detail}" if detail else ""))
        if ok:
            self.passed += 1
        else:
            self.failed += 1


# --------------------------------------------------------------------------
# 1) MongoDB: document model
# --------------------------------------------------------------------------
def mongo_model(db, ck):
    db.students.insert_many([
        {"_id": sid, "name": name, "course_ids": [c for s, c in ENROLLMENTS if s == sid]}
        for sid, name in STUDENTS])
    db.courses.insert_many([
        {"_id": cid, "title": title,
         "students": [{"student_id": s, "name": SNAME[s]} for s, c in ENROLLMENTS if c == cid]}
        for cid, title in COURSES])
    db.students.create_index("name")
    db.students.create_index("course_ids")          # multikey index on the array
    print("   students (embedded course_ids):", list(db.students.find({}, {"_id": 1, "name": 1, "course_ids": 1})))
    print("   courses  (embedded roster)    :", db.courses.find_one({"_id": "C1"}))

    print("\n   Queries (mongosh equivalents):")
    print("   Q1  db.students.findOne({name:'Alice'}).course_ids")
    print("   Q2  db.courses.findOne({_id:'C1'}).students")
    print("   Q3  db.students.find({name:{$ne:'Alice'}, course_ids:{$in: alice.course_ids}})")
    alice = db.students.find_one({"name": "Alice"})
    q1 = sorted(alice["course_ids"])
    q2 = sorted(s["name"] for s in db.courses.find_one({"_id": "C1"})["students"])
    q3 = sorted(s["name"] for s in db.students.find(
        {"name": {"$ne": "Alice"}, "course_ids": {"$in": alice["course_ids"]}}))
    ck.check("MongoDB Q1 courses of Alice", q1 == EXPECT_Q1, str(q1))
    ck.check("MongoDB Q2 students in C1", q2 == EXPECT_Q2, str(q2))
    ck.check("MongoDB Q3 students sharing a course with Alice", q3 == EXPECT_Q3, str(q3))
    return q1, q2, q3


# --------------------------------------------------------------------------
# 2) Cassandra: query-driven tables
# --------------------------------------------------------------------------
CQL = """
   CREATE TABLE student_courses (
     student_id text, course_id text, student_name text STATIC, course_title text,
     PRIMARY KEY ((student_id), course_id));
   CREATE TABLE course_students (
     course_id text, student_id text, course_title text STATIC, student_name text,
     PRIMARY KEY ((course_id), student_id));
   -- every enrollment is written to BOTH tables (BATCH)
   Q1  SELECT course_id, course_title FROM student_courses WHERE student_id = 'S1';
   Q2  SELECT student_id, student_name FROM course_students WHERE course_id = 'C1';
   Q3  no JOIN in CQL: Q1 for Alice, then Q2 once per course, merged in the application."""


def cassandra_simulated(ck):
    student_courses = {}      # partition key student_id -> {course_id: title}
    course_students = {}      # partition key course_id  -> {student_id: name}
    for s, c in ENROLLMENTS:  # the double write
        student_courses.setdefault(s, {})[c] = CTITLE[c]
        course_students.setdefault(c, {})[s] = SNAME[s]
    reads = 0
    q1 = sorted(student_courses["S1"]); reads += 1
    q2 = sorted(course_students["C1"].values()); reads += 1
    reads = 0
    mine = student_courses["S1"]; reads += 1
    others = set()
    for cid in mine:
        others |= set(course_students[cid].values()); reads += 1
    others.discard("Alice")
    q3 = sorted(others)
    print(f"   Q3 needed {reads} partition reads (1 for Alice + 1 per course) and an application-side merge")
    ck.check("Cassandra Q1 courses of Alice (single partition read)", q1 == EXPECT_Q1, str(q1))
    ck.check("Cassandra Q2 students in C1 (single partition read)", q2 == EXPECT_Q2, str(q2))
    ck.check("Cassandra Q3 students sharing a course with Alice (multi-step)", q3 == EXPECT_Q3, str(q3))
    return q1, q2, q3


def cassandra_real(host, ck):
    from cassandra.cluster import Cluster
    cluster = Cluster([host])
    session = cluster.connect()
    session.execute("DROP KEYSPACE IF EXISTS university_lab")
    session.execute("CREATE KEYSPACE university_lab WITH replication = "
                    "{'class': 'SimpleStrategy', 'replication_factor': 1}")
    session.set_keyspace("university_lab")
    session.execute("CREATE TABLE student_courses (student_id text, course_id text, "
                    "student_name text STATIC, course_title text, PRIMARY KEY ((student_id), course_id))")
    session.execute("CREATE TABLE course_students (course_id text, student_id text, "
                    "course_title text STATIC, student_name text, PRIMARY KEY ((course_id), student_id))")
    for s, c in ENROLLMENTS:
        session.execute("INSERT INTO student_courses (student_id, course_id, student_name, course_title) "
                        "VALUES (%s,%s,%s,%s)", (s, c, SNAME[s], CTITLE[c]))
        session.execute("INSERT INTO course_students (course_id, student_id, course_title, student_name) "
                        "VALUES (%s,%s,%s,%s)", (c, s, CTITLE[c], SNAME[s]))
    q1 = sorted(r.course_id for r in session.execute(
        "SELECT course_id FROM student_courses WHERE student_id='S1'"))
    q2 = sorted(r.student_name for r in session.execute(
        "SELECT student_name FROM course_students WHERE course_id='C1'"))
    others = set()
    for cid in q1:
        others |= {r.student_name for r in session.execute(
            "SELECT student_name FROM course_students WHERE course_id=%s", (cid,))}
    others.discard("Alice")
    q3 = sorted(others)
    session.execute("DROP KEYSPACE university_lab")
    cluster.shutdown()
    ck.check("Cassandra (real server) Q1 courses of Alice", q1 == EXPECT_Q1, str(q1))
    ck.check("Cassandra (real server) Q2 students in C1", q2 == EXPECT_Q2, str(q2))
    ck.check("Cassandra (real server) Q3 shared course (multi-step)", q3 == EXPECT_Q3, str(q3))
    return q1, q2, q3


# --------------------------------------------------------------------------
# 3) Neo4j: graph model
# --------------------------------------------------------------------------
CYPHER = """
   CREATE (alice:Student {name:'Alice'}), (bob:Student {name:'Bob'}), (carol:Student {name:'Carol'})
   CREATE (c1:Course {code:'C1'}), (c2:Course {code:'C2'}), (c3:Course {code:'C3'})
   CREATE (alice)-[:ENROLLED_IN]->(c1), (alice)-[:ENROLLED_IN]->(c2), (bob)-[:ENROLLED_IN]->(c1),
          (bob)-[:ENROLLED_IN]->(c3), (carol)-[:ENROLLED_IN]->(c2)
   Q1  MATCH (s:Student {name:'Alice'})-[:ENROLLED_IN]->(c:Course) RETURN c.code
   Q2  MATCH (s:Student)-[:ENROLLED_IN]->(c:Course {code:'C1'}) RETURN s.name
   Q3  MATCH (s1:Student)-[:ENROLLED_IN]->(c:Course)<-[:ENROLLED_IN]-(s2:Student)
       WHERE s1.name = 'Alice' AND s2.name <> 'Alice' RETURN DISTINCT s2.name"""


def neo4j_simulated(ck):
    edges = [(SNAME[s], c) for s, c in ENROLLMENTS]          # (student name) -[:ENROLLED_IN]-> (course code)
    q1 = sorted(c for s, c in edges if s == "Alice")
    q2 = sorted(s for s, c in edges if c == "C1")
    alice_courses = {c for s, c in edges if s == "Alice"}
    q3 = sorted({s for s, c in edges if c in alice_courses and s != "Alice"})   # one pattern, two hops
    ck.check("Neo4j Q1 courses of Alice (1 hop)", q1 == EXPECT_Q1, str(q1))
    ck.check("Neo4j Q2 students in C1 (1 hop)", q2 == EXPECT_Q2, str(q2))
    ck.check("Neo4j Q3 students sharing a course with Alice (2 hops, one MATCH)", q3 == EXPECT_Q3, str(q3))
    return q1, q2, q3


def neo4j_real(uri, user, password, ck):
    from neo4j import GraphDatabase
    driver = GraphDatabase.driver(uri, auth=(user, password))
    with driver.session() as s:
        s.run("MATCH (n {lab161:true}) DETACH DELETE n")
        for sid, name in STUDENTS:
            s.run("CREATE (:Student {name:$n, lab161:true})", n=name)
        for cid, title in COURSES:
            s.run("CREATE (:Course {code:$c, title:$t, lab161:true})", c=cid, t=title)
        for sid, cid in ENROLLMENTS:
            s.run("MATCH (s:Student {name:$n, lab161:true}), (c:Course {code:$c, lab161:true}) "
                  "CREATE (s)-[:ENROLLED_IN]->(c)", n=SNAME[sid], c=cid)
        q1 = sorted(r["c.code"] for r in s.run(
            "MATCH (s:Student {name:'Alice', lab161:true})-[:ENROLLED_IN]->(c:Course) RETURN c.code"))
        q2 = sorted(r["s.name"] for r in s.run(
            "MATCH (s:Student)-[:ENROLLED_IN]->(c:Course {code:'C1', lab161:true}) RETURN s.name"))
        q3 = sorted(r["s2.name"] for r in s.run(
            "MATCH (s1:Student {lab161:true})-[:ENROLLED_IN]->(c:Course)<-[:ENROLLED_IN]-(s2:Student) "
            "WHERE s1.name = 'Alice' AND s2.name <> 'Alice' RETURN DISTINCT s2.name"))
        s.run("MATCH (n {lab161:true}) DETACH DELETE n")
    driver.close()
    ck.check("Neo4j (real server) Q1 courses of Alice", q1 == EXPECT_Q1, str(q1))
    ck.check("Neo4j (real server) Q2 students in C1", q2 == EXPECT_Q2, str(q2))
    ck.check("Neo4j (real server) Q3 shared course (one MATCH)", q3 == EXPECT_Q3, str(q3))
    return q1, q2, q3


# --------------------------------------------------------------------------
COMPARISON = """
   Query syntax complexity
     Q1 courses of a student   : MongoDB find() on an array | Cassandra SELECT by partition key | Cypher MATCH, 1 hop
     Q2 students in a course   : MongoDB find() on roster   | Cassandra SELECT by partition key | Cypher MATCH, 1 hop
     Q3 students sharing course: MongoDB two steps or $lookup (moderate) | Cassandra no JOIN, application merge
                                 (hardest) | Cypher one pattern (easiest, most elegant)

   Expected performance characteristics
     MongoDB   : Q1/Q2 are single-document reads. Q3 is fast with the multikey index on course_ids;
                 $lookup is costlier. Keeping students.course_ids and courses.students in sync
                 means two writes per enrollment (transaction recommended).
     Cassandra : Q1/Q2 are single-partition reads: the fastest and most predictable of the three, with
                 linear horizontal scale and very high write throughput. Q3 costs 1 + N reads
                 (N = number of courses) and every enrollment is written to 2 tables.
     Neo4j     : Q1/Q2 start at an indexed node and follow relationships. Q3 cost depends on the size of
                 the neighbourhood visited, not on the total data size, so it stays fast as data grows.
                 Writes and horizontal scaling are harder than in Cassandra.

   RULE OF THUMB: MongoDB for general operational data, Cassandra for huge write-heavy known-query
   workloads, Neo4j when the questions are about connections and paths.
"""


def main():
    p = argparse.ArgumentParser(description="Lab 16.1 - model the same data in three databases")
    p.add_argument("--uri", default=os.getenv("MONGO_URI", "mongodb://rsadmin:RsLabPass123@127.0.0.1:27047/?authSource=admin"))
    p.add_argument("--db", default="chapter-16")
    p.add_argument("--cassandra", help="host of a real Cassandra server (optional)")
    p.add_argument("--neo4j-uri", help="bolt URI of a real Neo4j server (optional)")
    p.add_argument("--neo4j-user", default="neo4j")
    p.add_argument("--neo4j-password", default="")
    p.add_argument("--keep", action="store_true", help="do not drop the MongoDB lab database at the end")
    args = p.parse_args()

    client = MongoClient(args.uri, serverSelectionTimeoutMS=8000)
    try:
        client.admin.command("ping")
    except Exception as exc:  # noqa: BLE001
        sys.exit(f"Could not connect to MongoDB: {exc}\nCheck --uri (or MONGO_URI in .env).")
    client.drop_database(args.db)
    db = client[args.db]
    ck = Checker()
    results = {}

    print("1) MongoDB: document model (real server)")
    results["mongo"] = mongo_model(db, ck)

    print("\n2) Cassandra: query-driven table design")
    print(CQL)
    if args.cassandra:
        print("\n   Running on the real Cassandra server ...")
        results["cassandra"] = cassandra_real(args.cassandra, ck)
    else:
        print("\n   No --cassandra given: the two tables are simulated in memory.")
        results["cassandra"] = cassandra_simulated(ck)

    print("\n3) Neo4j: node and relationship model")
    print(CYPHER)
    if args.neo4j_uri:
        print("\n   Running on the real Neo4j server ...")
        results["neo4j"] = neo4j_real(args.neo4j_uri, args.neo4j_user, args.neo4j_password, ck)
    else:
        print("\n   No --neo4j-uri given: the graph is simulated in memory.")
        results["neo4j"] = neo4j_simulated(ck)

    print("\n4) Same answers in all three models")
    ck.check("Q1 identical in MongoDB, Cassandra and Neo4j", len({tuple(r[0]) for r in results.values()}) == 1)
    ck.check("Q2 identical in MongoDB, Cassandra and Neo4j", len({tuple(r[1]) for r in results.values()}) == 1)
    ck.check("Q3 identical in MongoDB, Cassandra and Neo4j", len({tuple(r[2]) for r in results.values()}) == 1)
    print(f"   RESULT: {ck.passed} passed, {ck.failed} failed")

    print("\n5) Comparison")
    print(COMPARISON)

    if not args.keep:
        client.drop_database(args.db)
        print(f"Database '{args.db}' dropped (use --keep to inspect it in Compass).")
    client.close()
    sys.exit(0 if ck.failed == 0 else 1)


if __name__ == "__main__":
    main()
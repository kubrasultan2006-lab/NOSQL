"""
Activity for 16.1 - Try it yourself: hybrid architecture (MongoDB + Cassandra + Neo4j)

  MongoDB   : operational data (students, enrollments) - the single source of truth (real server)
  Cassandra : audit log, append-only, partitioned by (student_id, day), newest first
              (simulated in memory; the CQL table is printed)
  Neo4j     : course prerequisite graph, PREREQUISITE_OF relationships
              (simulated in memory; the Cypher is printed)

Enrollment flow:
  1. read the student's completed courses from MongoDB
  2. ask the graph for the missing prerequisites (transitive chain)
  3. reject, or write the enrollment AND an outbox event to MongoDB
  4. a worker drains the outbox into the Cassandra audit table (no dual write from the API)

Run:
    python "chapter-16\\Activity for 16.1 - Try it yourself.py"

Uses its own MongoDB database (default chapter-16), dropped at the end unless --keep is given.
Requires: pip install pymongo python-dotenv
"""

import argparse
import os
import sys
from datetime import datetime, timezone

from pymongo import MongoClient

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# ---- Neo4j side (simulated): course -> its direct prerequisites ---------------------------------
PREREQ_GRAPH = {"CS101": [], "CS201": ["CS101"], "CS301": ["CS201"], "CS310": ["CS201", "MA101"], "MA101": []}

CYPHER = """   CREATE (:Course {code:'CS101'})-[:PREREQUISITE_OF]->(:Course {code:'CS201'})-[:PREREQUISITE_OF]->(:Course {code:'CS301'})
   MATCH (p:Course)-[:PREREQUISITE_OF*1..]->(c:Course {code:'CS301'}) RETURN DISTINCT p.code"""

CQL = """   CREATE TABLE enrollment_audit (
     student_id text, day date, event_time timeuuid, action text, course_id text, details text,
     PRIMARY KEY ((student_id, day), event_time)) WITH CLUSTERING ORDER BY (event_time DESC);"""


def prerequisite_chain(course):
    """All direct and indirect prerequisites (what the variable-length Cypher path returns)."""
    seen, stack = set(), list(PREREQ_GRAPH.get(course, []))
    while stack:
        c = stack.pop()
        if c not in seen:
            seen.add(c)
            stack.extend(PREREQ_GRAPH.get(c, []))
    return seen


# ---- Cassandra side (simulated) -----------------------------------------------------------------
class AuditTable:
    def __init__(self):
        self.partitions = {}                     # (student_id, day) -> list of rows

    def insert(self, row):
        key = (row["student_id"], row["day"])
        self.partitions.setdefault(key, []).append(row)
        self.partitions[key].sort(key=lambda r: r["event_time"], reverse=True)   # CLUSTERING ORDER BY DESC

    def read(self, student_id, day):
        return list(self.partitions.get((student_id, day), []))


# ---- Service ------------------------------------------------------------------------------------
class Checker:
    def __init__(self):
        self.passed = 0
        self.failed = 0

    def check(self, label, ok, detail=""):
        print(f"   [{'PASS' if ok else 'FAIL'}] {label}" + (f" -> {detail}" if detail else ""))
        if ok:
            self.passed += 1
        else:
            self.failed += 1


def now():
    return datetime.now(timezone.utc)


def enroll(db, student_id, course):
    student = db.students.find_one({"_id": student_id})
    missing = sorted(prerequisite_chain(course) - set(student["completed"]))
    if missing:
        db.outbox.insert_one({"action": "ENROLL_REJECTED", "student_id": student_id, "course_id": course,
                              "details": f"missing {missing}", "event_time": now(), "processed": False})
        return False, missing
    db.enrollments.insert_one({"student_id": student_id, "course_id": course, "created_at": now()})
    db.outbox.insert_one({"action": "ENROLLED", "student_id": student_id, "course_id": course,
                          "details": "ok", "event_time": now(), "processed": False})
    return True, []


def outbox_worker(db, audit):
    """Drain unprocessed outbox events into the audit table, then mark them processed."""
    n = 0
    for ev in db.outbox.find({"processed": False}).sort("event_time", 1):
        audit.insert({"student_id": ev["student_id"], "day": ev["event_time"].date().isoformat(),
                      "event_time": ev["event_time"], "action": ev["action"],
                      "course_id": ev["course_id"], "details": ev["details"]})
        db.outbox.update_one({"_id": ev["_id"]}, {"$set": {"processed": True}})
        n += 1
    return n


def main():
    p = argparse.ArgumentParser(description="Activity for 16.1 - hybrid architecture")
    p.add_argument("--uri", default=os.getenv("MONGO_URI", "mongodb://rsadmin:RsLabPass123@127.0.0.1:27047/?authSource=admin"))
    p.add_argument("--db", default="chapter-16")
    p.add_argument("--keep", action="store_true")
    args = p.parse_args()

    client = MongoClient(args.uri, serverSelectionTimeoutMS=8000)
    try:
        client.admin.command("ping")
    except Exception as exc:  # noqa: BLE001
        sys.exit(f"Could not connect to MongoDB: {exc}\nCheck --uri (or MONGO_URI in .env).")
    client.drop_database(args.db)
    db = client[args.db]
    db.students.insert_one({"_id": "S1", "name": "Alice", "completed": []})
    audit = AuditTable()
    ck = Checker()

    print("1) Architecture")
    print("   MongoDB (operational, source of truth) -> outbox -> worker -> Cassandra (audit log)")
    print("   MongoDB (course catalogue)             -> Neo4j (prerequisite chains)")
    print("\n   Cassandra audit table:\n" + CQL)
    print("\n   Neo4j prerequisite chain:\n" + CYPHER)

    print("\n2) Prerequisite chain from the graph")
    chain = sorted(prerequisite_chain("CS301"))
    ck.check("CS301 needs CS101 and CS201 (indirect prerequisite found)", chain == ["CS101", "CS201"], str(chain))
    chain = sorted(prerequisite_chain("CS310"))
    ck.check("CS310 needs CS101, CS201, MA101", chain == ["CS101", "CS201", "MA101"], str(chain))

    print("\n3) Enrollment checks prerequisites")
    ok, missing = enroll(db, "S1", "CS301")
    ck.check("Alice cannot enroll in CS301 without prerequisites", not ok, f"missing {missing}")
    db.students.update_one({"_id": "S1"}, {"$set": {"completed": ["CS101", "CS201"]}})
    ok, missing = enroll(db, "S1", "CS301")
    ck.check("after completing CS101 and CS201 she can enroll in CS301", ok)
    ck.check("enrollment stored in MongoDB", db.enrollments.count_documents({"student_id": "S1"}) == 1)

    print("\n4) Audit log through the outbox (no direct write from the API)")
    pending = db.outbox.count_documents({"processed": False})
    ck.check("events wait in the MongoDB outbox before the worker runs", pending == 2, f"{pending} pending")
    ck.check("Cassandra audit table is still empty before the worker runs", not audit.partitions)
    moved = outbox_worker(db, audit)
    ck.check("worker moves all events to the audit table", moved == 2 and
             db.outbox.count_documents({"processed": False}) == 0, f"{moved} event(s) moved")
    rows = audit.read("S1", now().date().isoformat())
    ck.check("audit partition (student_id, day) holds both events", len(rows) == 2, f"{len(rows)} row(s)")
    ck.check("newest event is returned first (CLUSTERING ORDER BY DESC)",
             [r["action"] for r in rows] == ["ENROLLED", "ENROLL_REJECTED"], str([r["action"] for r in rows]))
    for r in rows:
        print(f"      {r['event_time'].strftime('%H:%M:%S.%f')} {r['action']:<16} {r['course_id']} {r['details']}")

    print(f"\n   RESULT: {ck.passed} passed, {ck.failed} failed")
    print("""
5) Trade-offs
   + each store does what it is best at; audit writes never slow down enrollment
   + prerequisite checks are one short graph query, whatever the depth of the chain
   + the outbox keeps MongoDB the single source of truth and avoids dual-write inconsistency
   - three systems to run, secure and monitor
   - Cassandra and Neo4j are eventually consistent with MongoDB (the worker lags behind)
   - the worker must be idempotent (events can be delivered twice)
""")
    if not args.keep:
        client.drop_database(args.db)
        print(f"Database '{args.db}' dropped (use --keep to inspect it in Compass).")
    client.close()
    sys.exit(0 if ck.failed == 0 else 1)


if __name__ == "__main__":
    main()
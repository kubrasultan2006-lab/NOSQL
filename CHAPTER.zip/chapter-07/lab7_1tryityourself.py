"""
Activity 7.1: Try it yourself
Redesign one of the referencing relationships as an embedded design.

Relationship chosen : Article -> threat actors  (referenced today via actor_ids)
Decision it supports: "Which source (actor) is an actual threat?"

What this script does
  1. Gives every threat actor a threat verdict (level + actual_threat flag).
  2. Builds a NEW collection, articles_embedded, where each article carries a
     snapshot of its actors (profile + verdict) instead of just their ids.
  3. Runs the same questions against both designs and times them.
  4. Prints the answers to "What gets faster? What gets harder?" as tables.

Run after the seed script:
    python 7_1_Seed_ctidigest.py
    python lab7_1tryityourself.py

Only pymongo is needed. Set MONGO_URI to use a non-default server.
The original collections are not changed, except that threat_actors gains an
"assessment" field (so both designs hold the same verdict).
"""

import os
import statistics
import textwrap
import time
from collections import defaultdict
from datetime import datetime, timedelta, timezone

from pymongo import MongoClient

MONGO_URI = os.environ.get("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = "chapter-07"
LIMIT_BYTES = 16 * 1024 * 1024  # 16 MB
RECENT_DAYS = 90                # window used to judge "actual threat"
RUNS = 7                        # timing runs per query (median is reported)


# ---------------------------------------------------------------------------
# Table printer (same grid style as the Lab 6.2 output)
# ---------------------------------------------------------------------------
def print_table(headers, rows, max_widths=None, align=None):
    n = len(headers)
    max_widths = max_widths or [40] * n
    align = align or ["<"] * n

    def wrap(cell, width):
        return textwrap.wrap(str(cell), width) or [""]

    head = [wrap(h, max_widths[i]) for i, h in enumerate(headers)]
    body = [[wrap(c, max_widths[i]) for i, c in enumerate(r)] for r in rows]
    widths = [
        max(len(line) for line in head[i] + [ln for r in body for ln in r[i]])
        for i in range(n)
    ]

    def border(left, mid, right):
        return left + mid.join("─" * (w + 2) for w in widths) + right

    def render(cells, aligns):
        height = max(len(c) for c in cells)
        lines = []
        for k in range(height):
            parts = []
            for i, c in enumerate(cells):
                text = c[k] if k < len(c) else ""
                parts.append(" " + format(text, f"{aligns[i]}{widths[i]}") + " ")
            lines.append("│" + "│".join(parts) + "│")
        return lines

    out = [border("┌", "┬", "┐")]
    out += render(head, ["<"] * n)
    for r in body:
        out.append(border("├", "┼", "┤"))
        out += render(r, align)
    out.append(border("└", "┴", "┘"))
    print("\n".join(out))


def heading(text):
    print(f"\n=== {text} ===")


# ---------------------------------------------------------------------------
# Timing helpers
# ---------------------------------------------------------------------------
def median_ms(fn, runs=RUNS):
    fn()  # warm-up run, not timed
    times = []
    for _ in range(runs):
        t0 = time.perf_counter()
        fn()
        times.append((time.perf_counter() - t0) * 1000)
    return statistics.median(times)


def compare(ref_ms, emb_ms):
    if emb_ms <= ref_ms:
        return f"Embedded {ref_ms / emb_ms:.1f}x faster" if emb_ms else "Embedded faster"
    return f"Referenced {emb_ms / ref_ms:.1f}x faster"


# ---------------------------------------------------------------------------
# Step 1: decide which actors are an "actual threat"
#   score = articles in the last 90 days + 3 x articles tied to a CVE that is
#           exploited in the wild.  Top quarter = high, upper half = medium,
#           the rest = low.  actual_threat = level is high or medium.
# ---------------------------------------------------------------------------
def build_assessments(db):
    cutoff = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(days=RECENT_DAYS)
    exploited = {v["cve_id"] for v in db.vulnerabilities.find({"exploited_in_wild": True}, {"cve_id": 1})}

    recent = defaultdict(int)
    linked = defaultdict(int)
    for art in db.articles.find({}, {"published": 1, "actor_ids": 1, "cve_ids": 1}):
        published = art["published"].replace(tzinfo=None)
        has_exploited = any(c in exploited for c in art["cve_ids"])
        for aid in art["actor_ids"]:
            if published >= cutoff:
                recent[aid] += 1
            if has_exploited:
                linked[aid] += 1

    actor_ids = [a["_id"] for a in db.threat_actors.find({}, {"_id": 1})]
    scores = {aid: recent[aid] + 3 * linked[aid] for aid in actor_ids}
    ordered = sorted(scores.values())
    median = ordered[len(ordered) // 2]
    p75 = ordered[(len(ordered) * 3) // 4]

    assessed_at = datetime.now(timezone.utc)
    result = {}
    for aid, score in scores.items():
        level = "high" if score >= p75 else "medium" if score >= median else "low"
        result[aid] = {
            "score": score,
            "threat_level": level,
            "actual_threat": level != "low",
            "assessed_at": assessed_at,
        }
    return result


# ---------------------------------------------------------------------------
# Step 2: build the embedded design
# ---------------------------------------------------------------------------
def build_embedded(db, assessments):
    for aid, a in assessments.items():           # referenced design gets the verdict too
        db.threat_actors.update_one({"_id": aid}, {"$set": {"assessment": a}})

    db.articles_embedded.drop()
    actor_docs = {a["_id"]: a for a in db.threat_actors.find()}

    batch = []
    for art in db.articles.find():
        emb = dict(art)
        ids = emb.pop("actor_ids")               # the reference is replaced ...
        emb["actors"] = [                        # ... by an embedded snapshot
            {
                "actor_id": aid,                 # kept so the master record can still be found
                "name": actor_docs[aid]["name"],
                "aliases": actor_docs[aid]["aliases"],
                "country": actor_docs[aid]["country"],
                "motivation": actor_docs[aid]["motivation"],
                "ttps": actor_docs[aid]["ttps"],
                "assessment": dict(assessments[aid]),
            }
            for aid in ids
        ]
        batch.append(emb)
    db.articles_embedded.insert_many(batch)

    db.articles_embedded.create_index("actors.assessment.actual_threat")
    db.articles_embedded.create_index("actors.actor_id")
    db.threat_actors.create_index("assessment.actual_threat")


# ---------------------------------------------------------------------------
# Step 3: the queries, once per design
# ---------------------------------------------------------------------------
def make_queries(db):
    # Q1: articles together with actor names and threat level
    def q1_ref():
        return list(db.articles.aggregate([
            {"$lookup": {"from": "threat_actors", "localField": "actor_ids",
                         "foreignField": "_id", "as": "actors"}},
            {"$project": {"title": 1, "actors.name": 1, "actors.assessment.threat_level": 1}},
        ]))

    def q1_emb():
        return list(db.articles_embedded.find(
            {}, {"title": 1, "actors.name": 1, "actors.assessment.threat_level": 1}))

    # Q2: articles that involve an actual threat (the decision in the activity)
    def q2_ref():
        ids = [a["_id"] for a in db.threat_actors.find({"assessment.actual_threat": True}, {"_id": 1})]
        return list(db.articles.find({"actor_ids": {"$in": ids}}, {"title": 1}))

    def q2_emb():
        return list(db.articles_embedded.find({"actors.assessment.actual_threat": True}, {"title": 1}))

    # Q4: list every actor once
    def q4_ref():
        return list(db.threat_actors.find({}, {"name": 1}))

    def q4_emb():
        return list(db.articles_embedded.aggregate([
            {"$unwind": "$actors"},
            {"$group": {"_id": "$actors.actor_id", "name": {"$first": "$actors.name"}}},
        ]))

    return q1_ref, q1_emb, q2_ref, q2_emb, q4_ref, q4_emb


# Q3: change one actor's threat level (timed with a unique value each run)
def time_update(db, actor_id):
    original = db.threat_actors.find_one({"_id": actor_id})["assessment"]["threat_level"]

    ref_times, emb_times = [], []
    ref_modified = emb_modified = 0
    for i in range(RUNS):
        value = f"test-{i}"

        t0 = time.perf_counter()
        r = db.threat_actors.update_one({"_id": actor_id}, {"$set": {"assessment.threat_level": value}})
        ref_times.append((time.perf_counter() - t0) * 1000)
        ref_modified = r.modified_count

        t0 = time.perf_counter()
        r = db.articles_embedded.update_many(
            {"actors.actor_id": actor_id},
            {"$set": {"actors.$[a].assessment.threat_level": value}},
            array_filters=[{"a.actor_id": actor_id}],
        )
        emb_times.append((time.perf_counter() - t0) * 1000)
        emb_modified = r.modified_count

    # restore the real value in both designs
    db.threat_actors.update_one({"_id": actor_id}, {"$set": {"assessment.threat_level": original}})
    db.articles_embedded.update_many(
        {"actors.actor_id": actor_id},
        {"$set": {"actors.$[a].assessment.threat_level": original}},
        array_filters=[{"a.actor_id": actor_id}],
    )
    return statistics.median(ref_times), statistics.median(emb_times), ref_modified, emb_modified


def size_stats(db, coll):
    return list(db[coll].aggregate([
        {"$project": {"size": {"$bsonSize": "$$ROOT"}}},
        {"$group": {"_id": None, "count": {"$sum": 1}, "avg": {"$avg": "$size"},
                    "max": {"$max": "$size"}, "total": {"$sum": "$size"}}},
    ]))[0]


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)
    db = client[DB_NAME]

    if db.articles.estimated_document_count() == 0:
        print("No data found. Run 7_1_Seed_ctidigest.py first.")
        return

    assessments = build_assessments(db)
    build_embedded(db, assessments)

    # ----- Design comparison -----
    heading("Activity 7.1: Article -> threat actors, referenced vs embedded")
    print_table(
        ["Design", "Collections read to show an article", "What an article stores about its actors"],
        [
            ["Referenced (original)", "articles + threat_actors",
             "actor_ids: [ ObjectId(...), ... ]   (verdict lives only in threat_actors)"],
            ["Embedded (redesign)", "articles_embedded only",
             "actors: [ { actor_id, name, aliases, country, motivation, ttps, "
             "assessment: { threat_level, score, actual_threat, assessed_at } } ]"],
        ],
        max_widths=[22, 36, 70],
    )

    n_actual = sum(1 for a in assessments.values() if a["actual_threat"])
    print(f"\nVerdict rule: score = articles in last {RECENT_DAYS} days + 3 x articles tied to an "
          f"exploited-in-the-wild CVE.")
    names = {a["_id"]: a["name"] for a in db.threat_actors.find({}, {"name": 1})}
    print_table(
        ["Actor", "Score", "Threat level", "Actual threat?"],
        [[names[aid], a["score"], a["threat_level"], "YES" if a["actual_threat"] else "no"]
         for aid, a in sorted(assessments.items(), key=lambda x: -x[1]["score"])],
        max_widths=[20, 7, 13, 15],
        align=["<", ">", "<", "<"],
    )
    print(f"{n_actual} of {len(assessments)} actors are classed as an actual threat.")

    # ----- Timings -----
    q1_ref, q1_emb, q2_ref, q2_emb, q4_ref, q4_emb = make_queries(db)

    q2_same = len(q2_ref()) == len(q2_emb())
    t1r, t1e = median_ms(q1_ref), median_ms(q1_emb)
    t2r, t2e = median_ms(q2_ref), median_ms(q2_emb)
    t4r, t4e = median_ms(q4_ref), median_ms(q4_emb)

    target = db.threat_actors.find_one({"name": "Lazarus Group"})["_id"]
    t3r, t3e, mod_r, mod_e = time_update(db, target)

    heading(f"Measured: same questions on both designs (median of {RUNS} runs, milliseconds)")
    print_table(
        ["Query", "Referenced", "Embedded", "Result"],
        [
            ["Q1  Show every article with its actors' names and threat level",
             f"{t1r:.2f}", f"{t1e:.2f}", compare(t1r, t1e)],
            ["Q2  Find articles that involve an actual-threat actor",
             f"{t2r:.2f}", f"{t2e:.2f}", compare(t2r, t2e)],
            ["Q3  Change one actor's threat level",
             f"{t3r:.2f}", f"{t3e:.2f}", compare(t3r, t3e)],
            ["Q4  List every actor once",
             f"{t4r:.2f}", f"{t4e:.2f}", compare(t4r, t4e)],
        ],
        max_widths=[62, 11, 10, 28],
        align=["<", ">", ">", "<"],
    )
    print(f"Q2 returned the same articles in both designs: {'yes' if q2_same else 'NO - check data'}")
    print("Timings on a small dataset are only indicative; the shape of the result matters more "
          "than the exact numbers. Try N_ARTICLES = 50000 in the seed script to see the gap grow.")

    # ----- Cost of the redesign -----
    s_ref = size_stats(db, "articles")
    s_emb = size_stats(db, "articles_embedded")
    extra = s_emb["avg"] - s_ref["avg"]

    heading("Cost of the redesign")
    print_table(
        ["Measure", "Referenced", "Embedded", "Difference"],
        [
            ["Avg article size (bytes)", f"{s_ref['avg']:.0f}", f"{s_emb['avg']:.0f}",
             f"+{extra:.0f} ({extra / s_ref['avg'] * 100:.1f}%)"],
            ["Largest article (bytes)", f"{s_ref['max']:,}", f"{s_emb['max']:,}",
             f"{s_emb['max'] / LIMIT_BYTES * 100:.4f}% of 16 MB"],
            ["Total articles storage (bytes)", f"{s_ref['total']:,}", f"{s_emb['total']:,}",
             f"+{s_emb['total'] - s_ref['total']:,}"],
            ["Documents written to change ONE actor", f"{mod_r}", f"{mod_e}",
             f"{mod_e}x more writes"],
        ],
        max_widths=[40, 14, 14, 24],
        align=["<", ">", ">", "<"],
    )

    # ----- Written answers -----
    heading("Answers to the activity questions")
    print_table(
        ["Question", "Answer"],
        [
            ["Which queries become faster?",
             "1) Reading an article with its actors and their threat verdict: one document read, no $lookup "
             f"(Q1: {t1r:.2f} ms -> {t1e:.2f} ms).  "
             "2) Deciding which articles involve an actual threat: a single indexed filter on "
             "actors.assessment.actual_threat, instead of finding actors first and then articles "
             f"(Q2: {t2r:.2f} ms -> {t2e:.2f} ms).  "
             "3) Any article page or alert that must show 'who is behind this and how dangerous are they' "
             "in one round trip."],
            ["What becomes harder?",
             f"1) Updating an actor: changing one verdict now rewrites {mod_e} article documents instead of "
             f"{mod_r} (Q3: {t3r:.2f} ms -> {t3e:.2f} ms), and a half-finished update leaves articles disagreeing.  "
             f"2) Duplication: each article grows by about {extra:.0f} bytes ({extra / s_ref['avg'] * 100:.1f}%) "
             "and the same actor profile is stored many times.  "
             f"3) Listing actors once needs $unwind + $group over every article (Q4: {t4r:.2f} ms -> {t4e:.2f} ms).  "
             "4) Stale data: an embedded verdict is a snapshot, so it can be out of date unless assessed_at is "
             "checked or the copies are refreshed."],
            ["Is the 16 MB limit a risk?",
             f"Not here: the largest embedded article is {s_emb['max']:,} bytes. It would only matter if an "
             "article could list thousands of actors (unbounded arrays)."],
            ["Recommendation",
             "Use a hybrid (extended reference): embed only the small fields that are read with every article "
             "and rarely change (name, country, threat_level, assessed_at) and keep the full actor profile in "
             "threat_actors. Choose embedding when reads of the verdict far outnumber updates to it."],
        ],
        max_widths=[28, 110],
    )

    client.close()


if __name__ == "__main__":
    main()
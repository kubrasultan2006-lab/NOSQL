"""
Lab 7.2: Working Set Analysis
Objective: estimate the working set of a dataset and evaluate cache fit.

Steps (as in the lab sheet)
  1. Insert 100,000 documents of about 2 KB each into a test collection.
  2. Use serverStatus to read the WiredTiger cache size and how much data is in cache.
  3. Run random reads across the whole collection and watch the cache hit ratio
     change over time.

Setup:  pip install pymongo
Run:    python lab7_2workingsetanalysis.py

Useful options
  --cache-mb 100   shrink the WiredTiger cache while the lab runs (self-managed mongod only),
                   so the working set no longer fits and you can see misses and evictions.
                   The original size is restored at the end.
  --reload         rebuild the 100,000 documents even if the collection already exists.
  --rounds 20      number of read rounds (one hit-ratio sample per round).
  --reads 5000     random reads per round.
  --cleanup        drop the test collection when finished.

Tip for a true cold start: after the insert step, restart mongod, then run the script
again (it reuses the existing collection). The first rounds then show many cache misses.

The documents are synthetic, shaped like annual security-report records. The dataset
URL in the lab sheet is only a theme; no download is needed.
"""

import argparse
import os
import random
import time
from datetime import datetime, timezone

import bson
from pymongo import MongoClient
from pymongo.errors import OperationFailure

import textwrap

MONGO_URI = os.environ.get("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = "chapter-07"
COLL_NAME = "docs_2kb"
DOC_BYTES = 2048          # target BSON size per document (about 2 KB)
BATCH = 5000
MB = 1024 * 1024


# ---------------------------------------------------------------------------
# Table printer (same grid style as the earlier labs)
# ---------------------------------------------------------------------------
def print_table(headers, rows, max_widths=None, align=None):
    n = len(headers)
    max_widths = max_widths or [40] * n
    align = align or ["<"] * n

    def wrap(cell, width):
        return textwrap.wrap(str(cell), width) or [""]

    head = [wrap(h, max_widths[i]) for i, h in enumerate(headers)]
    body = [[wrap(c, max_widths[i]) for i, c in enumerate(r)] for r in rows]
    widths = [
        max(len(line) for line in head[i] + [ln for r in body for ln in r[i]])
        for i in range(n)
    ]

    def border(left, mid, right):
        return left + mid.join("─" * (w + 2) for w in widths) + right

    def render(cells, aligns):
        height = max(len(c) for c in cells)
        lines = []
        for k in range(height):
            parts = []
            for i, c in enumerate(cells):
                text = c[k] if k < len(c) else ""
                parts.append(" " + format(text, f"{aligns[i]}{widths[i]}") + " ")
            lines.append("│" + "│".join(parts) + "│")
        return lines

    out = [border("┌", "┬", "┐")]
    out += render(head, ["<"] * n)
    for r in body:
        out.append(border("├", "┼", "┤"))
        out += render(r, align)
    out.append(border("└", "┴", "┘"))
    print("\n".join(out))


def heading(text):
    print(f"\n=== {text} ===")


def mb(b):
    return f"{b / MB:,.1f} MB"


def bar(fraction, width=20):
    fraction = max(0.0, min(1.0, fraction))
    filled = round(fraction * width)
    return "█" * filled + "·" * (width - filled)


# ---------------------------------------------------------------------------
# Step 1: build ~2 KB documents
# ---------------------------------------------------------------------------
VENDORS = ["CrowdStrike", "Mandiant", "Verizon", "IBM", "Microsoft", "Palo Alto Networks",
           "Sophos", "Check Point", "Fortinet", "Cisco Talos", "Google", "Kaspersky"]
SECTORS = ["healthcare", "finance", "energy", "government", "education", "retail", "manufacturing"]
TAGS = ["ransomware", "phishing", "zero-day", "supply-chain", "cloud", "ics", "identity", "botnet"]


def make_doc(i, rng):
    doc = {
        "_id": i,
        "vendor": rng.choice(VENDORS),
        "year": rng.randint(2015, 2026),
        "sector": rng.choice(SECTORS),
        "title": f"Annual security report {i:06d}",
        "tags": rng.sample(TAGS, 3),
        "pages": rng.randint(20, 220),
        "published": datetime(2026, 1, 1, tzinfo=timezone.utc),
        "payload": "",
    }
    # An empty string already costs 5 bytes in BSON; every extra character costs 1 byte,
    # so padding the payload lands the document on the target size.
    pad = DOC_BYTES - len(bson.encode(doc))
    doc["payload"] = os.urandom((pad + 1) // 2).hex()[:pad]
    return doc


def insert_documents(coll, n_docs):
    rng = random.Random(7)
    coll.drop()
    t0 = time.perf_counter()
    batch = []
    for i in range(n_docs):
        batch.append(make_doc(i, rng))
        if len(batch) == BATCH:
            coll.insert_many(batch, ordered=False)
            batch = []
    if batch:
        coll.insert_many(batch, ordered=False)
    return time.perf_counter() - t0


# ---------------------------------------------------------------------------
# Step 2: serverStatus / collStats helpers
# ---------------------------------------------------------------------------
def cache_stats(client):
    return client.admin.command("serverStatus")["wiredTiger"]["cache"]


def snapshot(client, db):
    c = cache_stats(client)
    s = db.command("collStats", COLL_NAME)
    wt_cache = s.get("wiredTiger", {}).get("cache", {})
    return {
        "max": c["maximum bytes configured"],
        "in_cache": c["bytes currently in the cache"],
        "dirty": c.get("tracked dirty bytes in the cache", 0),
        "data": s["size"],
        "storage": s["storageSize"],
        "indexes": s["totalIndexSize"],
        "coll_cache": wt_cache.get("bytes currently in the cache", 0),
        "avg_obj": s.get("avgObjSize", 0),
        "count": s["count"],
    }


def set_cache_mb(client, size_mb):
    client.admin.command({"setParameter": 1, "wiredTigerEngineRuntimeConfig": f"cache_size={size_mb}MB"})


def evictions(c):
    return c.get("unmodified pages evicted", 0) + c.get("modified pages evicted", 0)


# ---------------------------------------------------------------------------
# Step 3: random reads with a hit ratio sample after every round
# ---------------------------------------------------------------------------
def random_reads(client, coll, n_docs, rounds, reads):
    rng = random.Random(123)
    rows = []
    samples = []
    prev = cache_stats(client)
    first = prev
    read_total = 0
    for r in range(1, rounds + 1):
        t0 = time.perf_counter()
        for _ in range(reads):
            coll.find_one({"_id": rng.randrange(n_docs)})
        elapsed = time.perf_counter() - t0
        read_total += reads

        cur = cache_stats(client)
        requested = cur["pages requested from the cache"] - prev["pages requested from the cache"]
        misses = cur["pages read into cache"] - prev["pages read into cache"]
        ratio = max(0.0, min(1.0, 1 - misses / requested)) if requested else 1.0
        samples.append(ratio)
        rows.append([
            r, f"{read_total:,}", f"{requested:,}", f"{misses:,}",
            f"{ratio * 100:.2f}%", bar(ratio),
            f"{cur['bytes currently in the cache'] / cur['maximum bytes configured'] * 100:.1f}%",
            f"{evictions(cur) - evictions(prev):,}",
            f"{elapsed / reads * 1000:.3f}",
        ])
        prev = cur
        print(f"\r  reading... round {r}/{rounds}", end="", flush=True)
    print()
    disk_bytes = prev["bytes read into cache"] - first["bytes read into cache"]
    return rows, samples, disk_bytes


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser(description="Lab 7.2 Working Set Analysis")
    ap.add_argument("--docs", type=int, default=100_000)
    ap.add_argument("--rounds", type=int, default=20)
    ap.add_argument("--reads", type=int, default=5000)
    ap.add_argument("--cache-mb", type=int, default=None)
    ap.add_argument("--reload", action="store_true")
    ap.add_argument("--cleanup", action="store_true")
    args = ap.parse_args()

    client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)
    db = client[DB_NAME]
    coll = db[COLL_NAME]

    try:
        original_max = cache_stats(client)["maximum bytes configured"]
    except (KeyError, OperationFailure) as exc:
        print("This lab needs the WiredTiger cache section of serverStatus "
              f"(self-managed mongod, or a cluster tier that allows serverStatus): {exc}")
        return

    cache_changed = False
    try:
        if args.cache_mb:
            try:
                set_cache_mb(client, args.cache_mb)
                cache_changed = True
                print(f"WiredTiger cache set to {args.cache_mb} MB for this run "
                      f"(original: {mb(original_max)}, restored at the end).")
            except OperationFailure as exc:
                print(f"Could not change the cache size here ({exc.details.get('errmsg', exc)}). "
                      "Continuing with the existing cache size.")

        # ----- Step 1 -----
        heading("Step 1: Insert 100,000 documents of about 2 KB")
        existing = coll.estimated_document_count()
        if existing == args.docs and not args.reload:
            print(f"Collection already holds {existing:,} documents; reusing it (use --reload to rebuild).")
        else:
            print(f"Inserting {args.docs:,} documents ...")
            secs = insert_documents(coll, args.docs)
            print(f"Inserted {args.docs:,} documents in {secs:.1f} s ({args.docs / secs:,.0f} docs/s).")

        after_insert = snapshot(client, db)
        sizes = [len(bson.encode(d)) for d in coll.aggregate([{"$sample": {"size": 200}}])]
        print_table(
            ["Check", "Value"],
            [
                ["Documents in collection", f"{after_insert['count']:,}"],
                ["Average document size (collStats avgObjSize)", f"{after_insert['avg_obj']:,} bytes"],
                ["Sample of 200 docs: min / max BSON size", f"{min(sizes):,} / {max(sizes):,} bytes"],
                ["Target size", f"{DOC_BYTES:,} bytes (about 2 KB)"],
            ],
            max_widths=[48, 34],
        )

        # ----- Step 3 (run before the final snapshot so the table can compare) -----
        rounds_rows, samples, disk_bytes = random_reads(client, coll, args.docs, args.rounds, args.reads)
        after_reads = snapshot(client, db)

        # ----- Step 2 output -----
        heading("Step 2: WiredTiger cache from serverStatus")
        rows = []

        def add(label, key, as_pct_of=None):
            a, b = after_insert[key], after_reads[key]
            if as_pct_of:
                rows.append([label, f"{a / after_insert[as_pct_of] * 100:.1f}%",
                             f"{b / after_reads[as_pct_of] * 100:.1f}%"])
            else:
                rows.append([label, mb(a), mb(b)])

        add("Maximum cache size (cache configured)", "max")
        add("Bytes currently in the cache", "in_cache")
        add("Cache fill (% of maximum)", "in_cache", as_pct_of="max")
        add("Dirty bytes in the cache", "dirty")
        add("Collection data size (uncompressed)", "data")
        add("Collection storage size on disk (compressed)", "storage")
        add("Index size (_id index)", "indexes")
        add("Collection bytes in cache", "coll_cache")
        add("Collection data in cache (% of data size)", "coll_cache", as_pct_of="data")
        print_table(
            ["Metric", "After insert", "After random reads"],
            rows,
            max_widths=[48, 16, 20],
            align=["<", ">", ">"],
        )

        # ----- Step 3 output -----
        heading(f"Step 3: Random reads across the whole collection "
                f"({args.rounds} rounds x {args.reads:,} reads)")
        print_table(
            ["Round", "Reads so far", "Pages requested", "Pages read from disk",
             "Hit ratio", "Hit ratio bar", "Cache fill", "Pages evicted", "Avg read (ms)"],
            rounds_rows,
            max_widths=[6, 13, 16, 20, 10, 20, 10, 13, 13],
            align=[">", ">", ">", ">", ">", "<", ">", ">", ">"],
        )

        # ----- Cache fit evaluation -----
        working_set = after_reads["data"] + after_reads["indexes"]
        cache_max = after_reads["max"]
        share = working_set / cache_max
        verdict = ("FITS in cache (at or below 80%)" if share <= 0.80 else
                   "BORDERLINE (80% to 100%)" if share <= 1.0 else
                   "DOES NOT FIT in cache")
        first_ratio = samples[0]
        last_ratio = sum(samples[-3:]) / len(samples[-3:])

        heading("Cache fit evaluation")
        print_table(
            ["Measure", "Value"],
            [
                ["Estimated working set (data + indexes; random reads touch every document)",
                 mb(working_set)],
                ["WiredTiger cache size", mb(cache_max)],
                ["Working set as % of cache", f"{share * 100:.1f}%"],
                ["Verdict", verdict],
                ["Hit ratio, first round", f"{first_ratio * 100:.2f}%"],
                ["Hit ratio, last 3 rounds (average)", f"{last_ratio * 100:.2f}%"],
                ["Data read from disk into cache during the reads", mb(disk_bytes)],
            ],
            max_widths=[66, 34],
        )

        # ----- Observations -----
        if first_ratio >= 0.99:
            trend = ("The hit ratio is already about 100% in round 1: the inserts left the collection in "
                     "the cache, so almost every read is served from memory.")
        elif last_ratio > first_ratio + 0.01:
            trend = (f"The hit ratio climbs from {first_ratio * 100:.1f}% to {last_ratio * 100:.1f}%: early "
                     "reads fault pages in from disk (misses) and later reads find them already cached.")
        else:
            trend = (f"The hit ratio stays near {last_ratio * 100:.1f}% and does not reach 100%: reads keep "
                     "evicting pages that are needed again soon.")

        if share <= 0.80:
            fit = ("The working set fits comfortably, so once warm almost nothing is read from disk and "
                   "latency is steady.")
        elif share <= 1.0:
            fit = ("The working set is close to the cache size, so eviction starts to compete with reads and "
                   "a small growth in data could push hit ratio down.")
        else:
            fit = ("The working set is larger than the cache, so some reads must always go to disk; hit ratio "
                   "settles near the share of the working set that fits.")

        heading("Observations")
        print_table(
            ["Topic", "What the numbers show"],
            [
                ["Hit ratio over time", trend],
                ["Cache fit", fit],
                ["Why random reads matter",
                 "Random reads give every document an equal chance of being read, so the working set is the "
                 "whole collection. A workload that mostly reads recent or popular documents has a much "
                 "smaller working set and caches well even when the dataset is large."],
                ["What to try next",
                 "Re-run with --cache-mb 100 (working set larger than cache) to see lower hit ratios, "
                 "evictions and slower reads, or restart mongod before running to see a cold start."],
            ],
            max_widths=[26, 110],
        )

        if args.cleanup:
            coll.drop()   # only this lab's collection: chapter-07 is shared with the other Chapter 7 labs
            print(f"\nDropped collection {DB_NAME}.{COLL_NAME}.")
    finally:
        if cache_changed:
            try:
                set_cache_mb(client, max(1, original_max // MB))
                print(f"\nWiredTiger cache restored to {mb(original_max)}.")
            except OperationFailure as exc:
                print(f"\nCould not restore the cache size automatically ({exc}). "
                      f"Set it back to {mb(original_max)} manually.")
        client.close()


if __name__ == "__main__":
    main()
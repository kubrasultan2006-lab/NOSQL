"""
Activity 7.2: Try it yourself
Research the WiredTiger metrics in db.serverStatus() and build a simple monitoring script
that reports the cache hit ratio every 10 seconds.

What the script does every cycle (10 seconds by default)
  1. BROWSE   : reads the awesome-annual-security-reports list (threat / security reports).
  2. COMPARE  : checks which reports are not in the database yet.
  3. STORE    : inserts the new reports into threat_monitor.reports.
  4. MEASURE  : reads db.serverStatus() and prints the WiredTiger cache hit ratio for the
                interval that just ended, plus cache fill, disk reads and evictions.

Setup:  pip install pymongo
Run:    python lab7_2tryityourself.py          (stop with Ctrl+C; a summary is printed)

Options
  --interval 10        seconds between samples
  --cycles 0           stop after N cycles (0 = run until Ctrl+C)
  --source URL|FILE    where the report list comes from (default: raw README on GitHub;
                       a local .md file also works, handy when you are offline)
  --simulate-new 3     hold back the 3 newest reports at first and "discover" one more each
                       cycle, so you can watch new reports being detected and stored
  --reset              empty the reports collection before starting
  --csv monitor.csv    also append every sample to a CSV file (for graphing later)

Hit ratio = (pages requested - pages read into cache) / pages requested, using the CHANGE
between two samples. Totals since server start would hide what is happening right now.
The ratio is server-wide, so it also includes the server's own background activity.
"""

import argparse
import csv
import os
import re
import textwrap
import time
import urllib.error
import urllib.request
from collections import deque
from datetime import datetime, timezone

from pymongo import ASCENDING, MongoClient
from pymongo.errors import BulkWriteError, OperationFailure

MONGO_URI = os.environ.get("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = "chapter-07"
COLL_NAME = "reports"
DEFAULT_SOURCE = ("https://raw.githubusercontent.com/jacobdjwilson/"
                  "awesome-annual-security-reports/main/README.md")
MB = 1024 * 1024

# One README entry:  - [Vendor](url) - [Report title](pdf-url) (2025) - Description.
ENTRY_RE = re.compile(
    r"^\s*[-*]\s*\[(?P<vendor>[^\]]+)\]\((?P<vendor_url>[^)\s]+)\)\s*[-–—]\s*"
    r"\[(?P<title>[^\]]+)\]\((?P<url>[^)\s]+)\)\s*\((?P<year>\d{4})\)\s*[-–—]?\s*(?P<desc>.*)$"
)


# ---------------------------------------------------------------------------
# Table printer for the fixed tables (research table and summary)
# ---------------------------------------------------------------------------
def print_table(headers, rows, max_widths=None, align=None):
    n = len(headers)
    max_widths = max_widths or [40] * n
    align = align or ["<"] * n

    def wrap(cell, width):
        return textwrap.wrap(str(cell), width) or [""]

    head = [wrap(h, max_widths[i]) for i, h in enumerate(headers)]
    body = [[wrap(c, max_widths[i]) for i, c in enumerate(r)] for r in rows]
    widths = [
        max(len(line) for line in head[i] + [ln for r in body for ln in r[i]])
        for i in range(n)
    ]

    def border(left, mid, right):
        return left + mid.join("─" * (w + 2) for w in widths) + right

    def render(cells, aligns):
        height = max(len(c) for c in cells)
        lines = []
        for k in range(height):
            parts = []
            for i, c in enumerate(cells):
                text = c[k] if k < len(c) else ""
                parts.append(" " + format(text, f"{aligns[i]}{widths[i]}") + " ")
            lines.append("│" + "│".join(parts) + "│")
        return lines

    out = [border("┌", "┬", "┐")]
    out += render(head, ["<"] * n)
    for r in body:
        out.append(border("├", "┼", "┤"))
        out += render(r, align)
    out.append(border("└", "┴", "┘"))
    print("\n".join(out))


def heading(text):
    print(f"\n=== {text} ===")


# ---------------------------------------------------------------------------
# Live table (rows are printed as they are measured)
# ---------------------------------------------------------------------------
COLS = [
    ("Time", 8, "<"), ("At source", 9, ">"), ("New", 4, ">"), ("In DB", 6, ">"),
    ("Hit ratio", 9, ">"), ("Hit ratio bar", 13, "<"), ("Cache fill", 10, ">"),
    ("Disk pages", 10, ">"), ("Evicted", 8, ">"), ("Check ms", 8, ">"),
]
INNER = sum(w + 2 for _, w, _ in COLS) + len(COLS) - 1


def live_border(left, mid, right):
    return left + mid.join("─" * (w + 2) for _, w, _ in COLS) + right


def live_row(values):
    cells = [" " + format(str(v), f"{a}{w}") + " " for v, (_, w, a) in zip(values, COLS)]
    return "│" + "│".join(cells) + "│"


def live_span(text):
    room = INNER - 2
    if len(text) > room:
        text = text[: room - 1] + "…"
    return "│ " + text.ljust(room) + " │"


def print_live_header():
    print(live_border("┌", "┬", "┐"))
    print(live_row([c[0] for c in COLS]))
    print(live_border("├", "┼", "┤"))


def bar(fraction, width=12):
    if fraction is None:
        return "·" * width
    fraction = max(0.0, min(1.0, fraction))
    filled = round(fraction * width)
    return "█" * filled + "·" * (width - filled)


# ---------------------------------------------------------------------------
# WiredTiger metrics from db.serverStatus()
# ---------------------------------------------------------------------------
def read_cache(client):
    ss = client.admin.command("serverStatus")
    wt = ss["wiredTiger"]
    c = wt["cache"]
    tickets = wt.get("concurrentTransactions", {})
    return {
        "requested": c["pages requested from the cache"],
        "read_in": c["pages read into cache"],
        "bytes_read_in": c.get("bytes read into cache", 0),
        "in_cache": c["bytes currently in the cache"],
        "max": c["maximum bytes configured"],
        "dirty": c.get("tracked dirty bytes in the cache", 0),
        "evicted": c.get("unmodified pages evicted", 0) + c.get("modified pages evicted", 0),
        "read_tickets_out": tickets.get("read", {}).get("out"),
        "write_tickets_out": tickets.get("write", {}).get("out"),
    }


def interval_ratio(prev, cur):
    """Hit ratio for the time between two samples (None if the cache was not used)."""
    requested = cur["requested"] - prev["requested"]
    misses = cur["read_in"] - prev["read_in"]
    if requested <= 0:
        return None, requested, misses
    return max(0.0, min(1.0, 1 - misses / requested)), requested, misses


def lifetime_ratio(cur):
    if cur["requested"] <= 0:
        return None
    return max(0.0, min(1.0, 1 - cur["read_in"] / cur["requested"]))


# ---------------------------------------------------------------------------
# Browsing for threat reports
# ---------------------------------------------------------------------------
def parse_reports(markdown):
    """Return the reports listed in the README, in file order, one per URL."""
    seen, reports = set(), []
    for line in markdown.splitlines():
        m = ENTRY_RE.match(line)
        if not m or m.group("url") in seen:
            continue
        seen.add(m.group("url"))
        reports.append({
            "vendor": m.group("vendor").strip(),
            "vendor_url": m.group("vendor_url"),
            "title": m.group("title").strip(),
            "url": m.group("url"),
            "year": int(m.group("year")),
            "description": m.group("desc").strip(),
        })
    return reports


def load_reports(source, state):
    """Fetch and parse the list. Uses an ETag so an unchanged list costs almost nothing."""
    if not re.match(r"https?://", source):
        with open(source, encoding="utf-8") as f:
            return parse_reports(f.read()), "local file"
    req = urllib.request.Request(source, headers={"User-Agent": "lab7-2-threat-monitor/1.0"})
    if state.get("etag"):
        req.add_header("If-None-Match", state["etag"])
    try:
        with urllib.request.urlopen(req, timeout=20) as resp:
            text = resp.read().decode("utf-8", "replace")
            state["etag"] = resp.headers.get("ETag")
        return parse_reports(text), "downloaded"
    except urllib.error.HTTPError as exc:
        if exc.code == 304:
            return state["entries"], "not modified"
        raise


def find_new(coll, visible):
    """Reports from the source that are not in the database yet (covered by the url index)."""
    urls = [r["url"] for r in visible]
    existing = {d["url"] for d in coll.find({"url": {"$in": urls}}, {"url": 1, "_id": 0})}
    return [r for r in visible if r["url"] not in existing]


def store_reports(coll, new):
    now = datetime.now(timezone.utc)
    docs = [{**r, "first_seen": now} for r in new]
    try:
        coll.insert_many(docs, ordered=False)
        return len(docs)
    except BulkWriteError as exc:          # another run stored some of them first
        return exc.details.get("nInserted", 0)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main(argv=None):
    ap = argparse.ArgumentParser(description="Activity 7.2: WiredTiger cache hit-ratio monitor")
    ap.add_argument("--interval", type=float, default=10)
    ap.add_argument("--cycles", type=int, default=0)
    ap.add_argument("--source", default=DEFAULT_SOURCE)
    ap.add_argument("--simulate-new", type=int, default=0)
    ap.add_argument("--reset", action="store_true")
    ap.add_argument("--csv", default=None)
    args = ap.parse_args(argv)

    client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)
    coll = client[DB_NAME][COLL_NAME]

    try:
        prev = read_cache(client)
    except (KeyError, OperationFailure) as exc:
        print("This monitor needs the WiredTiger cache section of serverStatus "
              f"(self-managed mongod, or a cluster tier that allows serverStatus): {exc}")
        return

    if args.reset:
        coll.drop()
    coll.create_index([("url", ASCENDING)], unique=True)
    coll.create_index([("year", ASCENDING)])

    # ----- Research: the metrics this monitor reads -----
    heading("Research: WiredTiger metrics in db.serverStatus()")
    print_table(
        ["Metric (wiredTiger.cache unless noted)", "What it tells you", "Used here for"],
        [
            ["pages requested from the cache", "Every time WiredTiger looks for a page through the cache",
             "Denominator of the hit ratio"],
            ["pages read into cache", "The page was not cached and had to be read from disk (a miss)",
             "Misses, shown as 'Disk pages'"],
            ["bytes read into cache", "How much data the misses pulled from disk", "Disk read volume (summary)"],
            ["bytes currently in the cache / maximum bytes configured", "How full the cache is",
             "'Cache fill' column"],
            ["tracked dirty bytes in the cache", "Modified pages not yet written to disk (write pressure)",
             "Summary"],
            ["unmodified pages evicted + modified pages evicted", "Pages pushed out to make room (cache pressure)",
             "'Evicted' column"],
            ["wiredTiger.concurrentTransactions read / write", "Read and write tickets in use (concurrency), "
             "shown if your version reports it", "Summary"],
            ["Formula", "hit ratio = (requested - read into cache) / requested, from the change between two samples",
             "'Hit ratio' column"],
        ],
        max_widths=[46, 62, 28],
    )

    print(f"\nMonitoring every {args.interval:g} s  |  source: {args.source}\n"
          f"database: {DB_NAME}.{COLL_NAME}  |  stop with Ctrl+C\n")
    print_live_header()

    writer = csv_file = None
    if args.csv:
        is_new = not os.path.exists(args.csv) or os.path.getsize(args.csv) == 0
        csv_file = open(args.csv, "a", newline="", encoding="utf-8")
        writer = csv.writer(csv_file)
        if is_new:
            writer.writerow(["time", "at_source", "new", "in_db", "hit_ratio", "cache_fill",
                             "disk_pages", "evicted", "check_ms"])

    state = {"etag": None, "entries": []}
    held = None                       # deque of urls held back by --simulate-new
    ratios, inserted_total, misses_total, cycle = [], 0, 0, 0
    cur = prev
    try:
        while True:
            cycle += 1
            started = time.monotonic()
            work_start = time.perf_counter()
            note = ""

            # 1. BROWSE
            try:
                entries, _how = load_reports(args.source, state)
                state["entries"] = entries
            except Exception as exc:                       # offline, blocked, bad file...
                entries = state["entries"]
                note = f"Source not reachable ({type(exc).__name__}); using the last list"

            # optional simulation of reports arriving one by one
            if args.simulate_new > 0 and entries:
                if held is None:
                    newest_first = sorted(range(len(entries)), key=lambda i: (-entries[i]["year"], i))
                    held = deque(entries[i]["url"] for i in newest_first[:args.simulate_new])
                elif held:
                    held.popleft()
            hidden = set(held) if held else set()
            visible = [r for r in entries if r["url"] not in hidden]

            # 2. COMPARE and 3. STORE
            new = find_new(coll, visible) if visible else []
            inserted = store_reports(coll, new) if new else 0
            inserted_total += inserted
            in_db = coll.estimated_document_count()
            check_ms = (time.perf_counter() - work_start) * 1000

            # wait for the end of the interval, then 4. MEASURE
            time.sleep(max(0.0, args.interval - (time.monotonic() - started)))
            cur = read_cache(client)
            ratio, _requested, misses = interval_ratio(prev, cur)
            evicted = cur["evicted"] - prev["evicted"]
            prev = cur
            misses_total += misses
            if ratio is not None:
                ratios.append(ratio)

            fill = cur["in_cache"] / cur["max"] if cur["max"] else 0
            stamp = datetime.now().strftime("%H:%M:%S")
            print(live_row([
                stamp, f"{len(visible):,}", f"{inserted:,}", f"{in_db:,}",
                "n/a" if ratio is None else f"{ratio * 100:.2f}%", bar(ratio),
                f"{fill * 100:.1f}%", f"{misses:,}", f"{evicted:,}", f"{check_ms:.0f}",
            ]), flush=True)
            for r in new[:5]:
                print(live_span(f"NEW  ({r['year']}) {r['vendor']} - {r['title']}"))
            if len(new) > 5:
                print(live_span(f"...and {len(new) - 5} more new reports stored"))
            if note:
                print(live_span(note))
            if writer:
                writer.writerow([stamp, len(visible), inserted, in_db,
                                 "" if ratio is None else f"{ratio:.4f}", f"{fill:.4f}",
                                 misses, evicted, f"{check_ms:.0f}"])
                csv_file.flush()

            if args.cycles and cycle >= args.cycles:
                break
    except KeyboardInterrupt:
        pass
    finally:
        print(live_border("└", "┴", "┘"))
        if csv_file:
            csv_file.close()

    # ----- Summary -----
    if cycle:
        heading("Summary")
        life = lifetime_ratio(cur)
        rows = [
            ["Cycles measured", f"{len(ratios)} of {cycle}"],
            ["Reports added to the database this session", f"{inserted_total:,}"],
            ["Reports in the database now", f"{coll.estimated_document_count():,}"],
        ]
        if ratios:
            rows += [
                ["Hit ratio: average of the intervals", f"{sum(ratios) / len(ratios) * 100:.2f}%"],
                ["Hit ratio: lowest / highest interval", f"{min(ratios) * 100:.2f}% / {max(ratios) * 100:.2f}%"],
            ]
        rows += [
            ["Hit ratio since the server started (for comparison)",
             "n/a" if life is None else f"{life * 100:.2f}%"],
            ["Pages read from disk while monitoring", f"{misses_total:,}"],
            ["Cache size / in use at exit", f"{cur['max'] / MB:,.0f} MB / {cur['in_cache'] / MB:,.1f} MB"],
            ["Dirty bytes in cache at exit", f"{cur['dirty'] / MB:,.2f} MB"],
        ]
        if cur["read_tickets_out"] is not None:
            rows.append(["Read / write tickets in use at exit",
                         f"{cur['read_tickets_out']} / {cur['write_tickets_out']}"])
        print_table(["Measure", "Value"], rows, max_widths=[52, 30])

    client.close()


if __name__ == "__main__":
    main()
"""
Seed script for Lab 7.1 - CTI Digest (cyber threat intelligence articles)

Creates four collections in the chapter-07 database:
    articles         main collection: embeds content_blocks[], tags[], sectors[]
                     and references the rest (source_id, actor_ids[], cve_ids[])
    sources          publishers (referenced by articles)
    threat_actors    threat groups (referenced by articles)
    vulnerabilities  CVEs (referenced by articles)

Run it first, then the Lab 7.1 scripts:
    python 7_1_Seed_ctidigest.py
    python lab_7_1_Seed_ctidigest.py      (the analysis / answers script)
    python lab7_1tryityourself.py

Set MONGO_URI to use a non-default server. Raise N_ARTICLES (for example 50000) to make
the timing differences in the "try it yourself" activity easier to see.
The data is synthetic and generated from a fixed random seed, so every run is identical.
"""

import os
import random
from datetime import datetime, timedelta, timezone

from pymongo import ASCENDING, MongoClient

MONGO_URI = os.environ.get("MONGO_URI", "mongodb://localhost:27017")
DB_NAME = "chapter-07"
N_ARTICLES = 500
SEED = 7

SOURCES = [
    ("BleepingComputer", "https://www.bleepingcomputer.com", "news"),
    ("The Hacker News", "https://thehackernews.com", "news"),
    ("Mandiant Blog", "https://www.mandiant.com/resources/blog", "vendor"),
    ("CrowdStrike Blog", "https://www.crowdstrike.com/blog", "vendor"),
    ("Microsoft Security", "https://www.microsoft.com/security/blog", "vendor"),
    ("CISA Advisories", "https://www.cisa.gov/news-events/cybersecurity-advisories", "government"),
    ("Krebs on Security", "https://krebsonsecurity.com", "blog"),
    ("SecurityWeek", "https://www.securityweek.com", "news"),
]

# name, aliases, country, motivation, ttps
ACTORS = [
    ("Lazarus Group", ["Hidden Cobra", "Zinc"], "KP", "financial", ["T1566", "T1059", "T1486"]),
    ("APT29", ["Cozy Bear", "Midnight Blizzard"], "RU", "espionage", ["T1078", "T1195", "T1071"]),
    ("APT28", ["Fancy Bear", "Forest Blizzard"], "RU", "espionage", ["T1566", "T1110", "T1003"]),
    ("APT41", ["Winnti", "Barium"], "CN", "espionage", ["T1190", "T1505", "T1027"]),
    ("Sandworm", ["Voodoo Bear", "Seashell Blizzard"], "RU", "sabotage", ["T1485", "T1561", "T1190"]),
    ("FIN7", ["Carbon Spider"], "RU", "financial", ["T1566", "T1204", "T1055"]),
    ("Scattered Spider", ["Octo Tempest", "UNC3944"], "US", "financial", ["T1621", "T1078", "T1566"]),
    ("LockBit", ["LockBit 3.0"], "RU", "financial", ["T1486", "T1490", "T1021"]),
    ("Volt Typhoon", ["Bronze Silhouette"], "CN", "espionage", ["T1133", "T1078", "T1003"]),
    ("MuddyWater", ["Mango Sandstorm"], "IR", "espionage", ["T1566", "T1059", "T1105"]),
    ("Kimsuky", ["Emerald Sleet"], "KP", "espionage", ["T1566", "T1204", "T1056"]),
    ("Conti", ["Wizard Spider"], "RU", "financial", ["T1486", "T1021", "T1047"]),
]

PRODUCTS = ["Exchange Server", "Fortinet FortiOS", "Ivanti Connect Secure", "Citrix NetScaler",
            "Apache Tomcat", "Windows SMB", "Cisco IOS XE", "Palo Alto PAN-OS", "VMware ESXi",
            "Atlassian Confluence", "OpenSSH", "Veeam Backup", "MOVEit Transfer", "GitLab", "WordPress"]
SECTORS = ["healthcare", "finance", "energy", "government", "education", "retail",
           "manufacturing", "telecom", "technology"]
TAGS = ["ransomware", "phishing", "zero-day", "supply-chain", "cloud", "ics", "identity",
        "botnet", "espionage", "data-breach", "malware", "vulnerability"]
VERBS = ["Exploits", "Targets", "Abuses", "Weaponizes", "Hits", "Compromises", "Disrupts"]
OBJECTS = ["critical flaw", "remote access tools", "backup servers", "cloud tenants",
           "VPN gateways", "email gateways", "build pipelines", "industrial controllers"]


def make_vulnerabilities(rng, n=40):
    docs, used = [], set()
    while len(docs) < n:
        cve = f"CVE-{rng.choice([2024, 2025, 2026])}-{rng.randint(1000, 49999)}"
        if cve in used:
            continue
        used.add(cve)
        docs.append({
            "cve_id": cve,
            "product": rng.choice(PRODUCTS),
            "cvss": round(rng.uniform(4.0, 10.0), 1),
            "exploited_in_wild": rng.random() < 0.35,
            "published": datetime(2026, 1, 1) + timedelta(days=rng.randint(0, 300)),
        })
    return docs


def make_block(rng, kind):
    if kind == "heading":
        return {"type": "heading", "level": rng.randint(2, 3), "text": rng.choice(OBJECTS).title()}
    if kind == "paragraph":
        return {"type": "paragraph", "text": " ".join(rng.choices(
            ["Analysts", "observed", "activity", "linked", "to", "the", "campaign", "targeting",
             "organizations", "through", "stolen", "credentials", "and", "unpatched", "services."],
            k=rng.randint(25, 70)))}
    if kind == "list":
        return {"type": "list", "items": [f"IOC {rng.randint(100, 999)}" for _ in range(rng.randint(3, 8))]}
    if kind == "code":
        return {"type": "code", "language": "text",
                "text": f"sha256 {rng.getrandbits(128):032x}{rng.getrandbits(128):032x}"}
    if kind == "quote":
        return {"type": "quote", "text": "We assess with moderate confidence that this activity will continue."}
    return {"type": "image", "url": f"https://images.example.com/{rng.randint(1000, 9999)}.png",
            "caption": "Infrastructure overview"}


def make_articles(rng, source_ids, actor_ids, cve_ids, n):
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    kinds = ["heading", "paragraph", "paragraph", "paragraph", "list", "code", "quote", "image"]
    articles = []
    for i in range(n):
        blocks = [make_block(rng, "heading"), make_block(rng, "paragraph")]
        blocks += [make_block(rng, rng.choice(kinds)) for _ in range(rng.randint(2, 8))]
        articles.append({
            "title": f"{rng.choice(VERBS)} {rng.choice(OBJECTS)} #{i + 1:05d}",
            "published": now - timedelta(days=rng.randint(0, 180), hours=rng.randint(0, 23)),
            "source_id": rng.choice(source_ids),
            "actor_ids": rng.sample(actor_ids, rng.randint(0, 3)),
            "cve_ids": rng.sample(cve_ids, rng.randint(0, 3)),
            "tags": rng.sample(TAGS, rng.randint(1, 4)),
            "sectors": rng.sample(SECTORS, rng.randint(1, 3)),
            "content_blocks": blocks,
        })
    return articles


def main():
    rng = random.Random(SEED)
    client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)
    db = client[DB_NAME]

    for name in ["articles", "articles_embedded", "sources", "threat_actors", "vulnerabilities"]:
        db[name].drop()          # start fresh; also removes the Activity 7.1 redesign collection

    source_ids = db.sources.insert_many(
        [{"name": n, "url": u, "type": t} for n, u, t in SOURCES]).inserted_ids
    actor_ids = db.threat_actors.insert_many(
        [{"name": n, "aliases": a, "country": c, "motivation": m, "ttps": t}
         for n, a, c, m, t in ACTORS]).inserted_ids
    vulns = make_vulnerabilities(rng)
    db.vulnerabilities.insert_many(vulns)
    cve_ids = [v["cve_id"] for v in vulns]          # articles reference CVEs by cve_id

    articles = make_articles(rng, source_ids, actor_ids, cve_ids, N_ARTICLES)
    for start in range(0, len(articles), 5000):
        db.articles.insert_many(articles[start:start + 5000])

    db.articles.create_index([("published", ASCENDING)])
    db.articles.create_index("actor_ids")
    db.vulnerabilities.create_index("cve_id", unique=True)

    print(f"Seeded database '{DB_NAME}':")
    for name in ["articles", "sources", "threat_actors", "vulnerabilities"]:
        print(f"  {name:<16} {db[name].count_documents({}):>8,} documents")
    print("Next: python lab_7_1_Seed_ctidigest.py")
    client.close()


if __name__ == "__main__":
    main()